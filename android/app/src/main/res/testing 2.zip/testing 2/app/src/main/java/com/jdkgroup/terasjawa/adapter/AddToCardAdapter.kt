package com.jdkgroup.terasjawa.adapter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.recyclerview.BaseRecyclerView
import com.jdkgroup.customviews.recyclerview.BaseViewHolder
import com.jdkgroup.model.api.response.addtocart.cartlist.CartList
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.glideSetAppImageView
import kotlinx.android.synthetic.main.itemview_add_to_card.view.*

class AddToCardAdapter(private val activity: Activity, private val cartList: ArrayList<CartList>) : BaseRecyclerView<CartList>() {

    private val inflater: LayoutInflater = LayoutInflater.from(activity)
    private lateinit var listener: ItemListener

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): CartList {
        return cartList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<CartList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_add_to_card, parent, false))
    }

    override fun getItemCount(): Int {
        return cartList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<CartList>(itemView), View.OnClickListener {
        var appIvMenuIcon = itemView.appIvMenuIcon!!
        var appTvTitle = itemView.appTvTitle!!
        var appTvPrice = itemView.appTvPrice!!
        var appBtnQty = itemView.appBtnQty!!
        var appTvDelete = itemView.appTvDelete!!

        var appBtnMinus = itemView.appBtnMinus!!
        var appBtnAdd = itemView.appBtnAdd!!


        init {
            appTvDelete.setOnClickListener(this)
            appBtnAdd.setOnClickListener(this)
            appBtnMinus.setOnClickListener(this)
        }

        override fun populateItem(t: CartList) {
            activity.glideSetAppImageView(RestConstant.IMAGE_URL + t.menuImage, appIvMenuIcon)
            appTvTitle.text = t.menuName.toString()
            appTvPrice.text = (java.lang.Float.valueOf(t.menuPrice) * java.lang.Float.valueOf(t.menuQty)).toString()
            appBtnQty.text = t.menuQty

            val qtyCal = cartList[layoutPosition].menuQty.toDouble()
            val priceCal = cartList[layoutPosition].menuPrice.toDouble()
            appTvPrice.text = (qtyCal * priceCal).toString()

            updateTotal(layoutPosition, 0)
        }

        override fun onClick(v: View) {
            when (v.id) {
                R.id.appTvDelete -> {
                    listener.onClickDeleteCartItem(layoutPosition, cartList[layoutPosition].cartId.toInt(), cartList[layoutPosition].menuId.toString(), cartList[layoutPosition].menuName)
                }
                R.id.appBtnAdd -> {
                    val strQty = appBtnQty.text.toString()
                    var qty = 0
                    try {
                        qty = Integer.parseInt(strQty)
                    } catch (e: Exception) {
                    }

                    qty++

                    appBtnQty.text = qty.toString() + ""
                    cartList[layoutPosition].menuQty = qty.toString()
                    val qtyCal = cartList[layoutPosition].menuQty.toDouble()
                    val priceCal = cartList[layoutPosition].menuPrice.toDouble()
                    appTvPrice.text = (qtyCal * priceCal).toString()

                    updateTotal(layoutPosition, 1)
                }

                R.id.appBtnMinus -> {
                    val strQty = appBtnQty.text.toString()
                    var qty = 1
                    try {
                        qty = Integer.parseInt(strQty)
                        if (qty > 1)
                            qty--
                    } catch (e: Exception) {
                    }

                    cartList[layoutPosition].menuQty = qty.toString()
                    appBtnQty.text = qty.toString() + ""

                    val qtyCal = cartList[layoutPosition].menuQty.toDouble()
                    val priceCal = cartList[layoutPosition].menuPrice.toDouble()
                    appTvPrice.text = (qtyCal * priceCal).toString()

                    updateTotal(layoutPosition, 1)
                }
            }
        }
    }

    fun updateTotal(position: Int, status: Int) {
        var grandTotal = 0.00

        cartList.forEach { product ->
            val qty = product.menuQty.toDouble()
            val price = product.menuPrice.toDouble()
            grandTotal += qty * price
        }
        listener.onCartChange(grandTotal, cartList[position], status)
    }

    fun grandTotal(cartItem: String) {
        var grandTotal = 0.00

        cartList.forEach { product ->
            val qty = product.menuQty.toDouble()
            val price = product.menuPrice.toDouble()
            grandTotal += qty * price
        }
        listener.onCartChange(grandTotal, cartItem)
    }

    fun remove(position: Int) {
        cartList.removeAt(position)
        notifyItemRemoved(position)

        grandTotal(cartList.size.toString());
    }


    interface ItemListener {
        fun onClickDeleteCartItem(position: Int, cartId: Int, menuId: String, cartName: String)
        fun onCartChange(grandTotal: Double, cartItems: CartList, status: Int)
        fun onCartChange(grandTotal: Double, cartItem: String)
    }
}


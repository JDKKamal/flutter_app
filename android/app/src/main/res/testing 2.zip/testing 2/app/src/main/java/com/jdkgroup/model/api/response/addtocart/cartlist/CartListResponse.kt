package com.jdkgroup.model.api.response.addtocart.cartlist

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CartListResponse{
    @SerializedName("response")
    @Expose
    lateinit var response: Response
    @SerializedName("cart_list")
    @Expose
    lateinit var cartList: ArrayList<CartList>
}
package com.jdkgroup.model.api.request

class ForgotPasswordRequest {
    var email: String? = null

    constructor() {}

    constructor(email: String) {
        this.email = email
    }
}

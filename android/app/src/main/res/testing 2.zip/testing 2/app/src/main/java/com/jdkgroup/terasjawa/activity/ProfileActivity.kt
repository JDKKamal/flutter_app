package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.support.v7.app.AlertDialog
import android.view.View
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.Logout
import com.jdkgroup.customviews.permission.PermissionDexter
import com.jdkgroup.db.DBQuery
import com.jdkgroup.model.api.response.profile.ProfileResponse
import com.jdkgroup.model.db.CategoryListRealm
import com.jdkgroup.model.event.ProfileEvent
import com.jdkgroup.presenter.ProfilePresenter
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.*
import com.jdkgroup.view.ProfileView
import kotlinx.android.synthetic.main.activity_profile.*
import kotlinx.android.synthetic.main.toolbar_profile.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.greenrobot.eventbus.EventBus
import java.io.File

class ProfileActivity : SimpleMVPActivity<ProfilePresenter, ProfileView>(), ProfileView, View.OnClickListener, PermissionDexter.OnPermissionChangedListener, Logout.OnLogoutListener {

    private val GALLERY = 1
    private val CAMERA = 2
    private var path: String? = null
    private var isPath: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        hideSoftKeyboard()
        EventBus.getDefault()

        appTvTitle.text = getString(R.string.toolbar_title_profile_event).toUpperCase()

        //TODO IF LOGIN STATUS NOT 0 THEN appEdtName NOT EDIT, appEdtPassword IS GONE
        when {
            PreferenceUtils.preferenceInstance(this).loginStatus != RestConstant.LOGIN_SIMPLE_STATUS -> {
                appEdtEmail.isFocusable = false
                appEdtPassword.visibility = View.GONE
            }
            else -> {
                appEdtEmail.clearFocus()
                appEdtEmail.isFocusable = true
                appEdtPassword.visibility = View.VISIBLE
            }
        }

        when {
            PreferenceUtils.preferenceInstance(this).isLogin -> {
                appEdtName.setText(PreferenceUtils.preferenceInstance(this).userName)
                appEdtEmail.setText(PreferenceUtils.preferenceInstance(this).email)

                appTvUserName.text = PreferenceUtils.preferenceInstance(this).userName

                appEdtName.setSelection(appEdtName.text!!.length)
                when {
                    PreferenceUtils.preferenceInstance(this.activity).profilepicture.isNotEmpty() -> glideSetAppImageView(PreferenceUtils.preferenceInstance(this).profilepicture, appIvProfile)
                }

                when {
                    !PreferenceUtils.preferenceInstance(this).mobile.isBlank() -> appEdtMobile.setText(PreferenceUtils.preferenceInstance(this).mobile)
                }
            }
        }

        appIvDrawer.setOnClickListener(this)
        appTvLogout.setOnClickListener(this)
        appBtnUpdateProfile.setOnClickListener(this)
        appIvProfile.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appIvDrawer -> finish()

            R.id.appBtnUpdateProfile -> {
                when {
                    presenter.validation(appEdtName.text.toString(), appEdtEmail.text.toString(), appEdtMobile.text.toString(), appEdtPassword.text.toString()) -> {
                        var mediaType = MediaType.parse("text/plain")
                        var requestBody: RequestBody
                        var file: File?
                        var fileName: String?

                        when {
                            !isPath -> {
                                requestBody = RequestBody.create(null, ByteArray(0))
                                fileName = ""
                            }
                            else -> {
                                file = File(path)
                                requestBody = RequestBody.create(MediaType.parse("*/*"), file)
                                fileName = file.name
                            }
                        }

                        val rbUserId: RequestBody = RequestBody.create(mediaType, PreferenceUtils.preferenceInstance(this).userId)
                        val rbUsername: RequestBody = RequestBody.create(mediaType, appEdtName.text.toString())
                        val rbEmail: RequestBody = RequestBody.create(mediaType, appEdtEmail.text.toString())
                        val rbPassword: RequestBody = RequestBody.create(mediaType, appEdtPassword.text.toString())
                        val rbMobile: RequestBody = RequestBody.create(mediaType, appEdtMobile.text.toString())
                        val rbAddress: RequestBody = RequestBody.create(mediaType, "")

                        val fileUpload = MultipartBody.Part.createFormData(RestConstant.PARAM_USER_IMAGE, fileName, requestBody)
                        presenter.callApiProfile(fileUpload, rbUserId, rbUsername, rbEmail, rbPassword, rbMobile, rbAddress)
                    }
                }
            }

            R.id.appTvLogout -> Logout(activity, this).logout()

            R.id.appIvProfile -> {
                val permissions = ArrayList<String>()
                permissions.add(Manifest.permission.CAMERA)
                permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
                permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)

                PermissionDexter(activity, permissions, this).permissionMultiple()
            }
        }
    }

    override fun createPresenter(): ProfilePresenter {
        return ProfilePresenter()
    }

    override fun attachView(): ProfileView {
        return this
    }

    override fun apiPostProfileResponse(response: ProfileResponse) {
        val responseCheck = response.response
        showToast(responseCheck.message)

        when {
            responseManage(responseCheck) -> {
                isPath = false
                PreferenceUtils.preferenceInstance(this).userName = response.updateUserProfile.name
                PreferenceUtils.preferenceInstance(this).email = response.updateUserProfile.email
                PreferenceUtils.preferenceInstance(this).mobile = response.updateUserProfile.phone
                PreferenceUtils.preferenceInstance(this).profilepicture = response.updateUserProfile.userImage

                appTvUserName.text = PreferenceUtils.preferenceInstance(this).userName
                EventBus.getDefault().post(ProfileEvent(response.updateUserProfile.userImage))
            }
        }
    }

    override fun onFailure(message: String) {
        showToast(message)
    }

    private fun showPictureDialog() {
        val pictureDialog = AlertDialog.Builder(this)
        pictureDialog.setTitle(getString(R.string.dialog_profile_title))
        val pictureDialogItems = arrayOf(getString(R.string.dialog_profile_gallery), getString(R.string.dialog_profile_camera))
        pictureDialog.setItems(pictureDialogItems) { _, which ->
            when (which) {
                0 -> chooseFromGallery()
                1 -> takeFromCamera()
            }
        }
        pictureDialog.show()
    }

    private fun chooseFromGallery() {
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(galleryIntent, GALLERY)
    }

    private fun takeFromCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA)
    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when {
            resultCode != Activity.RESULT_CANCELED -> when (requestCode) {
                GALLERY -> when {
                    data != null -> {
                        val contentURI = data.data

                        val bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, contentURI)
                        val path = saveImage(bitmap)
                        this.path = path
                        appIvProfile.setImageBitmap(bitmap)
                        isPath = true
                    }
                }
                CAMERA -> {
                    val thumbnail = data!!.extras.get("data") as Bitmap
                    appIvProfile.setImageBitmap(thumbnail)
                    val path = saveImage(thumbnail)
                    this.path = path
                    isPath = true
                }
            }
        }
    }

    override fun onLogout(boolean: Boolean) {
        DBQuery.with(activity).realmDeleteTable(CategoryListRealm::class.java)

        PreferenceUtils.preferenceInstance(activity).loginStatus = 0
        PreferenceUtils.preferenceInstance(activity).isLogin = false
        PreferenceUtils.preferenceInstance(activity).email = ""
        PreferenceUtils.preferenceInstance(activity).userName = ""
        PreferenceUtils.preferenceInstance(activity).mobile = ""
        PreferenceUtils.preferenceInstance(activity).profilepicture = ""
        PreferenceUtils.preferenceInstance(activity).loginStatus = 0

        launchActivity(LoginActivity::class.java, EnumLaunchActivity.ClearHistory)
    }

    override fun onAllPermissionGranted(boolean: Boolean) {
        when {
            hasInternet() -> showPictureDialog()
        }
    }

    override fun onBackPressed() {
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }
}
package com.jdkgroup.model.api.response.menucategory

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MenuCategoryResponse{
    @SerializedName("response")
    @Expose
    lateinit var response: Response
    @SerializedName("menu_list_cat")
    @Expose
    lateinit var menuListCat: MutableList<MenuCategoryList>
    @SerializedName("menu_cart")
    @Expose
    lateinit var menuCart: MutableList<MenuCartList>
}
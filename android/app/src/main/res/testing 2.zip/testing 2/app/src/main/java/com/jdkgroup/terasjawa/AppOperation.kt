package com.jdkgroup.terasjawa

import android.app.Activity
import android.content.Intent
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.customviews.socialintegration.facebookintegration.FacebookLoginHelper
import com.jdkgroup.customviews.socialintegration.googleintegration.GoogleLoginHelper
import com.jdkgroup.customviews.socialintegration.twitterintegration.TwitterHelper
import com.jdkgroup.model.api.response.addtocart.cartlist.CartListResponse
import com.jdkgroup.model.api.response.login.LoginResponse
import com.jdkgroup.model.api.response.menu.MenuList
import com.jdkgroup.model.api.response.menucategory.MenuCategoryList
import com.jdkgroup.model.parcelable.CategoryParcelable
import com.jdkgroup.model.parcelable.MenuParcelable
import com.jdkgroup.terasjawa.activity.*
import com.jdkgroup.utils.EnumLaunchActivity
import com.jdkgroup.utils.PreferenceUtils
import com.jdkgroup.utils.launchActivity
import com.jdkgroup.utils.sentParcelsLaunchClear
import java.util.*

sealed class AppOperation
class Finish(var activity: Activity) : AppOperation()
class LogoutBack(var activity: Activity) : AppOperation()
class ForgotPassword(var activity: Activity) : AppOperation()
class SignUpIntent(var activity: Activity) : AppOperation()
class FacebookLogin(var activity: Activity, var facebookLoginHelper: FacebookLoginHelper) : AppOperation()
class TwitterLogin(var twitterHelper: TwitterHelper) : AppOperation()
class GooglePlusLogin(var activity: Activity, var googleLoginHelper: GoogleLoginHelper) : AppOperation()
class Login(var activity: Activity, var response: LoginResponse, var loginStatus: Int) : AppOperation()
class DrawerIntentLogin(var activity: Activity, var response: CartListResponse) : AppOperation()
class SignUpTerms(var activity: Activity) : AppOperation()

class IntentDrawerActivity(var activity: Activity) : AppOperation()
class MenuClick(var activity: Activity, var modelMenu: MenuList, var alPassDataQuestion: ArrayList<MenuParcelable>) : AppOperation()
class CategoryClick(var activity: Activity, var parcelableTopic: List<MenuParcelable>?, var menuCategoryList: MenuCategoryList, var listCategoryPassData: ArrayList<CategoryParcelable>) : AppOperation()
class ActivityResultSocialLogin(var googleLoginHelper: GoogleLoginHelper, var facebookLoginHelper: FacebookLoginHelper, var twitterHelper: TwitterHelper, var requestCode: Int, var resultCode: Int, var data: Intent) : AppOperation()
class CommentAddClick(var activity: Activity, var parcelableTopic: List<MenuParcelable>?, var menuCategoryList: MenuCategoryList, var listCategoryPassData: ArrayList<CategoryParcelable>) : AppOperation()

fun execute(op: AppOperation) = when (op) {
    is Finish -> op.activity.finish()
    is LogoutBack -> {
        PreferenceUtils.preferenceInstance(op.activity).isLogout == 0
        op.activity.startActivity(Intent(op.activity, SliderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK))
        op.activity.finish()
    }
    is ForgotPassword -> op.activity.launchActivity(ForgotPasswordActivity::class.java, EnumLaunchActivity.LaunchActivity)
    is SignUpIntent -> op.activity.launchActivity(SignUpActivity::class.java, EnumLaunchActivity.LaunchActivity)
    is FacebookLogin -> op.facebookLoginHelper.performSignIn(op.activity)
    is TwitterLogin -> op.twitterHelper.performSignIn()
    is GooglePlusLogin -> {
        op.googleLoginHelper.performSignOut()
        op.googleLoginHelper.performSignIn(op.activity)
    }
    is Login -> {
        PreferenceUtils.preferenceInstance(op.activity).isLogin = true
        PreferenceUtils.preferenceInstance(op.activity).loginStatus = op.loginStatus
        PreferenceUtils.preferenceInstance(op.activity).isLogout = 1
        PreferenceUtils.preferenceInstance(op.activity).userId = op.response.loginDetail.userId
        PreferenceUtils.preferenceInstance(op.activity).userName = op.response.loginDetail.name
        PreferenceUtils.preferenceInstance(op.activity).email = op.response.loginDetail.email
        PreferenceUtils.preferenceInstance(op.activity).mobile = op.response.loginDetail.phone
        PreferenceUtils.preferenceInstance(op.activity).promoItem = op.response.loginDetail.promoRowcount

        PreferenceUtils.preferenceInstance(op.activity).profilepicture = op.response.loginDetail.userImage

        if (op.response.loginDetail!!.cartItems!! > 0) {
            PreferenceUtils.preferenceInstance(op.activity).cartItem = op.response.loginDetail!!.cartItems.toString()
        } else {
            PreferenceUtils.preferenceInstance(op.activity).cartItem = "00"
        }
    }
    is DrawerIntentLogin -> {
        op.activity.launchActivity(DrawerActivity::class.java, EnumLaunchActivity.LaunchActivity)
        op.activity.finish()
    }

    is SignUpTerms -> op.activity.launchActivity(SignUpTermsActivity::class.java, EnumLaunchActivity.LaunchActivity)

    is IntentDrawerActivity -> {
        op.activity.launchActivity(DrawerActivity::class.java, EnumLaunchActivity.LaunchActivity)
        op.activity.finish()
    }
    is MenuClick -> {
        op.alPassDataQuestion.add(MenuParcelable(op.modelMenu.cid, op.modelMenu.categoryName, op.modelMenu.categoryImage))
        op.activity.sentParcelsLaunchClear(CategoryActivity::class.java, AppConstant.BUNDLE_PARCELABLE, op.alPassDataQuestion, 1)
    }
    is CategoryClick -> {
        op.listCategoryPassData.add(
                CategoryParcelable(op.parcelableTopic!![0].cid,
                        op.menuCategoryList.menuName, //parcelableTopic!![0].categoryName
                        op.menuCategoryList.mid,
                        op.menuCategoryList.menuName,
                        op.menuCategoryList.menuInfo,
                        op.menuCategoryList.menuImage,
                        op.menuCategoryList.totalRate,
                        op.menuCategoryList.rateAvg,
                        op.menuCategoryList.menuPrice
                ))
        op.activity.sentParcelsLaunchClear(CategoryDetailActivity::class.java, AppConstant.BUNDLE_PARCELABLE, op.listCategoryPassData, 1)
    }
    is ActivityResultSocialLogin -> {
        op.facebookLoginHelper.onActivityResult(op.requestCode, op.resultCode, op.data)
        op.googleLoginHelper.onActivityResult(op.requestCode, op.data)
        op.twitterHelper.onActivityResult(op.requestCode, op.resultCode, op.data)
    }

    is CommentAddClick -> {
        op.listCategoryPassData.add(
                CategoryParcelable(op.parcelableTopic!![0].cid,
                        op.menuCategoryList.menuName, //parcelableTopic!![0].categoryName
                        op.menuCategoryList.mid,
                        op.menuCategoryList.menuName,
                        op.menuCategoryList.menuInfo,
                        op.menuCategoryList.menuImage,
                        op.menuCategoryList.totalRate,
                        op.menuCategoryList.rateAvg,
                        op.menuCategoryList.menuPrice
                ))
        op.activity.sentParcelsLaunchClear(CommentAddActivity::class.java, AppConstant.BUNDLE_PARCELABLE, op.listCategoryPassData, 1)
    }
}

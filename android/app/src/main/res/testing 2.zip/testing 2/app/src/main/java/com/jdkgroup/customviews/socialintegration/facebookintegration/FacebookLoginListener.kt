package com.jdkgroup.customviews.socialintegration.facebookintegration

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

interface FacebookLoginListener {
    fun onFbSignInFail(errorMessage: String)
    fun onFbSignInSuccess(facebookLoginModel: FacebookLoginModel)
    fun onFBSignOut()
}

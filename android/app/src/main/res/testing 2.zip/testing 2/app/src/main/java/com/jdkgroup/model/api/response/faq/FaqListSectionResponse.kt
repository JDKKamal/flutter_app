package com.jdkgroup.model.api.faq

import com.jdkgroup.model.api.Response

class FaqListSectionResponse {
    var listfaqsection: List<ListFaqSection>? = null
    var response: Response? = null

}

package com.jdkgroup.model.parcelable

import android.os.Parcel
import android.os.Parcelable

data class CommentParcelable(val mId: String, val commentName: String, val categoryName: String) : Parcelable {

    constructor(source: Parcel) :
            this(
                    source.readString(),
                    source.readString(),
                    source.readString())

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest?.writeString(this.mId)
        dest?.writeString(this.commentName)
        dest?.writeString(this.categoryName)
    }

    companion object {
        @JvmField
        final val CREATOR: Parcelable.Creator<CommentParcelable> = object : Parcelable.Creator<CommentParcelable> {
            override fun createFromParcel(source: Parcel): CommentParcelable {
                return CommentParcelable(source)
            }

            override fun newArray(size: Int): Array<CommentParcelable?> {
                return arrayOfNulls(size)
            }
        }
    }
}
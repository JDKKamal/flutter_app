package com.jdkgroup.model.event

class PromoEvent(val promoCount: String)

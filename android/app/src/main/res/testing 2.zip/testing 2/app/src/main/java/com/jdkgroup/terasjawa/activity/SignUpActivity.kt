package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.socialintegration.facebookintegration.FacebookLoginHelper
import com.jdkgroup.customviews.socialintegration.facebookintegration.FacebookLoginListener
import com.jdkgroup.customviews.socialintegration.facebookintegration.FacebookLoginModel
import com.jdkgroup.customviews.socialintegration.googleintegration.GoogleLoginHelper
import com.jdkgroup.customviews.socialintegration.googleintegration.GoogleLoginListener
import com.jdkgroup.customviews.socialintegration.googleintegration.GoogleLoginModel
import com.jdkgroup.customviews.socialintegration.twitterintegration.TwitterHelper
import com.jdkgroup.customviews.socialintegration.twitterintegration.TwitterListener
import com.jdkgroup.customviews.socialintegration.twitterintegration.TwitterUser
import com.jdkgroup.db.DBQuery
import com.jdkgroup.model.api.request.SignUpRequest
import com.jdkgroup.model.api.response.signup.SignUpResponse
import com.jdkgroup.model.api.response.signup.facebook.FacebookResponse
import com.jdkgroup.model.api.response.signup.gmail.GmailSignUpResponse
import com.jdkgroup.model.api.response.signup.twitter.TwitterSignUpResponse
import com.jdkgroup.model.db.CategoryListRealm
import com.jdkgroup.presenter.SignUpPresenter
import com.jdkgroup.terasjawa.*
import com.jdkgroup.utils.*
import com.jdkgroup.view.SignUpView
import kotlinx.android.synthetic.main.activity_signup.*
import kotlinx.android.synthetic.main.include_social.*

class SignUpActivity : SimpleMVPActivity<SignUpPresenter, SignUpView>(), SignUpView, FacebookLoginListener, GoogleLoginListener, TwitterListener, View.OnClickListener {
    private lateinit var facebookLoginHelper: FacebookLoginHelper
    private lateinit var googleLoginHelper: GoogleLoginHelper
    private lateinit var twitterHelper: TwitterHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        hideSoftKeyboard()

        //TODO SOCIAL LOGIN
        facebookLoginHelper = FacebookLoginHelper(this)
        googleLoginHelper = GoogleLoginHelper(this, this, RestConstant.SOCIAL_GOOGLE_ID)
        twitterHelper = TwitterHelper(R.string.twitter_api_key, R.string.twitter_secrate_key, this, this)

        appBtnSignUp.setOnClickListener(this)
        appIvSocialFacebook.setOnClickListener(this)
        appIvSocialTwitter.setOnClickListener(this)
        appIvSocialGooglePlus.setOnClickListener(this)
        appTvTerms.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appBtnSignUp -> {
                val name = appEdtName.text.toString()
                val email = appEdtEmail.text.toString()
                val mobile = appEdtMobile.text.toString()
                val password = appEdtPassword.text.toString()

                presenter.validation(name, email, mobile, password, appCBTermsCondition)
            }

            R.id.appIvSocialFacebook -> {
                var intentOperation = facebookLoginHelper.let { FacebookLogin(activity, it) }
                execute(intentOperation)
            }

            R.id.appIvSocialTwitter -> {
                var intentOperation = twitterHelper.let { TwitterLogin(it) }
                execute(intentOperation)
            }

            R.id.appIvSocialGooglePlus -> {
                var intentOperation = googleLoginHelper.let { GooglePlusLogin(activity, it) }
                execute(intentOperation)
            }

            R.id.appTvTerms -> {
                if (isInternet(true)) {
                    var intentOperation = SignUpTerms(activity)
                    execute(intentOperation)
                }
            }
        }
    }

    override fun createPresenter(): SignUpPresenter {
        return SignUpPresenter()
    }

    override fun attachView(): SignUpView {
        return this
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        var intentOperation = ActivityResultSocialLogin(googleLoginHelper, facebookLoginHelper, twitterHelper, requestCode, resultCode, data!!)
        execute(intentOperation)

    }

    override fun onFbSignInFail(errorMessage: String) {}

    override fun onFbSignInSuccess(facebookLoginModel: FacebookLoginModel) {
        val name = facebookLoginModel.name
        val email = facebookLoginModel.email
        val mobile = ""
        val facebookId = facebookLoginModel.id

        presenter.apiCall(RestConstant.CALL_API_FACEBOOK_REGISTER, SignUpRequest(name, email, mobile, facebookId))
    }

    override fun onFBSignOut() {

    }

    override fun onGoogleAuthSignIn(googleLoginModel: GoogleLoginModel) {
        val name = googleLoginModel.name
        val email = googleLoginModel.email
        val mobile = ""
        val googlePlusId = googleLoginModel.id

        presenter.apiCall(RestConstant.CALL_API_GOOGLE_PLUS_REGISTER, SignUpRequest(name, email, mobile, googlePlusId))
    }

    override fun onGoogleAuthSignInFailed(errorMessage: String) {
    }

    override fun onGoogleAuthSignOut() {
    }

    override fun onTwitterError() {
    }

    override fun onTwitterSignIn(userId: String, userName: String) {
        logInfo(getToJson(userId + userName))
    }

    override fun onTwitterProfileReceived(twitterUser: TwitterUser) {
        logInfo(getToJson(twitterUser))

        val name = twitterUser.name
        val email = twitterUser.email
        val mobile = ""
        val twitterId = twitterUser.id

        presenter.apiCall(RestConstant.CALL_API_TWITTER_REGISTER, SignUpRequest(name, email, mobile, twitterId.toString()))
    }

    override fun apiPostSignUpResponse(response: SignUpResponse) {
        showToast(response.response.message)

        when {
            response.response!!.code == RestConstant.OK_200 -> {
                var simpleSignUp = response.signUpDetail
                signUpRedirect(simpleSignUp!!.userId, simpleSignUp.name, simpleSignUp.email, simpleSignUp.phone, RestConstant.LOGIN_SIMPLE_STATUS)
            }
            else -> appEdtPassword.text = null
        }
    }

    override fun apiPostFacebookSignUpResponse(response: FacebookResponse) {
        val responseCheck = response.response
        showToast(responseCheck.message)

        when {
            responseManage(responseCheck) -> {
                var facebookRegister = response.facebookRegister
                signUpRedirect(facebookRegister.userId, facebookRegister.name, facebookRegister.email, "", RestConstant.LOGIN_FACEBOOK_STATUS)
            }
            else -> appEdtPassword.text = null
        }
    }

    override fun apiPostGooglePlusSignUpResponse(response: GmailSignUpResponse) {
        showToast(response.response.message)

        when {
            response.response.code == RestConstant.OK_200 -> {
                var facebookRegister = response.gplusRegister

                signUpRedirect(facebookRegister.userId, facebookRegister.name, facebookRegister.email, "", RestConstant.LOGIN_GOOGLE_PLUS_STATUS)
            }
        }
    }

    override fun apiPostTwitterPlusSignUpResponse(response: TwitterSignUpResponse) {
        showToast(response.response.message)

        when {
            response.response.code == RestConstant.OK_200 -> {
                var facebookRegister = response.twiterRegister

                signUpRedirect(facebookRegister.userId, facebookRegister.name, facebookRegister.email, "", RestConstant.LOGIN_TWITTER_STATUS)
            }
        }
    }

    override fun onFailure(message: String) {
        showToast(message)
    }

    private fun signUpRedirect(userID: String, userName: String, email: String, mobile: String, signUpStatus: Int) {
        DBQuery.with(this).realmDeleteTable(CategoryListRealm::class.java)
        PreferenceUtils.preferenceInstance(this).isLogout = 1

        PreferenceUtils.preferenceInstance(this).loginStatus = signUpStatus
        PreferenceUtils.preferenceInstance(this).isLogin = true
        PreferenceUtils.preferenceInstance(this).userId = userID
        PreferenceUtils.preferenceInstance(this).userName = userName
        PreferenceUtils.preferenceInstance(this).email = email
        PreferenceUtils.preferenceInstance(this).mobile = mobile
        PreferenceUtils.preferenceInstance(this).cartItem = "00"

        var intentOperation = IntentDrawerActivity(activity)
        execute(intentOperation)
    }

    override fun onBackPressed() {
        var intentOperation = Finish(activity)
        execute(intentOperation)
    }
}

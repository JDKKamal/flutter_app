package com.jdkgroup.utils

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Point
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Parcelable
import android.provider.MediaStore
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.content.ContextCompat
import android.support.v7.widget.*
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.common.base.CharMatcher
import com.google.common.base.Strings
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.terasjawa.R
import de.hdodenhof.circleimageview.CircleImageView
import org.apache.commons.lang3.StringUtils
import org.apache.commons.validator.routines.RegexValidator
import org.parceler.Parcels
import java.io.*
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Pattern

private var layoutManager: LinearLayoutManager? = null
const val LINEARLAYOUT = 0
const val GRIDLAYOUT = 1
const val HORIZONTALLAYOUT = 2

private var progressDialog: Dialog? = null

fun Activity.hideSoftKeyboard() {
    window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
    val imm = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.hideSoftInputFromWindow(window.decorView.windowToken, InputMethodManager.HIDE_IMPLICIT_ONLY)
    imm.hideSoftInputFromWindow(window.decorView.applicationWindowToken, InputMethodManager.HIDE_IMPLICIT_ONLY)
    imm.hideSoftInputFromWindow(window.decorView.windowToken, 0)
}

fun Activity.showKeyboard(appCompatEditText: AppCompatEditText) {
    val inputManager = this.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    inputManager.showSoftInput(appCompatEditText, InputMethodManager.SHOW_IMPLICIT)
}

fun Activity.requestEditTextFocus(view: AppCompatEditText) {
    view.requestFocus()
    showKeyboard(view)
}

fun Activity.navigationBarBackground(id: Int) {
    when {
        Build.VERSION.SDK_INT >= 21 -> window.navigationBarColor = ContextCompat.getColor(this, id)
    }
}

fun Activity.showToast(message: String) {
    val toast = Toast.makeText(this, message, Toast.LENGTH_SHORT)
    val textView = toast.view.findViewById<TextView>(android.R.id.message)
    textView.gravity = Gravity.CENTER
    toast.show()
}

fun Activity.isInternet(isDisplayMessage: Boolean): Boolean {
    val connectivityManager = this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val info = connectivityManager.activeNetworkInfo
    return when {
        info == null && isDisplayMessage -> {
            showToast(getString(R.string.no_internet_message))
            false
        }
        else -> true
    }
}

//Parcel
fun launchIsClearParcelable(activity: Activity, classType: Class<*>, bundle: Bundle, status: Int) {
    val intent = Intent(activity, classType)
    if (status == 0) {
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
    }
    intent.putExtra("bundle", bundle)
    activity.startActivity(intent)
}

fun Activity.sentParcelsLaunchClear(classType: Class<*>, bundleName: String, alData: List<*>, status: Int) {
    val bundle = Bundle()
    bundle.putParcelable(bundleName, Parcels.wrap<Any>(alData))
    launchParcel(classType, bundle, status)
}

fun Activity.launchParcel(classType: Class<*>, data: Bundle, status: Int) {
    val intent = Intent(this, classType)
    when (status) {
        0 -> intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
    }
    intent.putExtras(data)
    startActivity(intent)
}

fun <T> Activity.getParcelable(bundleName: String): T {
    return Parcels.unwrap<T>(intent.getParcelableExtra<Parcelable>(bundleName))
}

fun Activity.launchActivity(className: Class<*>, enumLaunchActivity: EnumLaunchActivity): Unit = when (enumLaunchActivity) {
    EnumLaunchActivity.LaunchActivity -> startActivity(Intent(this, className))
    EnumLaunchActivity.ClearHistory -> startActivity(Intent(this, className).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
}

fun Activity.fullScreen() {
    this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
}

fun addFragment(fragmentManager: FragmentManager, fragment: Fragment, id: Int) {
    fragmentManager.beginTransaction().add(id, fragment).addToBackStack(null).commit()
}

fun Activity.shareLink(link: String, subject: String, chooseName: String) {
    var intent = Intent(Intent.ACTION_SEND)
    intent.type = "text/plain"
    intent.putExtra(Intent.EXTRA_TEXT, link)
    intent.putExtra(android.content.Intent.EXTRA_SUBJECT, subject)
    startActivity(Intent.createChooser(intent, chooseName))
}

fun Activity.setRecyclerView(recyclerView: RecyclerView, spanCount: Int, no: Int): LinearLayoutManager? {
    when (no) {
        LINEARLAYOUT -> {
            layoutManager = LinearLayoutManager(this)
            recyclerView.layoutManager = layoutManager
            recyclerView.itemAnimator = DefaultItemAnimator()
            recyclerView.setHasFixedSize(true)
        }

        GRIDLAYOUT -> {
            layoutManager = GridLayoutManager(this, spanCount)
            recyclerView.layoutManager = layoutManager
            recyclerView.itemAnimator = DefaultItemAnimator()
            recyclerView.setHasFixedSize(true)
        }
        HORIZONTALLAYOUT -> {
            layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            recyclerView.layoutManager = layoutManager
        }
    }
    return layoutManager
}

fun Activity.checkProgressBar(enumProgressBar: EnumProgressBar): Unit = when (enumProgressBar) {
    EnumProgressBar.Show -> {
        when (progressDialog) {
            null -> progressDialog = Dialog(this)
        }

        val view = LayoutInflater.from(this).inflate(R.layout.progressbar_dialog, null, false)

        val appIvProgressBar = view.findViewById<AppCompatImageView>(R.id.appIvProgressBar)
        val animation = AnimationUtils.loadAnimation(this, R.anim.progress_anim)
        animation.duration = 1500
        appIvProgressBar.startAnimation(animation)

        progressDialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
        progressDialog!!.setContentView(view)
        val window = progressDialog!!.window
        window?.setBackgroundDrawable(ContextCompat.getDrawable(this, android.R.color.transparent))
        progressDialog!!.setCancelable(false)
        progressDialog!!.setCanceledOnTouchOutside(false)
        progressDialog!!.show()
    }
    EnumProgressBar.Hide -> {
        progressDialog!!.dismiss()
        progressDialog = null
    }
}

fun dpToPx(dp: Float, resources: Resources): Int {
    val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics)
    return px.toInt()
}

//For Get the screen dimensions
private val Activity.screenSize: IntArray
    get() {
        val size = Point()
        this.windowManager.defaultDisplay.getSize(size)
        return intArrayOf(size.x, size.y)
    }

fun Activity.isPackageExist(context: Context, packageInfo: String): Boolean {
    val packageInfo = context.packageManager.getPackageInfo(packageInfo, 0)
    if (packageInfo != null) {
        return true
    }
    return false
}

fun Activity.uninstallApk(context: Context, packageName: String) {
    when {
        isPackageExist(context, packageName) -> {
            val packageURI = Uri.parse("package:$packageName")
            val uninstallIntent = Intent(Intent.ACTION_DELETE, packageURI)
            context.startActivity(uninstallIntent)
        }
    }
}

fun Activity.glideSetAppImageView(imageUrl: String, circleImageView: CircleImageView) {
    Glide.with(this).load(imageUrl).into(circleImageView)
}

fun Activity.glideSetAppImageView(imageUrl: String, appIv: AppCompatImageView) {
    Glide.with(this).load(imageUrl).into(appIv)
}

fun Activity.glideSetAppImageView(imageUrl: Int, appIv: AppCompatImageView) {
    Glide.with(this).load(imageUrl).into(appIv)
}

fun Activity.getPathFromMediaUri(uri: Uri): String {
    var cursor: Cursor? = null
    try {
        cursor = contentResolver.query(uri, arrayOf(MediaStore.Images.Media.DATA), null, null, null)
        val columnIndex = cursor!!.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
        cursor.moveToFirst()
        return cursor.getString(columnIndex)
    } finally {
        when {
            cursor != null -> cursor.close()
        }
    }
}

//TODO val readFile = AppUtils.readFile("json/address", "txt")
fun Activity.readFile(fileName: String, extension: String): String {
    return try {
        val inputStream: InputStream = assets.open("$fileName.$extension")
        val inputString = inputStream.bufferedReader().use { it.readText() }
        inputString
    } catch (ex: Exception) {
        ex.toString()
    }
}

fun getDateFromTime(mTimestamp: Long, mDateFormat: String): String {
    val dateFormatter = SimpleDateFormat(mDateFormat)
    dateFormatter.timeZone = TimeZone.getDefault()

    val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
    cal.timeInMillis = mTimestamp

    return dateFormatter.format(cal.time)
}

fun getDateString(timeInMillis: Long, mDateFormate: String): String {
    val calendar = Calendar.getInstance()
    calendar.timeZone = TimeZone.getDefault()
    calendar.timeInMillis = timeInMillis
    val dateFormatter = SimpleDateFormat(mDateFormate, Locale.ENGLISH)
    return dateFormatter.format(calendar.time)
}

fun getLongTimestampToDate(timestamp: Long, timeFormat: String): String {
    val calendar = Calendar.getInstance(Locale.ENGLISH)
    calendar.timeZone = TimeZone.getTimeZone("GMT+5:30")
    calendar.timeInMillis = timestamp * 1000L
    return android.text.format.DateFormat.format(timeFormat, calendar).toString()
}

fun getUtC(millis: Long): Long {
    return millis + TimeZone.getDefault().rawOffset.toLong() + TimeZone.getDefault().dstSavings.toLong()
}

fun getGMT(millis: Long): Long {
    return millis - TimeZone.getDefault().rawOffset.toLong() - TimeZone.getDefault().dstSavings.toLong()
}

fun getDate(timeStamp: Long): String {
    val sdf = SimpleDateFormat("DD MMMM yyyy", Locale.getDefault())
    val netDate = Date(timeStamp * 1000)
    return sdf.format(netDate)
}

fun getDateTimeInMilliseconds(date: String): Long {
    val sdf = SimpleDateFormat("EEE MMM dd yyyy")
    val mDate = sdf.parse(date)
    return mDate.time
}

fun stringFromByte(inputStream: InputStream): String {
    val stringBuilder = StringBuilder()
    val bufferedReader = BufferedReader(InputStreamReader(inputStream))
    try {
        while (true) {
            val str = bufferedReader.readLine() ?: break
            stringBuilder.append(str)
        }
    } catch (localIOException: Exception) {
        localIOException.printStackTrace()
    }

    return inputStream.toString()
}

fun bytesToLong(bytes: ByteArray): Long {
    return ((bytes[7].toLong() shl 56) + (bytes[6].toLong() and 0xFF shl 48) + (bytes[5].toLong() and 0xFF shl 40) + (bytes[4].toLong() and 0xFF shl 32)
            + (bytes[3].toLong() and 0xFF shl 24) + (bytes[2].toLong() and 0xFF shl 16) + (bytes[1].toLong() and 0xFF shl 8) + (bytes[0].toLong() and 0xFF))
}

fun stringToBytes(str: String?): ByteArray {
    return when {
        str == null || str.isEmpty() -> ByteArray(0)
        else -> Base64.decode(str, Base64.DEFAULT)
    }
}

fun hexToBytes(hex: String?): ByteArray? {
    when (hex) {
        null -> return null
        else -> {
            val len = hex.length
            val data = ByteArray(len / 2)
            var i = 0
            while (i < len) {
                data[i / 2] = ((Character.digit(hex[i], 16) shl 4) + Character.digit(hex[i + 1], 16)).toByte()
                i += 2
            }
            return data
        }
    }
}

fun computeSHA256(convert: ByteArray, offset: Int, len: Int): ByteArray {
    val md = MessageDigest.getInstance("SHA-256")
    md.update(convert, offset, len)
    return md.digest()
}

fun <E> listRemoveDuplicates(list: List<E>): List<E> {
    val uniques = HashSet<E>()
    uniques.addAll(list)
    return ArrayList(uniques)
}

fun <E> linkedHashSetRemoveDuplicates(list: List<E>): List<E> {
    return ArrayList(LinkedHashSet(list))
}

fun isNotEmpty(list: List<*>?): Boolean {
    return list != null && !list.isEmpty()
}

fun <T> union(first: MutableList<T>, last: List<T>): List<*> {
    when {
        isNotEmpty(first) && isNotEmpty(last) -> {
            first.addAll(last)
            return first
        }
        isNotEmpty(first) && !isNotEmpty(last) -> return first
        else -> return last
    }
}

fun floatFormat2Digit(str: String): String {
    return String.format("%.02f", str)
}

fun discount(rs: Float, tax: Float): Float {
    return rs * tax / 100
}

fun roundValue(value: Float): Float {
    return Math.round(value).toFloat()
}

fun getToJson(src: Any): String {
    return GsonBuilder().create().toJson(src)
}

fun <T> getFromJson(str: String, classType: Class<T>): T {
    return Gson().fromJson(str, classType)
}

fun Activity.getPrettyPrintingJson(str: String) {
    //GsonBuilder().disableHtmlEscaping().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).setPrettyPrinting().serializeNulls().create()
    //GsonBuilder().excludeFieldsWithoutExposeAnnotation().create()
    logInfo(GsonBuilder().setPrettyPrinting().create().toJson(str))
}

fun <T> fromJson(file: File, clazz: Class<T>): T {
    return GsonBuilder().create().fromJson(FileReader(file.absoluteFile), clazz)
}

inline fun <reified T> Gson.fromJson(json: String) = this.fromJson<T>(json, object : TypeToken<T>() {}.type)!!

//TODO FILE SAVE
/*fun getImageFileFromSDCard(filename: String): Bitmap? {
    var bitmap: Bitmap? = null
    val imageFile = File(Environment.getExternalStorageDirectory().toString() + File.separator + filename)
    try {
        val fis = FileInputStream(imageFile)
        bitmap = BitmapFactory.decodeStream(fis)
    } catch (e: Exception) {
        e.printStackTrace()
    }

    return bitmap
}*/

fun Activity.saveImage(bitmap: Bitmap): String {
    val bytes = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes)
    val directory = File((Environment.getExternalStorageDirectory()).toString() + RestConstant.FOLDER_NAME)

    when {
        !directory.exists() -> directory.mkdirs()
    }

    val file = File(directory, ((Calendar.getInstance().timeInMillis).toString() + ".jpg"))
    file.createNewFile()
    val fo = FileOutputStream(file)
    fo.write(bytes.toByteArray())
    MediaScannerConnection.scanFile(this, arrayOf(file.path), arrayOf("image/jpeg"), null)
    fo.close()

    return file.absolutePath
}

fun decreaseImageSize(file: File): File? {
    val bitmapOptions = BitmapFactory.Options()
    bitmapOptions.inJustDecodeBounds = true
    bitmapOptions.inSampleSize = 6

    var inputStream = FileInputStream(file)
    BitmapFactory.decodeStream(inputStream, null, bitmapOptions)
    inputStream.close()

    val REQUIRED_SIZE = 75

    var scale = 1
    while (bitmapOptions.outWidth / scale / 2 >= REQUIRED_SIZE && bitmapOptions.outHeight / scale / 2 >= REQUIRED_SIZE) {
        scale *= 2
    }

    val o2 = BitmapFactory.Options()
    o2.inSampleSize = scale
    inputStream = FileInputStream(file)

    val selectedBitmap = BitmapFactory.decodeStream(inputStream, null, o2)
    inputStream.close()

    file.createNewFile()
    val outputStream = FileOutputStream(file)

    selectedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
    return file
}


//DISABLE SCREEN CAPTURE
fun Activity.disableScreenshotFunctionality() {
    window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
}

//TODO VALIDATION
var patternPassword = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$"
var patternBusinessName = "^[a-zA-Z0-9]+$"
var patternEmail = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
        "\\@" +
        "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
        "(" +
        "\\." +
        "[a-zA-Z]{2,8}" +
        ")+"
var patternName = "[a-zA-Z]{3,10}$"
var patternMobile = "^[0-9]{10,10}$"

fun isEmpty(str: String): Boolean {
    return StringUtils.isEmpty(str) || StringUtils.isBlank(str) || Strings.isNullOrEmpty(str)
}

fun isRegexValidator(str: String, expression: String): Boolean {
    val sensitive = RegexValidator(expression)
    return sensitive.isValid(str)
}

fun isEqual(strA: String, strB: String): Boolean {
    return StringUtils.equals(strA, strB)
}

fun range(str: String, start: Char, end: Char): String {
    return CharMatcher.inRange(start, end).retainFrom(str)
}

fun isLinkAvailable(link: String): Boolean {
    val pattern = Pattern.compile("^(http://|https://)?((?:[A-Za-z0-9]+-[A-Za-z0-9]+|[A-Za-z0-9]+)\\.)+([A-Za-z]+)[/\\?\\:]?.*$", Pattern.CASE_INSENSITIVE)
    val matcher = pattern.matcher(link)
    return matcher.matches()
}

fun removeAllWhiteSpace(value: String): String {
    return value.replace("\\s+".toRegex(), "")
}
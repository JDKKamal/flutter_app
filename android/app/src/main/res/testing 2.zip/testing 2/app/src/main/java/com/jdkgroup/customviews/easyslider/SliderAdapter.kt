package com.jdkgroup.customviews.easyslider

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter

class SliderAdapter(fm: FragmentManager, internal var sliderItems: List<SliderItem>) : FragmentPagerAdapter(fm) {

    override fun getItem(position: Int): Fragment {

        return SliderFragment.newInstance(sliderItems[position])
    }

    override fun getCount(): Int {
        return sliderItems.size
    }
}


package com.jdkgroup.view

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BaseView

interface SplashScreenView : BaseView {
    fun setSplashScreenWait()
}


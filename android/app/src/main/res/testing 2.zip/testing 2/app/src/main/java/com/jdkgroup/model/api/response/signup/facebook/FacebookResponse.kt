package com.jdkgroup.model.api.response.signup.facebook

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class FacebookResponse {
    @SerializedName("response")
    @Expose
    lateinit var response: Response
    @SerializedName("facebook_register")
    @Expose
    lateinit var facebookRegister: FacebookRegister
}
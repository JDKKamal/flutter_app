package com.jdkgroup.model;

public class ModelOrderStatus {
}

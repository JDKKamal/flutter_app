package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.view.View
import com.jdkgroup.baseclass.BaseActivity
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.hideSoftKeyboard
import kotlinx.android.synthetic.main.toolbar.*

class ContactUsActivity : BaseActivity(), View.OnClickListener{
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_us)

        hideSoftKeyboard()

        appTvTitle.text = getString(R.string.toolbar_title_contact_us)
        rlCount.visibility = View.GONE

        appIvDrawer.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
       when(v!!.id)
       {
           R.id.appIvDrawer ->  finish()
       }
    }
}

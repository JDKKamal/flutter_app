package com.jdkgroup.view

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BaseView
import com.jdkgroup.model.api.response.addtocart.cartlist.CartListResponse
import com.jdkgroup.model.api.response.login.LoginResponse

interface LoginView : BaseView {
    fun apiPostLoginResponse(response: LoginResponse)
    fun apiGetAddToCartListResponse(response: CartListResponse)
}
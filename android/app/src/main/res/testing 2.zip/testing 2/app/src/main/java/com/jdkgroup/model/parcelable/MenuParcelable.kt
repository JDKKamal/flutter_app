package com.jdkgroup.model.parcelable

import android.os.Parcel
import android.os.Parcelable

data class MenuParcelable(val cid: String, val categoryName: String, val categoryImage: String): Parcelable {

    constructor(source: Parcel):
            this(
            source.readString(),
            source.readString(),
            source.readString())

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest?.writeString(this.cid)
        dest?.writeString(this.categoryName)
        dest?.writeString(this.categoryImage)
    }

    companion object {
        @JvmField final val CREATOR: Parcelable.Creator<MenuParcelable> = object : Parcelable.Creator<MenuParcelable> {
            override fun createFromParcel(source: Parcel): MenuParcelable{
                return MenuParcelable(source)
            }

            override fun newArray(size: Int): Array<MenuParcelable?> {
                return arrayOfNulls(size)
            }
        }
    }
}
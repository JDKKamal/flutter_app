package com.jdkgroup.model.api.response.addtocart.cartlist

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CartList {

    @SerializedName("cart_id")
    @Expose
    lateinit var cartId: String
    @SerializedName("user_id")
    @Expose
    lateinit var userId: String
    @SerializedName("rest_id")
    @Expose
    lateinit var restId: String
    @SerializedName("menu_id")
    @Expose
    lateinit var menuId: String
    @SerializedName("menu_name")
    @Expose
    lateinit  var menuName: String
    @SerializedName("menu_image")
    @Expose
    lateinit var menuImage: String
    @SerializedName("menu_qty")
    @Expose
    lateinit var menuQty: String
    @SerializedName("menu_price")
    @Expose
    lateinit var menuPrice: String

}
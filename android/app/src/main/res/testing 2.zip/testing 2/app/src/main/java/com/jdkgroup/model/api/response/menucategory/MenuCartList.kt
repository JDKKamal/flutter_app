package com.jdkgroup.model.api.response.menucategory

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MenuCartList {

    @SerializedName("menu_id")
    @Expose
    lateinit var menuId: String
}
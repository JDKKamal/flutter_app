package com.jdkgroup.terasjawa.adapter.section;

import android.support.annotation.CallSuper;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.jdkgroup.customviews.section.SectionedRecyclerViewAdapter;
import com.jdkgroup.model.api.local.Faq;
import com.jdkgroup.terasjawa.R;

import java.util.List;

public abstract class SectionFaq extends SectionedRecyclerViewAdapter<SectionFaq.SubHeaderHolder, SectionFaq.MovieViewHolder> {

    public interface OnItemClickListener {
        void onItemClicked(Faq movie);
        void onSubHeaderClicked(int position);
    }

    public List<Faq> faqList;

    public OnItemClickListener onItemClickListener;

    public static class SubHeaderHolder extends RecyclerView.ViewHolder {

        public AppCompatTextView appTvHeaderTitle;
        public AppCompatImageView appIvExpandable;

        SubHeaderHolder(View itemView) {
            super(itemView);
            this.appTvHeaderTitle = itemView.findViewById(R.id.appTvHeaderTitle);
            this.appIvExpandable = itemView.findViewById(R.id.appIvExpandable);
        }
    }

    public static class MovieViewHolder extends RecyclerView.ViewHolder {

        public AppCompatTextView appTvQuestion;
        public AppCompatTextView appTvAnswer;

        MovieViewHolder(View itemView) {
            super(itemView);
            this.appTvQuestion = itemView.findViewById(R.id.appTvQuestion);
            this.appTvAnswer = itemView.findViewById(R.id.appTvAnswer);
        }
    }

    public SectionFaq(List<Faq> faqList) {
        super();
        this.faqList = faqList;
    }

    @Override
    public MovieViewHolder onCreateItemViewHolder(ViewGroup parent, int viewType) {
        return new MovieViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.itemview_faq_sub, parent, false));
    }

    @Override
    public SubHeaderHolder onCreateSubHeaderViewHolder(ViewGroup parent, int viewType) {
        return new SubHeaderHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.itemview_faq_header, parent, false));
    }

    @Override
    @CallSuper
    public void onBindSubHeaderViewHolder(SubHeaderHolder subHeaderHolder, int nextItemPosition) {

        boolean isSectionExpanded = isSectionExpanded(getSectionIndex(subHeaderHolder.getAdapterPosition()));

        if (isSectionExpanded) {
            subHeaderHolder.appIvExpandable.setImageDrawable(ContextCompat.getDrawable(subHeaderHolder.itemView.getContext(), R.drawable.ic_arrow_up_24dp));
        } else {
            subHeaderHolder.appIvExpandable.setImageDrawable(ContextCompat.getDrawable(subHeaderHolder.itemView.getContext(), R.drawable.ic_arrow_down_24dp));
        }

        subHeaderHolder.itemView.setOnClickListener(v -> onItemClickListener.onSubHeaderClicked(subHeaderHolder.getAdapterPosition()));

    }

    @Override
    public int getItemSize() {
        return faqList.size();
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }
}

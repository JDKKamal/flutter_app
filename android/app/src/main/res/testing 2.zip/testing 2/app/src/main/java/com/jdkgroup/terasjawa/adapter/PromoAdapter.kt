package com.jdkgroup.terasjawa.adapter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.Activity
import android.support.v4.content.ContextCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.recyclerview.BaseRecyclerView
import com.jdkgroup.customviews.recyclerview.BaseViewHolder
import com.jdkgroup.db.DBQuery
import com.jdkgroup.model.api.response.promo.PromoListCat
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.glideSetAppImageView
import kotlinx.android.synthetic.main.itemview_promo.view.*

class PromoAdapter(private val activity: Activity, private val menuCategoryList: MutableList<PromoListCat>) : BaseRecyclerView<PromoListCat>() {
    private val inflater: LayoutInflater = LayoutInflater.from(activity)

    private lateinit var listener: ItemListener

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): PromoListCat {
        return menuCategoryList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<PromoListCat> {
        return ViewHolder(inflater.inflate(R.layout.itemview_promo, parent, false))
    }

    override fun getItemCount(): Int {
        return menuCategoryList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<PromoListCat>(itemView) {
        var appBtnMenu = itemView.appBtnMenu!!
        var appIvMenu = itemView.appIvMenu!!
        var appTvTitle = itemView.appTvTitle!!
        var appTvPromo = itemView.appTvPromo!!
        var appTvPrice = itemView.appTvPrice!!
        var appRbMenu = itemView.appRbMenu!!

        override fun populateItem(t: PromoListCat) {
            appTvPrice.text = t.specialPrice
            appTvTitle.text = t.menuName
            appRbMenu.rating = java.lang.Float.valueOf(t.totalRate)
            appTvPromo.text = t.menuPrice
            activity.glideSetAppImageView(RestConstant.IMAGE_URL + t.menuImage, appIvMenu)

            val categoryList = DBQuery.with(activity).realmList(t.mid)
            when {
                categoryList.isNotEmpty() -> {
                    appBtnMenu.setTextColor(ContextCompat.getColor(activity, R.color.colorPesanMenu))
                    appBtnMenu.setBackgroundResource(R.drawable.style_add_to_card)
                    appBtnMenu.text = "Menu"
                }
                else -> {
                    appBtnMenu.setTextColor(ContextCompat.getColor(activity, R.color.colorPesanMenu))
                    appBtnMenu.setBackgroundResource(R.drawable.style_add_to_card_no)
                    appBtnMenu.text = "Ordered"
                }
            }

            itemView.setOnClickListener { listener.onClickPromo(menuCategoryList[layoutPosition]) }
        }
    }

    fun promoAddAll(listAdd: MutableList<PromoListCat>) {
        menuCategoryList.clear()
        menuCategoryList.addAll(listAdd)
        notifyDataSetChanged()
    }

    interface ItemListener {
        fun onClickPromo(promoListCat: PromoListCat)
    }
}

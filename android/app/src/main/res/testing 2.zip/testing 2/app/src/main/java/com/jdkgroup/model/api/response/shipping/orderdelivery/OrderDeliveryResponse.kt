package com.jdkgroup.model.api.response.shipping.orderdelivery

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.jdkgroup.model.api.Response

class OrderDeliveryResponse {
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("order_delivery_detail")
    @Expose
    var orderDeliveryDetail: OrderDeliveryDetail? = null

}
package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.view.View
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.AppInteractor
import com.jdkgroup.model.api.response.addtocart.cartlist.CartList
import com.jdkgroup.model.api.response.addtocart.cartlist.CartListResponse
import com.jdkgroup.model.parcelable.DeliveryParcelable
import com.jdkgroup.presenter.OrderSummaryPresenter
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.adapter.OrderDeliveryAdapter
import com.jdkgroup.utils.*
import com.jdkgroup.view.OrderSummaryView
import kotlinx.android.synthetic.main.activity_order_delivery.*
import kotlinx.android.synthetic.main.toolbar.*

class OrderDeliveryActivity : SimpleMVPActivity<OrderSummaryPresenter, OrderSummaryView>(), OrderSummaryView, OrderDeliveryAdapter.ItemListener {
    private lateinit var parcelableDelivery: List<DeliveryParcelable>
    private lateinit var orderDeliveryAdapter: OrderDeliveryAdapter

    private lateinit var appInteractor: AppInteractor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_delivery)

        hideSoftKeyboard()
        appInteractor = AppInteractor()
        appInteractor.getDeviceInfo(activity)

        setRecyclerView(recyclerView, 0, LINEARLAYOUT)

        appTvTitle.text = "Order Details".toUpperCase()

        val param = HashMap<String, String>()
        param[RestConstant.PARAM_USER_ID] = PreferenceUtils.preferenceInstance(this).userId
        presenter.apiCall(1, param, RestConstant.CALL_API_ADD_TO_CART_LIST)

        appBtnPayment.setOnClickListener {
            launchActivity(OrderActivity::class.java, EnumLaunchActivity.LaunchActivity)
        }

        /*findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener(object : SwipeRefreshLayout.OnRefreshListener {
            override fun onRefresh() {
                swipeRefreshLayout.isRefreshing = true
                Handler().postDelayed({
                    presenter.apiCall(activity, 0, param, RestConstant.CALL_API_ADD_TO_CART_LIST)
                }, 1000)
            }
        });*/

        parcelableDelivery = getParcelable(AppConstant.BUNDLE_PARCELABLE)
        when {
            parcelableDelivery.isNotEmpty() -> when {
                parcelableDelivery[0].status == 0 -> {
                    llTime.visibility = View.VISIBLE
                    //appIvOrder.setImageResource(R.drawable.order_bag)

                    appTvStatus.text = "Take Time"
                    appTvTitleOrder.text = parcelableDelivery[0].title
                    appTvEmail.text = PreferenceUtils.preferenceInstance(this).email
                    appTvMobile.text = parcelableDelivery[0].mobile
                    appTvTime.text = parcelableDelivery[0].address

                    appTvAddress.text = "Untuk menjamin citarasa dan kualitas masakan, Mohon diambil pada jam yang sudah di tentukan."

                }
                else -> {
                    llTime.visibility = View.GONE
                    appTvTitleOrder.text = parcelableDelivery[0].title
                    appTvAddress.text = parcelableDelivery[0].address + "\n" + parcelableDelivery[0].countryName.toLowerCase() + ", " + parcelableDelivery[0].districtName.toLowerCase()
                    appTvEmail.text = PreferenceUtils.preferenceInstance(this).email
                    appTvMobile.text = parcelableDelivery[0].mobile
                    appTvDeliveryService.text = java.lang.Double.valueOf(parcelableDelivery[0].deliveryService).toString()
                }
            }
        }

        appIvDrawer.setOnClickListener { activity.finish() }
    }

    override fun createPresenter(): OrderSummaryPresenter {
        return OrderSummaryPresenter()
    }

    override fun attachView(): OrderSummaryView {
        return this
    }

    override fun apiGetAddToCartListResponse(response: CartListResponse) {
        orderDeliveryAdapter = OrderDeliveryAdapter(activity, response.cartList)
        orderDeliveryAdapter.setOnListener(this)
        recyclerView.adapter = orderDeliveryAdapter
    }

    override fun onCartChange(grandTotal: Double, cartItems: CartList) {
        appTvTotal.text = grandTotal.toString()

        var tax: Double = grandTotal * 10 / 100

        appTvTax.text = tax.toString()
        val grandTotal = grandTotal + tax + appTvDeliveryService.text.toString().toDouble()
        appTvGradTotal.text = grandTotal.toString()
    }

    override fun onFailure(message: String) {
        showToast(message)
    }

    override fun onBackPressed() {
        finish()
    }
}

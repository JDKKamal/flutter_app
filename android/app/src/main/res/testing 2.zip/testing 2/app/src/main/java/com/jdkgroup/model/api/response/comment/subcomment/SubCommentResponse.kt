package com.jdkgroup.model.api.response.comment.subcomment

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SubCommentResponse {
    @SerializedName("response")
    @Expose
    var response: Response? = null
    @SerializedName("comment_lst")
    @Expose
    var commentLst: SubComment? = null

}
package com.jdkgroup.model.api.response.promo

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class PromoListCat {

    @SerializedName("mid")
    @Expose
    lateinit var mid: String
    @SerializedName("menu_name")
    @Expose
    lateinit var menuName: String
    @SerializedName("menu_info")
    @Expose
    lateinit var menuInfo: String
    @SerializedName("menu_price")
    @Expose
    lateinit var menuPrice: String
    @SerializedName("special_price")
    @Expose
    lateinit var specialPrice: String
    @SerializedName("total_rate")
    @Expose
    lateinit var totalRate: String
    @SerializedName("rate_avg")
    @Expose
    lateinit var rateAvg: String
    @SerializedName("menu_image")
    @Expose
    lateinit var menuImage: String
}

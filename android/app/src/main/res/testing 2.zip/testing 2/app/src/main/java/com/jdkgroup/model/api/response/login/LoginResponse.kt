package com.jdkgroup.model.api.response.login

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class LoginResponse{
    @SerializedName("response")
    @Expose
    lateinit var response: Response
    @SerializedName("login_detail")
    @Expose
    lateinit var loginDetail: LoginDetail

}
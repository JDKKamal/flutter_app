package com.jdkgroup.model.api.response.comment.commentview

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CommentViewResponse{
    @SerializedName("response")
    @Expose
    lateinit var response: Response
    @SerializedName("view_more_comment_list")
    @Expose
    lateinit var viewMoreCommentList: List<ViewMoreCommentList>
}
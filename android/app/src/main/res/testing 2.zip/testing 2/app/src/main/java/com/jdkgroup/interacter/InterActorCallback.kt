package com.jdkgroup.interacter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

interface InterActorCallback<T> {

    fun onStart()

    fun onResponse(response: T)

    fun onFinish()

    fun onError(message: String)
}

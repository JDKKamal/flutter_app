package com.jdkgroup.model.api.response.comment.commentlist

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CommentList {

    @SerializedName("count")
    @Expose
    var count: String
    @SerializedName("r_id")
    @Expose
    var rId: String
    @SerializedName("ip")
    @Expose
    var ip: String
    @SerializedName("rate")
    @Expose
    var rate: String
    @SerializedName("msg")
    @Expose
    var msg: String
    @SerializedName("name")
    @Expose
    var name: String
    @SerializedName("user_image")
    @Expose
    var userImage: String
    @SerializedName("like_unlike")
    @Expose
    var likeUnlike: Int

    constructor(count: String, rId: String, ip: String, rate: String, msg: String, name: String, userImage: String, likeUnlike: Int) {
        this.count = count
        this.rId = rId
        this.ip = ip
        this.rate = rate
        this.msg = msg
        this.name = name
        this.userImage = userImage
        this.likeUnlike = likeUnlike
    }
}
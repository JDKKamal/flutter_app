package com.jdkgroup.customviews.easyslider

import android.os.Bundle
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.LinearLayout
import com.jdkgroup.baseclass.BaseFragment
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.glideSetAppImageView

class SliderFragment : BaseFragment() {

    internal var item: SliderItem? = null
    internal lateinit var title_layout: LinearLayout
    internal lateinit var title: AppCompatTextView
    internal lateinit var imageView: AppCompatImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        item = arguments!!.getParcelable("item")
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.slider_item_container, container, false)
        title = rootView.findViewById(R.id.title)
        title_layout = rootView.findViewById(R.id.title_layout)
        imageView = rootView.findViewById(R.id.img)

        if (item!!.title != null) {
            title.text = item!!.title
            title_layout.visibility = View.VISIBLE
        } else {
            title_layout.visibility = View.GONE
        }

        if (item!!.resID != 0) {
            activity().glideSetAppImageView(item!!.resID, imageView)
        }

        if (item!!.url != null) {
            activity().glideSetAppImageView(item!!.url!!, imageView)
        }
        return rootView
    }

    fun showTitle() {
        val bottomUp = AnimationUtils.loadAnimation(context, R.anim.bottom_up)
        title_layout.startAnimation(bottomUp)
        title_layout.visibility = View.VISIBLE
    }

    fun hideTitle() {
        title_layout.visibility = View.GONE
    }

    companion object {

        fun newInstance(item: SliderItem): SliderFragment {
            val fragment = SliderFragment()
            val args = Bundle()
            args.putParcelable("item", item)
            fragment.arguments = args
            return fragment
        }
    }
}


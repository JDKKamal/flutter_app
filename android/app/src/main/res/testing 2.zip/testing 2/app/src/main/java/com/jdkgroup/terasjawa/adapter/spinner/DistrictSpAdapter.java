package com.jdkgroup.terasjawa.adapter.spinner;

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.content.Context;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.jdkgroup.model.api.response.shipping.district.DistrictList;
import com.jdkgroup.terasjawa.R;
import com.jdkgroup.terasjawa.spdialog.SpDialogDistrict;

import org.apache.commons.lang3.text.WordUtils;

import java.util.ArrayList;
import java.util.List;

public class DistrictSpAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context context;
    private List searchList = new ArrayList<>();

    private List alList = new ArrayList<>();
    SpDialogDistrict.OnItemClick itemSelect;

    public DistrictSpAdapter(Context context, List<?> alList, SpDialogDistrict.OnItemClick itemSelect) {

        this.context = context;
        this.alList = alList;
        this.searchList.addAll(alList);
        this.itemSelect = itemSelect;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.itemview_sp_country, parent, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ((ViewHolder) holder).setData(position);
    }

    @Override
    public int getItemCount() {
        return alList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        AppCompatTextView appTvTitle;
        int position;

        public ViewHolder(View itemView) {
            super(itemView);
            appTvTitle = itemView.findViewById(R.id.appTvTitle);

            itemView.setOnClickListener(v -> itemSelect.selectedItem(alList.get(getAdapterPosition())));
        }

        public void setData(int position) {
            this.position = position;
            if (alList.get(position) instanceof DistrictList) {
                DistrictList district = (DistrictList) alList.get(position);
                appTvTitle.setText(WordUtils.capitalizeFully(district.getStateName()));
            }
        }
    }

    public void filter(String text) {
        alList.clear();
        if (text.isEmpty()) {
            alList.addAll(searchList);
        } else {
            text = text.toLowerCase();

            if (searchList.get(0) instanceof DistrictList) {
                for (int i = 0; i < searchList.size(); i++) {
                    DistrictList districtModel = (DistrictList) searchList.get(i);
                    if (districtModel.getStateName().toLowerCase().contains(text)) {
                        alList.add(districtModel);
                    }
                }
            }
        }
        notifyDataSetChanged();
    }
}
package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.model.api.response.comment.commentview.CommentViewResponse
import com.jdkgroup.model.parcelable.CommentParcelable
import com.jdkgroup.presenter.CommentViewPresenter
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.adapter.CommentViewAdapter
import com.jdkgroup.utils.*
import com.jdkgroup.view.CommentView
import kotlinx.android.synthetic.main.activity_comment_view.*
import kotlinx.android.synthetic.main.toolbar.*
import java.util.*

class CommentViewActivity : SimpleMVPActivity<CommentViewPresenter, CommentView>(), CommentView {
    private lateinit var parcelableComment: List<CommentParcelable>
    private lateinit var commentViewAdapter: CommentViewAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comment_view)

        hideSoftKeyboard()

        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem
        setRecyclerView(recyclerView, 0, LINEARLAYOUT)

        parcelableComment = getParcelable(AppConstant.BUNDLE_PARCELABLE)
        when {
            parcelableComment.isNotEmpty() -> {
                appTvTitle.text = parcelableComment[0].categoryName

                val param: HashMap<String, String> = hashMapOf(RestConstant.PARAM_VIEW_MORE_COMMENT to parcelableComment[0].mId)
                presenter.apiCall(param, RestConstant.CALL_API_COMMENT_VIEW)
            }
        }

        appIvDrawer.setOnClickListener { activity.finish() }
    }

    override fun onResume() {
        super.onResume()
        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem
    }

    override fun createPresenter(): CommentViewPresenter {
        return CommentViewPresenter()
    }

    override fun attachView(): CommentView {
        return this
    }

    override fun apiGetCommentViewResponse(response: CommentViewResponse) {
        when {
            response.response.code == RestConstant.OK_200 -> {
                commentViewAdapter = CommentViewAdapter(this, response.viewMoreCommentList)
                recyclerView.adapter = commentViewAdapter
            }
            else -> showToast(response.response.message!!)
        }
    }

    override fun onFailure(message: String) {
        showToast(message)
    }
}

package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.socialintegration.facebookintegration.FacebookLoginHelper
import com.jdkgroup.customviews.socialintegration.facebookintegration.FacebookLoginListener
import com.jdkgroup.customviews.socialintegration.facebookintegration.FacebookLoginModel
import com.jdkgroup.customviews.socialintegration.googleintegration.GoogleLoginHelper
import com.jdkgroup.customviews.socialintegration.googleintegration.GoogleLoginListener
import com.jdkgroup.customviews.socialintegration.googleintegration.GoogleLoginModel
import com.jdkgroup.customviews.socialintegration.twitterintegration.TwitterHelper
import com.jdkgroup.customviews.socialintegration.twitterintegration.TwitterListener
import com.jdkgroup.customviews.socialintegration.twitterintegration.TwitterUser
import com.jdkgroup.db.DBQuery
import com.jdkgroup.interacter.AppInteractor
import com.jdkgroup.model.api.Response
import com.jdkgroup.model.api.request.LoginRequest
import com.jdkgroup.model.api.response.addtocart.cartlist.CartListResponse
import com.jdkgroup.model.api.response.login.LoginResponse
import com.jdkgroup.model.db.CategoryListRealm
import com.jdkgroup.presenter.LoginPresenter
import com.jdkgroup.terasjawa.*
import com.jdkgroup.utils.EnumLaunchActivity
import com.jdkgroup.utils.hideSoftKeyboard
import com.jdkgroup.utils.launchActivity
import com.jdkgroup.utils.showToast
import com.jdkgroup.view.LoginView
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.include_social.*
import java.util.*

class LoginActivity : SimpleMVPActivity<LoginPresenter, LoginView>(), LoginView, FacebookLoginListener, GoogleLoginListener, TwitterListener, View.OnClickListener {

    private lateinit var facebookLoginHelper: FacebookLoginHelper
    private lateinit var googleLoginHelper: GoogleLoginHelper
    private lateinit var appInteractor: AppInteractor
    private lateinit var twitterHelper: TwitterHelper

    private var loginStatus: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        hideSoftKeyboard()
        appInteractor = AppInteractor()
        //TODO SOCIAL LOGIN
        facebookLoginHelper = FacebookLoginHelper(this)
        googleLoginHelper = GoogleLoginHelper(this, this, RestConstant.SOCIAL_GOOGLE_ID)
        twitterHelper = TwitterHelper(R.string.twitter_api_key, R.string.twitter_secrate_key, this, this)

        appBtnLogin.setOnClickListener(this)
        appTvForgotPassword.setOnClickListener(this)
        appTvSignUp.setOnClickListener(this)
        appIvSocialFacebook.setOnClickListener(this)
        appIvSocialTwitter.setOnClickListener(this)
        appIvSocialGooglePlus.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appBtnLogin -> {
                val email = appEdtEmail.text.toString()
                val password = appEdtPassword.text.toString()

                presenter.validation(email, password)
                loginStatus = RestConstant.LOGIN_SIMPLE_STATUS
            }

            R.id.appTvForgotPassword -> {
                var intentOperation = ForgotPassword(activity)
                execute(intentOperation)
            }

            R.id.appTvSignUp -> {
                var intentOperation = SignUpIntent(activity)
                execute(intentOperation)
            }

            R.id.appIvSocialFacebook -> {
                var intentOperation = facebookLoginHelper.let { FacebookLogin(activity, it) }
                execute(intentOperation)
            }

            R.id.appIvSocialTwitter -> {
                var intentOperation = twitterHelper.let { TwitterLogin(it) }
                execute(intentOperation)
            }

            R.id.appIvSocialGooglePlus -> {
                var intentOperation = googleLoginHelper.let { GooglePlusLogin(activity, it) }
                execute(intentOperation)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        var intentOperation = ActivityResultSocialLogin(googleLoginHelper, facebookLoginHelper, twitterHelper, requestCode, resultCode, data!!)
        execute(intentOperation)
    }

    override fun createPresenter(): LoginPresenter {
        return LoginPresenter()
    }

    override fun attachView(): LoginView {
        return this
    }

    override fun onFbSignInFail(errorMessage: String) {}

    override fun onFbSignInSuccess(facebookLoginModel: FacebookLoginModel) {
        loginStatus = RestConstant.LOGIN_FACEBOOK_STATUS
        presenter.apiCall(RestConstant.CALL_LOGIN_SOCIAL, LoginRequest(facebookLoginModel.email, ""))
    }

    override fun onFBSignOut() {}

    override fun onGoogleAuthSignIn(googleLoginModel: GoogleLoginModel) {
        loginStatus = RestConstant.LOGIN_GOOGLE_PLUS_STATUS
        presenter.apiCall(RestConstant.CALL_LOGIN_SOCIAL, LoginRequest(googleLoginModel.email!!, ""))
    }

    override fun onGoogleAuthSignInFailed(errorMessage: String) {}

    override fun onGoogleAuthSignOut() {}

    override fun onTwitterError() {}

    override fun onTwitterSignIn(userId: String, userName: String) {}

    override fun onTwitterProfileReceived(user: TwitterUser) {
        loginStatus = RestConstant.LOGIN_TWITTER_STATUS
        //presenter!!.apiCall(this, RestConstant.CALL_LOGIN_SOCIAL, LoginRequest(twitterUser!!.email!!, ""))
    }

    override fun apiPostLoginResponse(response: LoginResponse) {
        val responseCheck = response.response
        showToast(responseCheck.message)
        when {
            responseManage(responseCheck) -> {
                var intentOperation = Login(activity, response, this.loginStatus)
                execute(intentOperation)

                launchActivity(DrawerActivity::class.java, EnumLaunchActivity.LaunchActivity)
                finish()
            }
            else -> appEdtPassword.text = null
        }
    }

    override fun apiGetAddToCartListResponse(response: CartListResponse) {
        DBQuery.with(this).realmDeleteTable(CategoryListRealm::class.java)
        when {
            response.response.code == RestConstant.NOT_FOUND_404 -> {
            }
            else -> response.cartList.forEach { cartList -> DBQuery.with(this).realmInsert(CategoryListRealm(UUID.randomUUID().toString(), cartList.menuId)) }
        }

        var intentOperation = DrawerIntentLogin(activity, response)
        execute(intentOperation)
    }

    override fun onFailure(message: String) {
        showToast(message)
    }

    override fun onBackPressed() {
        appExit()
    }
}
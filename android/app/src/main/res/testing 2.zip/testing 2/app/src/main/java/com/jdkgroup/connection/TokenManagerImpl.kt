package com.jdkgroup.connection

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.content.Context
import com.jdkgroup.utils.PreferenceUtils

class TokenManagerImpl(private val context: Context) : TokenManager {

    override //TOKEN SET
    val token: String
        get() = PreferenceUtils.preferenceInstance(context).deviceToken

    override fun hasToken(): Boolean {
        //TOKEN CHECK
        return PreferenceUtils.preferenceInstance(context).isToken
    }

    override fun clearToken() {
        //TOKEN CLEAR
        PreferenceUtils.preferenceInstance(context).deviceToken = ""
    }

    @Synchronized
    override fun refreshToken() {
        //TOKEN REFRESH
    }
}

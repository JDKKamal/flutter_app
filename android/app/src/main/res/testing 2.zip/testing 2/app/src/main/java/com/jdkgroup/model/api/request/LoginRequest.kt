package com.jdkgroup.model.api.request


data class LoginRequest(val email: String,  @Volatile var password: String)

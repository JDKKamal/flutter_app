package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.support.v7.widget.AppCompatCheckBox
import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.request.SignUpRequest
import com.jdkgroup.model.api.response.signup.SignUpResponse
import com.jdkgroup.model.api.response.signup.facebook.FacebookResponse
import com.jdkgroup.model.api.response.signup.gmail.GmailSignUpResponse
import com.jdkgroup.model.api.response.signup.twitter.TwitterSignUpResponse
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.*
import com.jdkgroup.view.SignUpView

class SignUpPresenter : BasePresenter<SignUpView>() {
    private fun callApiPostSignUp(params: HashMap<String, String>) {
        appInteractor.apiPostSignUp(view.activity(), params, object : InterActorCallback<SignUpResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: SignUpResponse) {
                view.apiPostSignUpResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }

        })
    }

    private fun callApiPostFacebookSignUp(params: HashMap<String, String>) {
        appInteractor.apiPostFacebookSignUp(view.activity(), params, object : InterActorCallback<FacebookResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: FacebookResponse) {
                view.apiPostFacebookSignUpResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }

        })
    }

    private fun callApiPostGooglePlusSignUp(params: HashMap<String, String>) {
        appInteractor.apiPostGooglePlusSignUp(view.activity(), params, object : InterActorCallback<GmailSignUpResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: GmailSignUpResponse) {
                view.apiPostGooglePlusSignUpResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }

        })
    }

    private fun callApiPostTwitterSignUp(params: HashMap<String, String>) {
        appInteractor.apiPostTwitterSignUp(view.activity(), params, object : InterActorCallback<TwitterSignUpResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: TwitterSignUpResponse) {
                view.apiPostTwitterPlusSignUpResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }

        })
    }

    fun apiCall(apiNo: Int, signUpRequest: SignUpRequest) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_REGISTER -> {
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_NAME] = signUpRequest.name!!
                    param[RestConstant.PARAM_EMAIL] = signUpRequest.email!!.toLowerCase()
                    param[RestConstant.PARAM_PHONE] = signUpRequest.mobile!!
                    param[RestConstant.PARAM_PASSWORD] = signUpRequest.password!!
                    callApiPostSignUp(param)
                }
                RestConstant.CALL_API_FACEBOOK_REGISTER -> {
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_NAME] = signUpRequest.name!!
                    param[RestConstant.PARAM_EMAIL] = signUpRequest.email!!.toLowerCase()
                    param[RestConstant.PARAM_PHONE] = signUpRequest.mobile!!
                    param[RestConstant.PARAM_FACEBOOK_ID] = signUpRequest.password!!
                    callApiPostFacebookSignUp(param)
                }
                RestConstant.CALL_API_GOOGLE_PLUS_REGISTER -> {
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_NAME] = signUpRequest.name!!
                    param[RestConstant.PARAM_EMAIL] = signUpRequest.email!!.toLowerCase()
                    param[RestConstant.PARAM_PHONE] = signUpRequest.mobile!!
                    param[RestConstant.PARAM_GOOGLE_PLUS_ID] = signUpRequest.password!!
                    callApiPostGooglePlusSignUp(param)
                }
                RestConstant.CALL_API_TWITTER_REGISTER -> {
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_NAME] = signUpRequest.name!!
                    param[RestConstant.PARAM_EMAIL] = signUpRequest.email!!.toLowerCase()
                    param[RestConstant.PARAM_PHONE] = signUpRequest.mobile!!
                    param[RestConstant.PARAM_TWITTER_ID] = signUpRequest.password!!
                    callApiPostTwitterSignUp(param)
                }
            }
        }
    }

    //TODO VALIDATION
    fun validation(name: String, email: String, mobile: String, password: String, appCBTermsCondition: AppCompatCheckBox) {
        return when {
            isEmpty(name) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_name))
            }
            isEmpty(email) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_email))
            }
            !isRegexValidator(email, patternEmail) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_valid_email))
            }
            isEmpty(mobile) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_mobile))
            }
            isEmpty(password) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_password))
            }
            !appCBTermsCondition.isChecked ->
                view.activity().showToast(view.activity().getString(R.string.msg_check_not_terms))
            else -> apiCall(RestConstant.CALL_API_REGISTER, SignUpRequest(name, email, mobile, password))
        }
    }
    //FINISH VALIDATION
}

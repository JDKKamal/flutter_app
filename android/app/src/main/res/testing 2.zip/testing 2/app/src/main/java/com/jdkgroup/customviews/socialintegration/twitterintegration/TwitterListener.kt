package com.jdkgroup.customviews.socialintegration.twitterintegration

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

interface TwitterListener {
    fun onTwitterError()
    fun onTwitterSignIn(userId: String, userName: String)
    fun onTwitterProfileReceived(user: TwitterUser)
}
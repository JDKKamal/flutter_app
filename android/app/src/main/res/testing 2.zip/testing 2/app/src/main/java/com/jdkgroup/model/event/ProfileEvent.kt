package com.jdkgroup.model.event

class ProfileEvent(val userProfile: String)

package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.response.comment.commentview.CommentViewResponse
import com.jdkgroup.utils.EnumProgressBar
import com.jdkgroup.view.CommentView
import kotlin.collections.HashMap

class CommentViewPresenter : BasePresenter<CommentView>() {
    private fun callApiGetCommentView(params: HashMap<String, String>) {
        appInteractor.apiGetCommentView(view.activity(), params, object : InterActorCallback<CommentViewResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: CommentViewResponse) {
                view.apiGetCommentViewResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }
        })
    }

    internal fun apiCall(params: HashMap<String, String>, apiNo: Int) {
        when {
            hasInternet() ->
                when (apiNo) {
                    RestConstant.CALL_API_COMMENT_VIEW -> callApiGetCommentView(params)
                }
        }
    }
}

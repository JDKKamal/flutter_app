package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.request.DistrictRequest
import com.jdkgroup.model.api.request.OrderDeliveryRequest
import com.jdkgroup.model.api.response.shipping.country.CountryResponse
import com.jdkgroup.model.api.response.shipping.district.DistrictResponse
import com.jdkgroup.model.api.response.shipping.orderdelivery.OrderDeliveryResponse
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.EnumProgressBar
import com.jdkgroup.utils.isEmpty
import com.jdkgroup.utils.showToast
import com.jdkgroup.view.OpsiPengirimanView

class OpsiPengirimanPresenter : BasePresenter<OpsiPengirimanView>() {
    private fun callApiGetCountry() {
        appInteractor.apiGetCountry(view.activity(), object : InterActorCallback<CountryResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: CountryResponse) {
                view.apiGetCountryResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }

        })
    }

    private fun callApiGetDistrict(params: HashMap<String, String>) {
        appInteractor.apiGetDistrict(view.activity(), params, object : InterActorCallback<DistrictResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: DistrictResponse) {
                view.apiGetDistrictResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }

        })
    }

    private fun callApiPostOrderDelivery(params: HashMap<String, String>) {
        appInteractor.apiPostOrderDelivery(view.activity(), params, object : InterActorCallback<OrderDeliveryResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: OrderDeliveryResponse) {
                view.apiPostOrderDeliveryResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }

        })
    }

    fun apiCall(apiNo: Int, districtRequest: DistrictRequest?, orderDeliveryRequest: OrderDeliveryRequest?) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_COUNTRY -> callApiGetCountry()
                RestConstant.CALL_API_DISTRICT -> {
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_DISTRICT_CAT] = districtRequest!!.countryid
                    callApiGetDistrict(param)
                }
                RestConstant.CALL_API_ORDER_DELIVERY -> {
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_USER_ID] = orderDeliveryRequest!!.userid
                    param[RestConstant.PARAM_TITLE_NAME] = orderDeliveryRequest.title
                    param[RestConstant.PARAM_FULL_NAME] = orderDeliveryRequest.fullname
                    param[RestConstant.PARAM_MOBILE_NUMBER] = orderDeliveryRequest.mobile
                    param[RestConstant.PARAM_ADDRESS] = orderDeliveryRequest.address
                    param[RestConstant.PARAM_COUNTRY_ID] = orderDeliveryRequest.countryid
                    param[RestConstant.PARAM_STATE_ID] = orderDeliveryRequest.stateid

                    callApiPostOrderDelivery(param)
                }
            }
        }
    }

    fun validation(title: String, fullName: String, address: String, country: String, district: String, districtDeliveryService: String, mobile: String): Boolean {
        return when {
            isEmpty(title) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_title_order))
                false
            }
            isEmpty(fullName) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_full_name_order))
                false
            }
            isEmpty(address) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_address))
                false
            }
            isEmpty(country) -> {
                view.activity().showToast("Select country")
                false
            }
            isEmpty(districtDeliveryService) -> {
                view.activity().showToast("Select district")
                false
            }
            isEmpty(mobile) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_mobile))
                false
            }
            else -> true
        }
    }

}

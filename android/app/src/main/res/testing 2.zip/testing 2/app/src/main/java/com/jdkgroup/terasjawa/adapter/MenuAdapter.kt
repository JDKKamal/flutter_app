package com.jdkgroup.terasjawa.adapter

/*
   DEVELOPED BY restaurant Solution
   info@restaurant.com
   +91 9601501313
*/

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.recyclerview.BaseRecyclerView
import com.jdkgroup.customviews.recyclerview.BaseViewHolder
import com.jdkgroup.model.api.response.menu.MenuList
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.glideSetAppImageView
import kotlinx.android.synthetic.main.itemview_menu.view.*
import java.util.*
import kotlin.collections.ArrayList

class MenuAdapter(private val activity: Activity, private val menuList: MutableList<MenuList>) : BaseRecyclerView<MenuList>() {

    private val searchList: MutableList<MenuList>
    private val inflater: LayoutInflater = LayoutInflater.from(activity)
    private lateinit var listener: ItemListener

    init {
        this.searchList = ArrayList()
        this.searchList.addAll(menuList)
    }

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): MenuList {
        return menuList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<MenuList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_menu, parent, false))
    }

    override fun getItemCount(): Int {
        return menuList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<MenuList>(itemView) {
        val appTvTitle = itemView.appTvTitle!!
        val appIvMenuIcon = itemView.appIvMenuIcon!!
        val appRbMenu = itemView.appRbMenu!!

        override fun populateItem(t: MenuList) {
            appTvTitle.text = t.categoryName
            appRbMenu.rating = t.rateAvg.toFloat()

            activity.glideSetAppImageView(RestConstant.IMAGE_URL + t.categoryImage, appIvMenuIcon)
            itemView.setOnClickListener { listener.onClickMenu(menuList[layoutPosition]) }
        }
    }

    //TODO FILTER
    fun filter(charText: String) {
        var charText = charText
        charText = charText.toLowerCase(Locale.getDefault())
        menuList.clear()

        when {
            charText.isEmpty() -> menuList.addAll(searchList)
            else -> searchList.forEach { search ->
                if (search.categoryName.toLowerCase(Locale.getDefault()).contains(charText)) {
                    menuList.add(search)
                }
            }
        }
        notifyDataSetChanged()
    }

    interface ItemListener {
        fun onClickMenu(modelMenu: MenuList)
    }
}

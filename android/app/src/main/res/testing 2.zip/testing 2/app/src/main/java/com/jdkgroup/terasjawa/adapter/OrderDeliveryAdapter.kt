package com.jdkgroup.terasjawa.adapter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.recyclerview.BaseRecyclerView
import com.jdkgroup.customviews.recyclerview.BaseViewHolder
import com.jdkgroup.model.api.response.addtocart.cartlist.CartList
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.glideSetAppImageView
import kotlinx.android.synthetic.main.itemview_order_delivery.view.*

class OrderDeliveryAdapter(private val activity: Activity, private val profiles: List<CartList>) : BaseRecyclerView<CartList>() {
    private val inflater: LayoutInflater = LayoutInflater.from(activity)

    private lateinit var listener: ItemListener

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): CartList {
        return profiles[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<CartList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_order_delivery, parent, false))
    }

    override fun getItemCount(): Int {
        return profiles.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<CartList>(itemView) {
        var appIvMenuIcon = itemView.appIvMenuIcon!!
        var appTvTitle = itemView.appTvTitle!!
        var appTvQuantity = itemView.appTvQuantity!!
        var appTvPrice = itemView.appTvPrice!!

        override fun populateItem(t: CartList) {
            activity.glideSetAppImageView(RestConstant.IMAGE_URL + t.menuImage, this.appIvMenuIcon)
            appTvTitle.text = t.menuName
            appTvQuantity.text = "Quantity - ${t.menuQty}"

            val qtyCal = profiles[layoutPosition].menuQty.toDouble()
            val priceCal = profiles[layoutPosition].menuPrice.toDouble()
            appTvPrice.text = (qtyCal * priceCal).toString()

            updateTotal(layoutPosition)
        }
    }

    fun updateTotal(position: Int) {
        var grandTotal = 0.00
        profiles.forEach { product ->
            val qty = product.menuQty.toDouble()
            val price = product.menuPrice.toDouble()
            grandTotal += qty * price
        }
        listener.onCartChange(grandTotal, profiles[position])

    }

    interface ItemListener {
        fun onCartChange(grandTotal: Double, cartItems: CartList)
    }
}

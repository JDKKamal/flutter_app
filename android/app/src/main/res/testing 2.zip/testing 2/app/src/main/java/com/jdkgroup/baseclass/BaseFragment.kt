package com.jdkgroup.baseclass

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Point
import android.os.Bundle
import android.os.Environment
import android.support.v4.app.Fragment
import android.support.v7.widget.*
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import com.google.gson.FieldNamingPolicy
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.jdkgroup.interacter.disposablemanager.DisposableManager
import com.jdkgroup.utils.EnumProgressBar
import com.jdkgroup.utils.checkProgressBar
import com.jdkgroup.utils.logError
import java.io.File
import java.io.FileReader
import java.util.*

abstract class BaseFragment : Fragment() {

    private var progressDialog: Dialog? = null
    private lateinit var params: HashMap<String, String>
    private lateinit var calendar: Calendar

    //TODO PROGRESSBAR DIALOG
    fun showProgressDialog(enumProgressBar: EnumProgressBar) {
        activity().checkProgressBar(enumProgressBar)
    }

    val defaultParam: HashMap<String, String>
        get() {
            params = HashMap()
            return params
        }

    val defaultParamWithIdAndToken: HashMap<String, String>
        get() {
            params = defaultParam
            return params
        }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        retainInstance = true
    }

    override fun onDestroyView() {
        DisposableManager.dispose()
        super.onDestroyView()
    }

    fun activity(): Activity {
        return this.activity!!
    }
}
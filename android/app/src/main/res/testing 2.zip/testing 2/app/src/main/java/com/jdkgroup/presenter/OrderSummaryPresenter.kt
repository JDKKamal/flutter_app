package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.response.addtocart.cartlist.CartListResponse
import com.jdkgroup.utils.EnumProgressBar
import com.jdkgroup.view.OrderSummaryView
import kotlin.collections.HashMap

class OrderSummaryPresenter : BasePresenter<OrderSummaryView>() {
    private fun callApiGetAddToCartList(swipeRefreshStatus: Int, params: HashMap<String, String>) {
        appInteractor.apiGetAddToCartList(view.activity(), params, object : InterActorCallback<CartListResponse> {
            override fun onStart() {
                if (swipeRefreshStatus == 1) {
                    view.showProgressDialog(EnumProgressBar.Show)
                }
            }

            override fun onResponse(response: CartListResponse) {
                view.apiGetAddToCartListResponse(response)
            }

            override fun onFinish() {
                if (swipeRefreshStatus == 1) {
                    view.showProgressDialog(EnumProgressBar.Hide)
                }
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }

        })
    }

    fun apiCall(swipeRefreshStatus: Int, params: HashMap<String, String>, apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_ADD_TO_CART_LIST -> callApiGetAddToCartList(swipeRefreshStatus, params)
            }
        }
    }
}

package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.response.menu.MenuResponse
import com.jdkgroup.utils.EnumProgressBar
import com.jdkgroup.view.MenuView

class MenuPresenter : BasePresenter<MenuView>() {
    private fun callApiGetMenu(swipeRefreshStatus: Int) {
        appInteractor.apiGetMenu(view.activity(), object : InterActorCallback<MenuResponse> {
            override fun onStart() {
                if (swipeRefreshStatus == 1) {
                    view.showProgressDialog(EnumProgressBar.Show)
                }
            }

            override fun onResponse(response: MenuResponse) {
                view.apiPostMenuResponse(response)
            }

            override fun onFinish() {
                if (swipeRefreshStatus == 1) {
                    view.showProgressDialog(EnumProgressBar.Hide)
                }
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }

        })
    }

    fun apiCall(swipeRefreshStatus: Int, apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_MENU -> callApiGetMenu(swipeRefreshStatus)
            }
        }
    }
}

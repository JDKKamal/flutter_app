package com.jdkgroup.customviews.savepref

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

class FastException(message: String) : RuntimeException(message)

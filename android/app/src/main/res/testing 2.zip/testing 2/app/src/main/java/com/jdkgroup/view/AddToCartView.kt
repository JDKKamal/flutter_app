package com.jdkgroup.view

/*
   DEVELOPED BY KAMLESH LAKHANI
   info@bytotech.com
   +91 9601501313
*/

import com.jdkgroup.model.api.response.addtocart.cartlist.CartListResponse
import com.jdkgroup.baseclass.BaseView
import com.jdkgroup.model.api.response.DefaultResponse

interface AddToCartView : BaseView
{
    fun apiGetAddToCartListResponse(response: CartListResponse)
    fun apiGetDeleteItemResponse(response: DefaultResponse)
    fun apiGetUpdateItemResponse(response: DefaultResponse)

}

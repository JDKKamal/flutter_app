package com.jdkgroup.customviews.easyslider

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.support.v4.view.ViewPager
import android.text.Html
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView

import com.jdkgroup.terasjawa.R

import java.util.ArrayList

class EasySlider(context: Context, attrs: AttributeSet) : RelativeLayout(context, attrs) {
    private lateinit var root: View
    internal lateinit var pager: ViewPager
    private val sliderItems = ArrayList<SliderItem>()
    private var mSectionsPagerAdapter: SliderAdapter? = null
    private var counter = 3000
    private lateinit var dotsLayout: LinearLayout
    private lateinit var dots: Array<TextView?>
    private var active = -1
    private val isFirstSwipe = true

    init {
        init(context)
    }

    private fun init(context: Context) {
        root = View.inflate(context, R.layout.slider_content, this)
        pager = root.findViewById(R.id.pager)
        dotsLayout = root.findViewById(R.id.dots_layout)

        pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                switchDots(position, active)
                val newfragment = mSectionsPagerAdapter!!.instantiateItem(pager, position) as SliderFragment

                when {
                    active != -1 -> {
                        val oldFragment = mSectionsPagerAdapter!!.instantiateItem(pager, active) as SliderFragment
                        oldFragment.hideTitle()
                    }
                }
                newfragment.showTitle()
                active = position
            }

            override fun onPageSelected(position: Int) {}

            override fun onPageScrollStateChanged(state: Int) {}
        })
    }

    private fun switchDots(position: Int, active: Int) {
        when {
            active != -1 -> {
                val oldPosition = dotsLayout.getChildAt(active) as TextView
                val newPosition = dotsLayout.getChildAt(position) as TextView
                oldPosition.setTextColor(Color.parseColor("#50ffffff"))
                newPosition.setTextColor(Color.WHITE)
            }
        }
    }

    fun setPages(sliderItems: List<SliderItem>) {
        this.sliderItems.clear()
        this.sliderItems.addAll(sliderItems)
        mSectionsPagerAdapter = SliderAdapter((context as android.support.v4.app.FragmentActivity).supportFragmentManager, sliderItems)
        when {
            sliderItems.isNotEmpty() -> {
                pager.adapter = mSectionsPagerAdapter
                pager.offscreenPageLimit = sliderItems.size
            }
        }

        val handler = Handler()
        handler.postDelayed(object : Runnable {
            override fun run() {
                try {
                    when {
                        min < mSectionsPagerAdapter!!.sliderItems.size -> {
                            pager.currentItem = min
                            min++
                        }
                        else -> {
                            min = 0
                            pager.currentItem = min
                        }
                    }
                } catch (e: Exception) { }
                handler.postDelayed(this, counter.toLong())
            }
        }, counter.toLong())

        initDots()
    }

    private fun initDots() {
        dotsLayout.removeAllViews()
        dots = arrayOfNulls(sliderItems.size)
        dots.indices.forEach { i ->
            dots[i] = TextView(context)
            dots[i]!!.text = Html.fromHtml("&#8226;")
            dots[i]!!.textSize = 30f
            if (i != 0) {
                dots[i]!!.setTextColor(Color.parseColor("#50ffffff"))
            } else {
                dots[i]!!.setTextColor(Color.WHITE)
            }
            dotsLayout.addView(dots[i])
        }
    }

    fun setTimer(timer: Int) {
        try {
            when {
                timer >= 1000 -> this.counter = timer
                else -> throw Exception()
            }
        } catch (timer1: Exception) {
            Log.d("Slider error", "timer must be equals or greater than 1 second ")
        }
    }

    companion object {
        internal var min = 1
    }
}

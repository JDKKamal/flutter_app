package com.jdkgroup.terasjawa.fragment

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.jdkgroup.baseclass.MVPFragment
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.AppEditTextChangedListener
import com.jdkgroup.model.api.response.menu.MenuList
import com.jdkgroup.model.api.response.menu.MenuResponse
import com.jdkgroup.model.parcelable.MenuParcelable
import com.jdkgroup.presenter.MenuPresenter
import com.jdkgroup.terasjawa.MenuClick
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.adapter.MenuAdapter
import com.jdkgroup.terasjawa.execute
import com.jdkgroup.utils.GRIDLAYOUT
import com.jdkgroup.utils.hideSoftKeyboard
import com.jdkgroup.utils.setRecyclerView
import com.jdkgroup.utils.showToast
import com.jdkgroup.view.MenuView
import kotlinx.android.synthetic.main.fragment_menu.*

class MenuFragment : MVPFragment<MenuPresenter, MenuView>(), MenuView, AppEditTextChangedListener.OnEditTextChangedListener, MenuAdapter.ItemListener {
    private lateinit var menuAdapter: MenuAdapter
    var menuList: MutableList<MenuList> = ArrayList()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_menu, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        activity().hideSoftKeyboard()
        activity().setRecyclerView(rvMenu, 2, GRIDLAYOUT)
        appEdtSearch.addTextChangedListener(AppEditTextChangedListener(this, appEdtSearch))

        presenter.apiCall(1, RestConstant.CALL_API_MENU)

        if (hasInternet()) {
            view.findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener {
                swipeRefreshLayout.isRefreshing = true
                Handler().postDelayed({
                    presenter.apiCall(0, RestConstant.CALL_API_MENU)
                }, 1000)
            }
        }

        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent, R.color.colorPrimaryDark, R.color.colorAccent)
    }

    override fun createPresenter(): MenuPresenter {
        return MenuPresenter()
    }

    override fun attachView(): MenuView {
        return this
    }

    override fun apiPostMenuResponse(response: MenuResponse) {
        swipeRefreshLayout.isRefreshing = false
        menuList = ArrayList()

        when {
            response.response.code == RestConstant.OK_200 -> {
                menuList = response.menucategoryList
                menuAdapter = MenuAdapter(activity(), menuList)
                rvMenu.adapter = menuAdapter
            }
            else -> {
                activity().showToast(response.response.message)

                menuAdapter = MenuAdapter(activity(), menuList)
                rvMenu.adapter = menuAdapter
            }
        }

        menuAdapter.setOnListener(this)
    }

    override fun onAfterTextChanged(str: String) {
        when {
            menuList.isNotEmpty() && str.isNotEmpty() -> menuAdapter.filter(str)
            else -> menuAdapter.filter("")
        }
    }

    override fun onClickMenu(modelMenu: MenuList) {
        val alPassDataQuestion = ArrayList<MenuParcelable>()
        var intentOperation = MenuClick(activity(), modelMenu, alPassDataQuestion)
        execute(intentOperation)
    }

    override fun onFailure(message: String) {
        swipeRefreshLayout.isRefreshing = false
        activity().showToast(message)
    }
}

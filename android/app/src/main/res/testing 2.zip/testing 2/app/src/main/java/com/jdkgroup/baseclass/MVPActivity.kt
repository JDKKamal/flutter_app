package com.jdkgroup.baseclass

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823

   * P - PRESENTER
   * V - VIEW
   * EXTENDS BASEACTIVITY
* */

import android.app.Activity
import android.os.Bundle

abstract class MVPActivity<P : BasePresenter<V>, V : BaseView> : BaseActivity() {
    lateinit var presenter: P
        private set

    override val activity: Activity
        get() = this

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        presenter = createPresenter()
        presenter.attachView(attachView())
    }

    public override fun onDestroy() {
        super.onDestroy()
    }

    abstract fun createPresenter(): P

    abstract fun attachView(): V
}

package com.jdkgroup.db

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.Activity
import android.app.Application
import com.jdkgroup.model.db.CategoryListRealm
import io.realm.Realm
import io.realm.RealmModel
import io.realm.RealmQuery



class DBQuery(application: Application) {
    val realm: Realm? = Realm.getDefaultInstance()

    internal fun closeRealm() {
        if (realm != null && !realm.isClosed) {
            realm.close()
        }
    }

    fun realmVersion(): Long {
        return realm!!.version
    }

    fun realmInsert(realmModel: RealmModel) {
        realm!!.beginTransaction()
        realm.insert(realmModel)
        realm.commitTransaction()
    }

    fun realmInsertList(list: Collection<RealmModel>) {
        realm!!.beginTransaction()
        realm.insert(list)
        realm.commitTransaction()
    }

    fun realmList(id: String): List<CategoryListRealm> {
        return realm!!.where(CategoryListRealm::class.java).equalTo("id", id).findAll()
    }

    fun realmDeleteCategoryId(id: String) {
        realm!!.beginTransaction()
        val result = realm.where(CategoryListRealm::class.java).equalTo("id", id).findAll()
        result.deleteAllFromRealm()
        realm.commitTransaction()
    }

    fun realmDeleteTable(clazz: Class<out RealmModel>) {
        realm!!.beginTransaction()
        realm.delete(clazz)
        realm.commitTransaction()
    }

    companion object {
        fun with(activity: Activity): DBQuery {
            return DBQuery(activity.application)
        }

        fun with(application: Application): DBQuery {
            return DBQuery(application)
        }
    }
}
package com.jdkgroup.model.api.faq

class ListFaqSection {
    var faqlist: List<FaqList>? = null
    var question: String? = null
}
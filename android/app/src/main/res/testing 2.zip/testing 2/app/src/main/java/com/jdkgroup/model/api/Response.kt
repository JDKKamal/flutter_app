package com.jdkgroup.model.api

open class Response {
    var code: Int = 0
    lateinit var message: String
    lateinit var urlpath: String
}


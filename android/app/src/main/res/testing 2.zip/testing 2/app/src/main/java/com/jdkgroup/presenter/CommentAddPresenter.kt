package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.response.comment.commentlist.CommentResponse
import com.jdkgroup.model.api.response.comment.like.LikeResponse
import com.jdkgroup.model.api.response.comment.logincomment.LoginCommentResponse
import com.jdkgroup.model.api.response.comment.subcomment.SubCommentResponse
import com.jdkgroup.model.api.response.comment.unlike.UnLikeResponse
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.EnumProgressBar
import com.jdkgroup.utils.isEmpty
import com.jdkgroup.utils.showToast
import com.jdkgroup.view.CommentAddView

class CommentAddPresenter : BasePresenter<CommentAddView>() {
    private fun callApiGetLoginComment(params: HashMap<String, String>) {
        appInteractor.apiGetLoginComment(view.activity(), params, object : InterActorCallback<LoginCommentResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: LoginCommentResponse) {
                view.apiGetLoginCommentResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }

        })
    }

    private fun callApiPostCommentList(params: HashMap<String, String>) {
        appInteractor.apiPostCommentList(view.activity(), params, object : InterActorCallback<CommentResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: CommentResponse) {
                view.apiPostCommentListResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }
        })
    }

    private fun callApiPostSubComment(params: HashMap<String, String>) {
        appInteractor.apiPostSubComment(view.activity(), params, object : InterActorCallback<SubCommentResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: SubCommentResponse) {
                view.apiPostSubCommentResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }
        })
    }

    private fun callApiPostLike(params: HashMap<String, String>) {
        appInteractor.apiPostLike(view.activity(), params, object : InterActorCallback<LikeResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: LikeResponse) {
                view.apiPostLikeResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }
        })
    }

    private fun callApiPostUnLike(params: HashMap<String, String>) {
        appInteractor.apiPostUnLike(view.activity(), params, object : InterActorCallback<UnLikeResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: UnLikeResponse) {
                view.apiPostUnLikeResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }
        })
    }


    internal fun apiCall(params: HashMap<String, String>, apiNo: Int) {
        when {
            hasInternet() ->
                when (apiNo) {

                    RestConstant.CALL_API_COMMENT_LOGIN -> callApiGetLoginComment(params)

                    RestConstant.CALL_API_COMMENT_LIST -> callApiPostCommentList(params)

                    RestConstant.CALL_API_SUB_COMMENT -> callApiPostSubComment(params)

                    RestConstant.CALL_API_LIKE -> callApiPostLike(params)

                    RestConstant.CALL_API_UNLIKE -> callApiPostUnLike(params)
                }
        }
    }

    internal fun validationComment(comment: String): Boolean {
        return when {
            isEmpty(comment) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_comment))
                false
            }
            else -> true
        }
    }
}

package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.view.View
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.db.DBQuery
import com.jdkgroup.model.api.response.DefaultResponse
import com.jdkgroup.model.db.CategoryListRealm
import com.jdkgroup.model.parcelable.CategoryParcelable
import com.jdkgroup.presenter.DetailPresenter
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.*
import com.jdkgroup.view.DetailView
import kotlinx.android.synthetic.main.activity_category_detail.*
import kotlinx.android.synthetic.main.toolbar.*
import java.util.*

class CategoryDetailActivity : SimpleMVPActivity<DetailPresenter, DetailView>(), DetailView, View.OnClickListener {

    private lateinit var loginRatting: String

    companion object {
        lateinit var listCategoryParcelable: List<CategoryParcelable>
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_detail)

        hideSoftKeyboard()
        loginRatting = "0"

        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem

        listCategoryParcelable = getParcelable(AppConstant.BUNDLE_PARCELABLE)!!
        when {
            listCategoryParcelable.isNotEmpty() -> {
                appTvTitle.text = listCategoryParcelable[0].nameMenu.toUpperCase()

                appRbCategory.rating = listCategoryParcelable[0].totalRateAvgCategory.toFloat()
                appTvTotalRatingCategory.text = "(" + listCategoryParcelable[0].totalRateCategory + " ratings)"
                appTvDetail.text = listCategoryParcelable[0].descriptionCategory
                appTvPrice.text = listCategoryParcelable[0].priceCategory.toString()

                glideSetAppImageView(RestConstant.IMAGE_URL + listCategoryParcelable[0].imageCategory, this.appIvCategoryImage)
            }
        }

        appBtnAddToCard.setOnClickListener(this)
        appIvDrawer.setOnClickListener(this)
        appBtnComment.setOnClickListener (this)
    }

    override fun onResume() {
        super.onResume()

        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem
    }

    override fun createPresenter(): DetailPresenter {
        return DetailPresenter()
    }

    override fun attachView(): DetailView {
        return this
    }

    override fun apiGetAddToCartResponse(response: DefaultResponse) {
        when {
            response.response!!.code == RestConstant.OK_200 -> DBQuery.with(activity()).realmInsert(CategoryListRealm(UUID.randomUUID().toString(), listCategoryParcelable[0].idCategory))
        }

        launchActivity(AddToCardActivity::class.java, EnumLaunchActivity.LaunchActivity)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.appBtnAddToCard -> {
                when {
                    listCategoryParcelable.isNotEmpty() -> {
                        val param: HashMap<String, String> = hashMapOf(
                                RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(this).userId,
                                RestConstant.MENU_ID to listCategoryParcelable[0].idCategory,
                                RestConstant.MENU_NAME to listCategoryParcelable[0].nameCategory,
                                RestConstant.MENU_QTY to "1",
                                RestConstant.MENU_PRICE to listCategoryParcelable[0].priceCategory
                        )
                        presenter.apiCall(param, RestConstant.CALL_API_ADD_TO_CART)
                    }
                }
            }

            R.id.appIvDrawer -> activity.finish()

            R.id.appBtnComment -> launchActivity(CommentAddActivity::class.java, EnumLaunchActivity.LaunchActivity)
        }

    }

    override fun onFailure(message: String) {
        showToast(message)
    }

}

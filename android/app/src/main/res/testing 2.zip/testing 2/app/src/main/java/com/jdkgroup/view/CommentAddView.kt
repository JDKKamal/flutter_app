package com.jdkgroup.view

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BaseView
import com.jdkgroup.model.api.response.DefaultResponse
import com.jdkgroup.model.api.response.comment.like.LikeResponse
import com.jdkgroup.model.api.response.comment.logincomment.LoginCommentResponse
import com.jdkgroup.model.api.response.comment.commentlist.CommentResponse
import com.jdkgroup.model.api.response.comment.subcomment.SubCommentResponse
import com.jdkgroup.model.api.response.comment.unlike.UnLikeResponse

interface CommentAddView : BaseView {
    fun apiGetLoginCommentResponse(response: LoginCommentResponse)
    fun apiPostCommentListResponse(response: CommentResponse)
    fun apiPostSubCommentResponse(response: SubCommentResponse)

    fun apiPostLikeResponse(response: LikeResponse)
    fun apiPostUnLikeResponse(response: UnLikeResponse)
}

package com.jdkgroup.model.api.response.menu

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MenuResponse {
    @SerializedName("response")
    @Expose
    lateinit var response: Response
    @SerializedName("menucategory_list")
    @Expose
    lateinit var menucategoryList: MutableList<MenuList>
}

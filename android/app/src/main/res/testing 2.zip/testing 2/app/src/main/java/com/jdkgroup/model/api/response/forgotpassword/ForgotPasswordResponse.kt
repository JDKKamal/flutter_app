package com.jdkgroup.model.api.response.forgotpassword

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.jdkgroup.model.api.Response

class ForgotPasswordResponse {
    @SerializedName("response")
    @Expose
   lateinit var response: Response
}
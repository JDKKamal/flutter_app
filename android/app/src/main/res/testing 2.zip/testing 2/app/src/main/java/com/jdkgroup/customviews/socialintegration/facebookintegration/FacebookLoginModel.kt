package com.jdkgroup.customviews.socialintegration.facebookintegration

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

class FacebookLoginModel(var authtoken: String, var id: String, var name: String, var firstname: String, var lastname: String, var gender: String, var email: String, var profilePicture: String, var cellno: String)

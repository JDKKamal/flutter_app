package com.jdkgroup.baseclass

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.Activity
import com.jdkgroup.utils.EnumProgressBar

interface BaseView {
    val defaultParam: Map<String, String>
    fun activity(): Activity
    fun hasInternet(): Boolean
    fun showProgressDialog(enumProgressBar: EnumProgressBar)
    fun onFailure(message: String)
}
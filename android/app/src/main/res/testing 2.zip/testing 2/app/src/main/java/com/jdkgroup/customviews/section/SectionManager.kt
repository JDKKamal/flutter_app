package com.jdkgroup.customviews.section

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.support.annotation.IntRange

import java.util.ArrayList

internal class SectionManager {

    val sections: MutableList<Section> = ArrayList()

    val lastSection: Section
        get() = sections[sections.size - 1]

    val itemCount: Int
        get() {

            var itemCount = 0

            for (section in sections) {
                itemCount += 1
                if (section.isExpanded) {
                    itemCount += section.itemCount
                }
            }

            return itemCount

        }

    val dataItemCount: Int
        get() {
            var dataItemCount = 0
            for (section in sections) {
                dataItemCount += section.itemCount
            }
            return dataItemCount
        }

    val sectionsCount: Int
        get() = sections.size

    fun addSection(section: Section) {
        sections.add(section)
    }

    fun isSectionSubHeaderOnPosition(@IntRange(from = 0, to = Integer.MAX_VALUE.toLong()) position: Int): Boolean {
        for (section in sections) {
            if (section.subheaderPosition == position) {
                return true
            }
        }
        return false
    }

    fun isSectionExpanded(@IntRange(from = 0, to = Integer.MAX_VALUE.toLong()) sectionIndex: Int): Boolean {
        if (sectionIndex < 0 || sectionIndex >= sections.size) {
            throw IllegalArgumentException("sectionIndex: " + sectionIndex + ", size: " + sections.size)
        }
        return sections[sectionIndex].isExpanded
    }

    fun expandSection(@IntRange(from = 0, to = Integer.MAX_VALUE.toLong()) sectionIndex: Int): Int {

        val sectionToExpand = sections[sectionIndex]

        if (sectionToExpand.isExpanded) {
            return 0
        }

        sectionToExpand.isExpanded = true

        for (i in sectionIndex + 1 until sections.size) {
            val section = sections[i]
            section.subheaderPosition = section.subheaderPosition + sectionToExpand.itemCount
        }

        return sectionToExpand.itemCount

    }

    fun expandAllSections() {
        for (section in sections) {
            expandSection(sections.indexOf(section))
        }
    }

    fun collapseSection(@IntRange(from = 0, to = Integer.MAX_VALUE.toLong()) sectionIndex: Int): Int {

        if (sectionIndex < 0 || sectionIndex >= sections.size) {
            throw IllegalArgumentException("sectionIndex: " + sectionIndex + ", size: " + sections.size)
        }

        val sectionToCollapse = sections[sectionIndex]

        if (!sectionToCollapse.isExpanded) {
            return 0
        }

        sectionToCollapse.isExpanded = false

        for (i in sectionIndex + 1 until sections.size) {
            val section = sections[i]
            section.subheaderPosition = section.subheaderPosition - sectionToCollapse.itemCount
        }

        return sectionToCollapse.itemCount

    }

    fun collapseAllSections() {
        for (section in sections) {
            collapseSection(sections.indexOf(section))
        }
    }

    fun getItemPositionForSubheaderViewHolder(@IntRange(from = 0, to = Integer.MAX_VALUE.toLong()) subheaderPosition: Int): Int {

        if (subheaderPosition < 0 || subheaderPosition >= itemCount) {
            throw IllegalArgumentException("subheaderPosition: $subheaderPosition, itemCount: $itemCount")
        }

        var itemPosition = 0

        val sectionIndex = sectionIndex(subheaderPosition)

        for (i in 0 until sectionIndex) {
            itemPosition += sections[i].itemCount
        }

        return itemPosition

    }

    fun getItemPositionForItemViewHolder(@IntRange(from = 0, to = Integer.MAX_VALUE.toLong()) itemHolderPosition: Int): Int {
        var itemHolderPosition = itemHolderPosition

        if (itemHolderPosition < 0 || itemHolderPosition >= itemCount) {
            throw IllegalArgumentException("itemHolderPosition: $itemHolderPosition, itemCount: $itemCount")
        }
        if (isSectionSubHeaderOnPosition(itemHolderPosition)) {
            throw IllegalArgumentException("section subheader is placed at $itemHolderPosition position")
        }

        val sectionIndex = sectionIndex(itemHolderPosition)

        itemHolderPosition -= sectionIndex + 1

        for (i in 0 until sectionIndex) {

            val section = sections[i]

            if (!section.isExpanded) {
                itemHolderPosition += section.itemCount
            }

        }

        return itemHolderPosition

    }

    fun getAdapterPositionForItem(itemPosition: Int): Int {

        if (itemPosition < 0 || itemPosition >= dataItemCount) {
            throw IllegalArgumentException("itemPosition: $itemPosition, itemCount: $dataItemCount")
        }

        if (!sections[sectionIndexByItemPosition(itemPosition)].isExpanded) {
            return -1
        }

        var adapterPosition = 0

        var itemCount = 0

        for (section in sections) {

            adapterPosition += 1

            if (!section.isExpanded) {
                adapterPosition -= section.itemCount
            }

            if (itemCount + section.itemCount <= itemPosition) {
                itemCount += section.itemCount
            } else {
                break
            }

        }

        return adapterPosition + itemPosition

    }

    fun removeItem(itemAdapterPosition: Int): Boolean {

        if (itemAdapterPosition < 0 || itemAdapterPosition >= itemCount) {
            throw IllegalArgumentException("itemAdapterPosition: $itemAdapterPosition, itemCount: $itemCount")
        }
        if (isSectionSubHeaderOnPosition(itemAdapterPosition)) {
            throw IllegalArgumentException("section subheader is placed at $itemAdapterPosition position")
        }

        val sectionIndex = sectionIndex(itemAdapterPosition)
        val section = sections[sectionIndex]

        val isSectionRemoved: Boolean

        var positionsToDecrease: Int

        if (section.itemCount == 1) {
            isSectionRemoved = true
            positionsToDecrease = 2
        } else {
            isSectionRemoved = false
            section.setItemsCount(section.itemCount - 1)
            positionsToDecrease = 1
        }

        if (!section.isExpanded) {
            if (isSectionRemoved) {
                positionsToDecrease = 1
            }
        }

        for (i in sectionIndex + 1 until sections.size) {
            val section1 = sections[i]
            section1.subheaderPosition = section1.subheaderPosition - positionsToDecrease
        }

        if (isSectionRemoved) {
            sections.remove(section)
        }

        return isSectionRemoved

    }

    fun insertItem(adapterPosition: Int, shouldInsertSection: Boolean) {
        var adapterPosition = adapterPosition

        if (shouldInsertSection) {

            val newSection = Section(adapterPosition)
            newSection.setItemsCount(1)

            if (adapterPosition == itemCount) {
                sections.add(newSection)
                return
            }

            val sectionIndex = sectionIndex(adapterPosition)

            for (i in sectionIndex until sections.size) {
                val section = getSection(i)
                section.subheaderPosition = section.subheaderPosition + 2
            }

            sections.add(sectionIndex, newSection)

        } else {

            if (isSectionSubHeaderOnPosition(adapterPosition) && adapterPosition != 0 || adapterPosition == itemCount) {
                adapterPosition--
            }

            val currentSectionIndex = sectionIndex(adapterPosition)
            val currentSection = getSection(currentSectionIndex)
            currentSection.setItemsCount(currentSection.itemCount + 1)

            if (!currentSection.isExpanded) {
                return
            }

            for (i in currentSectionIndex + 1 until sections.size) {
                val section = getSection(i)
                section.subheaderPosition = section.subheaderPosition + 1
            }

        }

    }

    fun getSection(@IntRange(from = 0, to = Integer.MAX_VALUE.toLong()) sectionIndex: Int): Section {
        if (sectionIndex < 0 || sectionIndex >= sections.size) {
            throw IllegalArgumentException("sectionIndex: " + sectionIndex + ", size: " + sections.size)
        }
        return sections[sectionIndex]
    }

    fun sectionIndex(@IntRange(from = 0, to = Integer.MAX_VALUE.toLong()) adapterPosition: Int): Int {

        if (adapterPosition < 0 || adapterPosition >= itemCount) {
            throw IllegalArgumentException("adapterPosition: $adapterPosition, itemCount: $itemCount")
        }

        var sectionIndex = 0

        for (section in sections) {
            if (adapterPosition == section.subheaderPosition) {
                return sections.indexOf(section)
            } else if (adapterPosition > section.subheaderPosition) {
                sectionIndex = sections.indexOf(section)
            }
        }

        return sectionIndex

    }

    fun sectionIndexByItemPosition(@IntRange(from = 0, to = Integer.MAX_VALUE.toLong()) itemPosition: Int): Int {

        if (itemPosition < 0) {
            throw IllegalArgumentException("itemPosition < 0")
        }

        var itemCount = 0

        for (section in sections) {

            itemCount += section.itemCount

            if (itemCount > itemPosition) {
                return sections.indexOf(section)
            }

        }

        return sections.size - 1

    }

    fun positionInSection(@IntRange(from = 0, to = Integer.MAX_VALUE.toLong()) itemAdapterPosition: Int): Int {

        if (itemAdapterPosition < 0 || itemAdapterPosition >= itemCount) {
            throw IllegalArgumentException("itemAdapterPosition: $itemAdapterPosition, itemCount: $itemCount")
        }
        if (isSectionSubHeaderOnPosition(itemAdapterPosition)) {
            throw IllegalArgumentException("section subheader is placed at $itemAdapterPosition position")
        }

        val section = getSection(sectionIndex(itemAdapterPosition))

        return itemAdapterPosition - section.subheaderPosition - 1

    }

    fun sectionSize(sectionIndex: Int): Int {
        return getSection(sectionIndex).itemCount
    }

    fun clear() {
        sections.clear()
    }

}

package com.jdkgroup.model.api.response.profile

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ProfileResponse {
    @SerializedName("response")
    @Expose
    lateinit var response: Response
    @SerializedName("update_user_profile")
    @Expose
    lateinit var updateUserProfile: UpdateUserProfile

}
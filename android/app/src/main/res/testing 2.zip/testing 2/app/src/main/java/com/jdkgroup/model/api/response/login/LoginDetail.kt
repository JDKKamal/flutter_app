package com.jdkgroup.model.api.response.login

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class LoginDetail {

    @SerializedName("user_id")
    @Expose
    lateinit var userId: String
    @SerializedName("name")
    @Expose
    lateinit var name: String
    @SerializedName("email")
    @Expose
    lateinit var email: String
    @SerializedName("phone")
    @Expose
    lateinit var phone: String
    @SerializedName("address")
    @Expose
    lateinit var address: String
    @SerializedName("user_image")
    @Expose
    lateinit var userImage: String
    @SerializedName("cart_items")
    @Expose
    var cartItems: Int = 0
    @SerializedName("promo_rowcount")
    @Expose
    lateinit var promoRowcount: String
}
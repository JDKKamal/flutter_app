package com.jdkgroup.model.api.response.slider

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SliderList {

    @SerializedName("banner_name")
    @Expose
    lateinit var bannerName: String
    @SerializedName("banner_desc")
    @Expose
    lateinit var bannerDesc: String
    @SerializedName("banner_name_imagepath")
    @Expose
    lateinit var bannerNameImagePath: String
    @SerializedName("banner_image")
    @Expose
    lateinit var bannerImage: String
}


package com.jdkgroup.model.api.response.slider

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.jdkgroup.model.api.Response

class SliderResponse {
    @SerializedName("response")
    @Expose
    lateinit var response: Response
    @SerializedName("slider_list")
    @Expose
    lateinit var sliderList: MutableList<SliderList>
}
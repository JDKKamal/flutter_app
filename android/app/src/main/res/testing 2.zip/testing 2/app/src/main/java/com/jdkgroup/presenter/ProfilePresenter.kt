package com.jdkgroup.presenter

/*
   Developed BY Bytotech Solution
   info@bytotech.com
   +91 9601501313
*/
import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.response.profile.ProfileResponse
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.*
import com.jdkgroup.view.ProfileView
import okhttp3.MultipartBody
import okhttp3.RequestBody

class ProfilePresenter : BasePresenter<ProfileView>() {
    fun callApiProfile(image: MultipartBody.Part, userId: RequestBody, name: RequestBody, email: RequestBody, password: RequestBody, mobile: RequestBody, address: RequestBody) {
        when {
            hasInternet() -> appInteractor.apiPostProfile(view.activity(), image, userId, name, email, password, mobile, address, object : InterActorCallback<ProfileResponse> {
                override fun onStart() {
                    view.showProgressDialog(EnumProgressBar.Show)
                }

                override fun onResponse(response: ProfileResponse) {
                    view.apiPostProfileResponse(response)
                }

                override fun onFinish() {
                    view.showProgressDialog(EnumProgressBar.Hide)
                }

                override fun onError(message: String) {
                    view.onFailure(message)
                }

            })
        }
    }

    fun validation(name: String, email: String, mobile: String, password: String): Boolean {
        return when {
          isEmpty(name) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_name))
                false
            }
          isEmpty(email) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_email))
                false
            }
            !isRegexValidator(email, patternEmail) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_valid_email))
                false
            }
            !isEmpty(mobile) && !isRegexValidator(mobile, patternMobile) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_valid_mobile))
                false
            }
            else -> true
        }
    }
}
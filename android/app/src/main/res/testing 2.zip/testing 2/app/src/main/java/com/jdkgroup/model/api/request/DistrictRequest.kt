package com.jdkgroup.model.api.request

class DistrictRequest(var countryid: String) {
}

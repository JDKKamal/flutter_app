package com.exam.mania.adapter

import com.jdkgroup.model.api.local.Faq
import com.jdkgroup.terasjawa.adapter.section.SectionFaq

class FaqSectionAdapter(itemList: List<Faq>) : SectionFaq(itemList) {

    override fun onPlaceSubheaderBetweenItems(position: Int): Boolean {
        val faq = faqList[position]
        val nextFaq = faqList[position + 1]

        return faq.date == nextFaq.date
    }

    override fun onBindItemViewHolder(holder: SectionFaq.MovieViewHolder, position: Int) {
        val faq = faqList[position]

        holder.appTvQuestion.text = faq.question
        holder.appTvAnswer.text =  faq.answer

        holder.itemView.setOnClickListener { _ -> onItemClickListener.onItemClicked(faq) }
    }

    override fun onBindSubHeaderViewHolder(SubHeaderHolder: SectionFaq.SubHeaderHolder, nextItemPosition: Int) {
        super.onBindSubHeaderViewHolder(SubHeaderHolder, nextItemPosition)
        val nextMovie = faqList[nextItemPosition]
        SubHeaderHolder.appTvHeaderTitle.text = nextMovie.title
    }
}

package com.jdkgroup.terasjawa.adapter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.jdkgroup.customviews.recyclerview.BaseRecyclerView
import com.jdkgroup.customviews.recyclerview.BaseViewHolder
import com.jdkgroup.model.api.response.comment.commentlist.CommentList
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.glideSetAppImageView
import kotlinx.android.synthetic.main.itemview_section_parent.view.*

class CommentAdapter(private val activity: Activity, private val commentList: MutableList<CommentList>) : BaseRecyclerView<CommentList>() {
    private val inflater: LayoutInflater = LayoutInflater.from(activity)

    private lateinit var listener: ItemListener

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): CommentList {
        return commentList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<CommentList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_section_parent, parent, false))
    }

    override fun getItemCount(): Int {
        return commentList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<CommentList>(itemView) {
        var tvParentTitle = itemView.tvParentTitle!!
        var appTvParentComment = itemView.appTvParentComment!!
        var appRbParentComment = itemView.appRbParentComment!!
        var appTvParentCommentCount = itemView.appTvParentCommentCount!!
        var appIvParentCommentAdd = itemView.appIvParentCommentAdd!!

        var appIvParent = itemView.appIvParent!!
        var appTvParentLikeCount = itemView.appTvParentLikeCount!!
        var appIvParentLike = itemView.appIvParentLike!!
        var appTvParentView = itemView.appTvParentView!!

        override fun populateItem(t: CommentList) {
            if (t.userImage.isNotEmpty()) {
                activity.glideSetAppImageView( t.userImage, appIvParent)
            }

            tvParentTitle.text = t.name
            appRbParentComment.rating = t.rate.toFloat()
            appTvParentComment.text = t.msg

            if (t.count.isNotEmpty()) {
                appTvParentCommentCount.text = "Comments available"
            } else {
                appTvParentCommentCount.text = "No comments"
            }
            if (t.count.isNotEmpty()) {
                appTvParentLikeCount.text = t.count.toString() + " Likes"
            } else {
                appTvParentLikeCount.text = "0 Likes"
            }

            /* if (PreferenceUtils.preferenceInstance(context).userId == userId) {
                 sectionViewHolder.appIvParentLike.setColorFilter(R.color.colorLike)
             } else {
                 sectionViewHolder.appIvParentLike.setColorFilter(R.color.colorUnlike)
             }*/

            appIvParentCommentAdd.setOnClickListener {
                listener.onClickChildComment(commentList[layoutPosition])
            }

            appIvParentLike.setOnClickListener{
                listener.onClickLike(layoutPosition, commentList[layoutPosition])
            }

            appTvParentView.setOnClickListener{
                listener.onClickLike(layoutPosition, commentList[layoutPosition])
            }

            appTvParentView.setOnClickListener{
                listener.onClickViewComment(commentList[layoutPosition])
            }
        }
    }

    interface ItemListener {
        fun onClickChildComment(commentList: CommentList)
        fun onClickLike(position: Int, commentList: CommentList)
        fun onClickViewComment(commentList: CommentList)
    }

    fun likeCount(position: Int, item: CommentList) {
        var calCount = item.count.toInt() + 1
        commentList[position] = CommentList(calCount.toString(), item.rId, item.ip, item.rate, item.msg, item.name, item.userImage, 1)
        notifyItemChanged(position)
    }

    fun unLikeCount(position: Int, item: CommentList) {
        var calCount = item.count.toInt() - 1
        commentList[position] = CommentList(calCount.toString(), item.rId, item.ip, item.rate, item.msg, item.name, item.userImage, 0)
        notifyItemChanged(position)
    }
}

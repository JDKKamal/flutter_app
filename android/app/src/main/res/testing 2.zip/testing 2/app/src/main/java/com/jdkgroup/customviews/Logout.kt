package com.jdkgroup.customviews

import android.app.Activity
import android.support.v7.widget.AppCompatTextView
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.PreferenceUtils
import com.jdkgroup.utils.glideSetAppImageView
import de.hdodenhof.circleimageview.CircleImageView

class Logout(private val activity: Activity, private val mListener: OnLogoutListener)
{
    fun logout()
    {
        val builder = android.app.AlertDialog.Builder(activity)
        val alertDialog = builder.create()
        val dialogView = activity.layoutInflater.inflate(R.layout.dialog_logout, null)
        alertDialog.setView(dialogView)

        val appTvYes = dialogView.findViewById(R.id.appTvYes) as AppCompatTextView
        val appTvNo = dialogView.findViewById(R.id.appTvNo) as AppCompatTextView
        val appCivProfile = dialogView.findViewById(R.id.appCivProfile) as CircleImageView

        when {
            PreferenceUtils.preferenceInstance(this.activity).profilepicture.isNotEmpty() -> activity.glideSetAppImageView(PreferenceUtils.preferenceInstance(activity).profilepicture, appCivProfile)
        }
        appTvYes.setOnClickListener {
            mListener.onLogout(true)
        }
        appTvNo.setOnClickListener { alertDialog.dismiss() }

        alertDialog.show()
    }

    interface OnLogoutListener {
        fun onLogout(boolean: Boolean)
    }
}
package com.jdkgroup.customviews.recyclerview

import android.support.v7.widget.RecyclerView

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/


abstract class BaseRecyclerView<T> : RecyclerView.Adapter<BaseViewHolder<T>>() {

    protected abstract fun getItem(position: Int): T

    override fun onBindViewHolder(holder: BaseViewHolder<T>, position: Int) {
        holder.populateItem(getItem(position))
    }
}

package com.jdkgroup.utils

enum class EnumProgressBar {
    Show,
    Hide
}

enum class EnumLaunchActivity {
    LaunchActivity,
    ClearHistory
}

/*
enum class EnumRecyclerView {
    LinearLayout,
    GridLayout,
    HorizontalLayout,
}*/

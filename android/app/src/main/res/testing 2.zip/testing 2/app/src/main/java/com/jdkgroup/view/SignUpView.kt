package com.jdkgroup.view

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BaseView
import com.jdkgroup.model.api.response.signup.SignUpResponse
import com.jdkgroup.model.api.response.signup.facebook.FacebookResponse
import com.jdkgroup.model.api.response.signup.gmail.GmailSignUpResponse
import com.jdkgroup.model.api.response.signup.twitter.TwitterSignUpResponse

interface SignUpView : BaseView {
    fun apiPostSignUpResponse(response: SignUpResponse)
    fun apiPostFacebookSignUpResponse(response: FacebookResponse)
    fun apiPostGooglePlusSignUpResponse(response: GmailSignUpResponse)
    fun apiPostTwitterPlusSignUpResponse(response: TwitterSignUpResponse)
}
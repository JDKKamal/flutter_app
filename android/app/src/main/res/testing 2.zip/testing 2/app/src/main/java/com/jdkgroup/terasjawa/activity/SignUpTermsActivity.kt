package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import com.jdkgroup.baseclass.BaseActivity
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.EnumProgressBar
import com.jdkgroup.utils.checkProgressBar
import com.jdkgroup.utils.hideSoftKeyboard
import com.jdkgroup.utils.isInternet
import kotlinx.android.synthetic.main.activity_signup_terms.*
import kotlinx.android.synthetic.main.toolbar_profile.*

class SignUpTermsActivity : BaseActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup_terms)

        hideSoftKeyboard()

        appTvTitle.text = getString(R.string.toolbar_title_privacy_policy).toUpperCase()

        if (isInternet(true)) {
            checkProgressBar(EnumProgressBar.Show)
            startWebView(RestConstant.PRIVACY_POLICY_SIGN_UP)
        }

        appTvLogout.visibility = View.GONE
        appIvDrawer.setOnClickListener(this)
    }

    private fun startWebView(url: String) {
        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                return true
            }

            override fun onLoadResource(view: WebView, url: String) {
                checkProgressBar(EnumProgressBar.Hide)
            }

            override fun onPageFinished(view: WebView, url: String) {
                checkProgressBar(EnumProgressBar.Hide)
            }
        }
        webView.settings.javaScriptEnabled = true
        webView.loadUrl(url)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appIvDrawer -> finish()
        }
    }

    override fun onBackPressed() {
        finish()
    }
}

package com.jdkgroup.customviews.section

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

internal class Section(var subheaderPosition: Int) {

    var itemCount: Int = 0
        private set

    var isExpanded: Boolean = false

    init {
        this.isExpanded = true
        this.itemCount = 0
    }

    fun setItemsCount(itemsCount: Int) {
        this.itemCount = itemsCount
    }

}

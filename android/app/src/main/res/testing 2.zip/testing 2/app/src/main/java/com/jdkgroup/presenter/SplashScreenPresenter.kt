package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Handler
import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.terasjawa.activity.SliderActivity
import com.jdkgroup.utils.EnumLaunchActivity
import com.jdkgroup.utils.launchActivity
import com.jdkgroup.view.SplashScreenView

class SplashScreenPresenter : BasePresenter<SplashScreenView>() {
    fun getSplashScreenWait(timeOut: Int) {
        Handler().postDelayed({
            view.activity().launchActivity(SliderActivity::class.java, EnumLaunchActivity.LaunchActivity)
            view.activity().finish()
        }, timeOut.toLong())
    }
}
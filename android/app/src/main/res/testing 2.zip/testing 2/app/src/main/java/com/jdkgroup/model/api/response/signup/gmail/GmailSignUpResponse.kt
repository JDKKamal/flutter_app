package com.jdkgroup.model.api.response.signup.gmail

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class GmailSignUpResponse {
    @SerializedName("response")
    @Expose
    lateinit  var response: Response
    @SerializedName("gplus_register")
    @Expose
    lateinit var gplusRegister: GplusRegister
}
package com.jdkgroup.customviews.permission

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener

class PermissionDexter(private val activity: Activity, val permissions : Collection<String>, private val mListener: OnPermissionChangedListener) {
    fun permissionMultiple () {
        Dexter.withActivity(activity)
                .withPermissions(permissions
                )
                .withListener(object : MultiplePermissionsListener {
                    override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                        if (report.areAllPermissionsGranted()) {
                            mListener.onAllPermissionGranted(true)
                        }
                        (0 until report.deniedPermissionResponses.size).forEach { i ->
                            report.deniedPermissionResponses[i].permissionName
                        }
                        // CHECK FOR PERMANENT DENIAL OF ANY PERMISSION DEXTER
                        if (report.isAnyPermissionPermanentlyDenied) {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", activity.packageName, null))
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            activity.startActivity(intent)
                        }
                    }

                    override fun onPermissionRationaleShouldBeShown(permissions: List<com.karumi.dexter.listener.PermissionRequest>, token: PermissionToken) {
                        token.continuePermissionRequest()
                    }
                }).check()
    }

    interface OnPermissionChangedListener {
        fun onAllPermissionGranted(boolean: Boolean)
    }
}


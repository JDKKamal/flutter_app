package com.jdkgroup.terasjawa.adapter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.content.Context
import android.graphics.Color
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.jdkgroup.terasjawa.R
import com.jdkgroup.model.ModelDrawer
import com.jdkgroup.utils.PreferenceUtils

class DrawerAdapter(private val context: Context, data: MutableList<ModelDrawer>) : RecyclerView.Adapter<DrawerAdapter.ViewHolder>() {
    internal var data: List<ModelDrawer> = ArrayList()
    private val inflater: LayoutInflater = LayoutInflater.from(context)

    init {
        this.data = data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = inflater.inflate(R.layout.itemview_drawer, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val modelDrawer = data[position]

        when (position) {
            2 -> {
                holder.appTvBadge.visibility = View.VISIBLE
                holder.appTvBadge.text = PreferenceUtils.preferenceInstance(context).promoItem
            }
        }

        holder.appIvIcon.setBackgroundResource(modelDrawer.icon)
        holder.appTvDrawerTitle.text = modelDrawer.title
    }

    override fun getItemCount(): Int {
        return data.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var appTvDrawerTitle: AppCompatTextView = itemView.findViewById(R.id.appTvDrawerTitle)
        var appTvBadge: AppCompatTextView = itemView.findViewById(R.id.appTvBadge)
        var appIvIcon: AppCompatImageView = itemView.findViewById(R.id.appIvIcon)
    }
}
package com.jdkgroup.model.api.response

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class DefaultResponse {
    @SerializedName("response")
    @Expose
    lateinit var response: Response
}
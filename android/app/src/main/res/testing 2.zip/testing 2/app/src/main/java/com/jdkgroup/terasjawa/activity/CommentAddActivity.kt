package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.AlertDialog
import android.os.Bundle
import android.support.v7.widget.*
import android.view.View
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.model.api.response.comment.commentlist.CommentList
import com.jdkgroup.model.api.response.comment.commentlist.CommentResponse
import com.jdkgroup.model.api.response.comment.like.LikeResponse
import com.jdkgroup.model.api.response.comment.logincomment.LoginCommentResponse
import com.jdkgroup.model.api.response.comment.subcomment.SubCommentResponse
import com.jdkgroup.model.api.response.comment.unlike.UnLikeResponse
import com.jdkgroup.model.parcelable.CategoryParcelable
import com.jdkgroup.model.parcelable.CommentParcelable
import com.jdkgroup.presenter.CommentAddPresenter
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.adapter.CommentAdapter
import com.jdkgroup.utils.*
import com.jdkgroup.view.CommentAddView
import kotlinx.android.synthetic.main.activity_comment_add.*
import java.util.*

class CommentAddActivity : SimpleMVPActivity<CommentAddPresenter, CommentAddView>(), CommentAddView, CommentAdapter.ItemListener {
    private lateinit var toolBar: Toolbar

    private lateinit var appTvTitle: AppCompatTextView
    private lateinit var appIvDrawer: AppCompatImageView
    private lateinit var appTvBadge: AppCompatTextView

    private lateinit var loginRatting: String
    private lateinit var listCategoryParcelable: List<CategoryParcelable>
    private lateinit var commentAdapter: CommentAdapter

    private var commentList: CommentList? = null
    private var position: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comment_add)

        hideSoftKeyboard()
        setRecyclerView(recyclerView, 0, LINEARLAYOUT)
        loginRatting = "0"

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar.findViewById<View>(R.id.appIvDrawer)
        appTvBadge = toolBar.findViewById(R.id.appTvBadge)

        appTvTitle = toolBar.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar.findViewById(R.id.appIvDrawer)

        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem

        listCategoryParcelable = CategoryDetailActivity.listCategoryParcelable
        if (listCategoryParcelable.isNotEmpty()) {
            appTvTitle.text = listCategoryParcelable[0].nameMenu.toUpperCase()
        }

        val param: HashMap<String, String> = hashMapOf(
                RestConstant.PARAM_MID to listCategoryParcelable[0].idCategory
        )
        presenter.apiCall(param, RestConstant.CALL_API_COMMENT_LIST)

        appIvLoginCommentSend.setOnClickListener {
            var loginComment = appEdtLoginComment.text.toString()
            if (loginRatting.isEmpty()) {
                loginRatting = "0"
            }

            presenter.apiCall(hashMapOf(
                    RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(this).userId,
                    RestConstant.PARAM_RATE to loginRatting.toString(),
                    RestConstant.PARAM_MSG to loginComment,
                    RestConstant.PARAM_MID to listCategoryParcelable[0].idCategory
            ), RestConstant.CALL_API_COMMENT_LOGIN)
        }

        LlLoginRatting.setOnClickListener {
            dialogLoginComment()
        }

        appIvDrawer.setOnClickListener { activity.finish() }
    }

    override fun onResume() {
        super.onResume()

        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem
    }

    override fun createPresenter(): CommentAddPresenter {
        return CommentAddPresenter()
    }

    override fun attachView(): CommentAddView {
        return this
    }

    override fun apiGetLoginCommentResponse(response: LoginCommentResponse) {
        appEdtLoginComment.text = null

        val param: HashMap<String, String> = hashMapOf(
                RestConstant.PARAM_MID to listCategoryParcelable[0].idCategory
        )
        presenter.apiCall(param, RestConstant.CALL_API_COMMENT_LIST)
    }

    override fun apiPostCommentListResponse(response: CommentResponse) {
        if (response.response!!.code == RestConstant.OK_200) {
            commentAdapter = CommentAdapter(activity, response.commentList!!)
            commentAdapter.setOnListener(this)
            recyclerView.adapter = commentAdapter
        }
    }

    override fun apiPostSubCommentResponse(response: SubCommentResponse) {

    }

    override fun onClickViewComment(commentList: CommentList) {
        val alPassDataQuestion = ArrayList<CommentParcelable>()
        alPassDataQuestion.add(CommentParcelable(commentList.rId, commentList.name, listCategoryParcelable[0].nameCategory))
        sentParcelsLaunchClear(CommentViewActivity::class.java, AppConstant.BUNDLE_PARCELABLE, alPassDataQuestion, 1)
    }

    override fun apiPostLikeResponse(response: LikeResponse) {
        commentAdapter.likeCount(this.position!!, this.commentList!!)
    }

    override fun apiPostUnLikeResponse(response: UnLikeResponse) {
        commentAdapter.unLikeCount(this.position!!, this.commentList!!)
    }

    override fun onClickLike(position: Int, commentList: CommentList) {
        this.commentList = commentList
        this.position = position
        when {
            commentList.likeUnlike == 0 -> {
                val param: HashMap<String, String> = hashMapOf(
                        RestConstant.PARAM_USER_ID to commentList.ip.toString(),
                        RestConstant.PARAM_R_ID to commentList.rId.toString()
                )

                presenter.apiCall(param, RestConstant.CALL_API_LIKE)
            }
            else -> {
                if (PreferenceUtils.preferenceInstance(this).userId == commentList.ip.toString()) {
                    val param: HashMap<String, String> = hashMapOf(
                            RestConstant.PARAM_USER_ID to commentList.ip.toString(),
                            RestConstant.PARAM_R_ID to commentList.rId.toString()
                    )

                    presenter.apiCall(param, RestConstant.CALL_API_UNLIKE)
                }
            }
        }
    }

    override fun onClickChildComment(commentList: CommentList) {
        dialogSubComment(commentList)
    }

    override fun onFailure(message: String) {
        showToast(message)
    }

    private fun dialogLoginComment() {
        val builder = AlertDialog.Builder(this)
        val alertDialog = builder.create()
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_ratting, null)
        alertDialog.setView(dialogView)

        val appRbLoginRatting = dialogView.findViewById(R.id.appRbLoginRatting) as AppCompatRatingBar
        val appTvYes = dialogView.findViewById(R.id.appTvYes) as AppCompatTextView
        val appTvNo = dialogView.findViewById(R.id.appTvNo) as AppCompatTextView
        appTvYes.setOnClickListener {
            loginRatting = appRbLoginRatting.rating.toString()
            alertDialog.dismiss()
        }
        appTvNo.setOnClickListener {
            loginRatting = "0"
            alertDialog.dismiss()
        }

        alertDialog.show()
    }

    private fun dialogSubComment(commentList: CommentList) {
        val builder = AlertDialog.Builder(this)
        val alertDialog = builder.create()
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_sub_comment, null)
        alertDialog.setView(dialogView)

        val appEdtComment = dialogView.findViewById(R.id.appEdtComment) as AppCompatEditText
        val appTvYes = dialogView.findViewById(R.id.appTvYes) as AppCompatTextView
        val appTvNo = dialogView.findViewById(R.id.appTvNo) as AppCompatTextView
        appTvYes.setOnClickListener {
            if (presenter.validationComment(appEdtComment.text.toString())) {

                val param: HashMap<String, String> = hashMapOf(
                        RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(this).userId,
                        RestConstant.PARAM_COMMENT to appEdtComment.text.toString(),
                        RestConstant.PARAM_R_ID to commentList.rId.toString(),
                        RestConstant.PARAM_MID to listCategoryParcelable[0].idCategory
                )

                presenter.apiCall(param, RestConstant.CALL_API_SUB_COMMENT)
                alertDialog.dismiss()
            }
        }
        appTvNo.setOnClickListener {
            loginRatting = "0"
            alertDialog.dismiss()
        }

        alertDialog.show()
    }
}

package com.jdkgroup.model.api.response.signup.twitter

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class TwitterSignUpResponse {
    @SerializedName("response")
    @Expose
    lateinit var response: Response
    @SerializedName("twiter_register")
    @Expose
    lateinit var twiterRegister: TwiterRegister
}
package com.jdkgroup.model.api.response.shipping.country

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CountryList {
    @SerializedName("country_id")
    @Expose
    lateinit var countryId: String
    @SerializedName("country_name")
    @Expose
    lateinit var countryName: String

}
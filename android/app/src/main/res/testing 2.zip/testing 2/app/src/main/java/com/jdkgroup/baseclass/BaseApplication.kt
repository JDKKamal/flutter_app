package com.jdkgroup.baseclass

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823

   BASEAPPLICATION
   *  SET MULTIDEX, LOOGING, CALLINGGRAPHY (FONT)
   *  REALM (DATABASE)
*/

import android.support.multidex.MultiDex
import android.support.multidex.MultiDexApplication
import com.jdkgroup.customviews.savepref.FastSave
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.LogLevel
import com.jdkgroup.utils.LogUtils
import io.realm.Realm
import io.realm.RealmConfiguration
import uk.co.chrisjenx.calligraphy.CalligraphyConfig

class BaseApplication : MultiDexApplication() {
    lateinit var baseApplication: BaseApplication

    override fun onCreate() {
        super.onCreate()
        LogUtils.addLevel(LogLevel.ALL)
        baseApplication = this

        MultiDex.install(this)
        FastSave.init(this)

        Realm.init(this)
        RealmConfiguration.Builder().name("app.realm").build()

        CalligraphyConfig.initDefault(CalligraphyConfig.Builder()
                .setDefaultFontPath(this.getString(R.string.regular_font))
                .setFontAttrId(R.attr.fontPath)
                .build())
    }

   /* companion object {
        var baseApplication: BaseApplication? = null
            private set
    }*/
}
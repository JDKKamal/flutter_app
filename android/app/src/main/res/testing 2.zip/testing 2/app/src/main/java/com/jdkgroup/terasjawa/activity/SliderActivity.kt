package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.support.v7.widget.AppCompatButton
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.easyslider.SliderItem
import com.jdkgroup.model.api.Response
import com.jdkgroup.model.api.response.slider.SliderList
import com.jdkgroup.model.api.response.slider.SliderResponse
import com.jdkgroup.presenter.SliderPresenter
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.EnumLaunchActivity
import com.jdkgroup.utils.launchActivity
import com.jdkgroup.utils.showToast
import com.jdkgroup.view.SliderView
import kotlinx.android.synthetic.main.activity_slider.*

open class SliderActivity : SimpleMVPActivity<SliderPresenter, SliderView>(), SliderView {

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slider)

        presenter.apiCall(RestConstant.CALL_API_SLIDER)

        findViewById<AppCompatButton>(R.id.appBtnSkip).setOnClickListener {
            launchActivity(LoginActivity::class.java, EnumLaunchActivity.LaunchActivity)
            finish()
        }
    }

    override fun onBackPressed() {
        appExit()
    }

    override fun createPresenter(): SliderPresenter {
        return SliderPresenter()
    }

    override fun attachView(): SliderView {
        return this
    }

    override fun apiGetSliderResponse(response: SliderResponse) {
        val responseCheck = response.response

        if (responseManage(responseCheck)) {
            val listSlider: MutableList<SliderList> = response.sliderList

            val sliderItems = ArrayList<SliderItem>()
            for (i in 0 until listSlider.size) {
                sliderItems.add(SliderItem(listSlider[i].bannerDesc, listSlider[i].bannerNameImagePath))
            }
            slider.setPages(sliderItems)
        }
    }

    override fun onFailure(message: String) {
        showToast(message)
    }
}
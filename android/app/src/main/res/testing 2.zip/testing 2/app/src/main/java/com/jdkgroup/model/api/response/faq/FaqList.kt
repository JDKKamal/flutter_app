package com.jdkgroup.model.api.faq

class FaqList {
    var answer: String? = null
    var faqlistid: String? = null
}
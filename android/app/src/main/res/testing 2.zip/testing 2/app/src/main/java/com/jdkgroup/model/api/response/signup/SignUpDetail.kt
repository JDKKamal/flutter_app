package com.jdkgroup.model.api.response.signup

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SignUpDetail {
    @SerializedName("user_id")
    @Expose
    lateinit var userId: String
    @SerializedName("name")
    @Expose
    lateinit var name: String
    @SerializedName("email")
    @Expose
    lateinit var email: String
    @SerializedName("phone")
    @Expose
    lateinit var phone: String
    @SerializedName("success")
    @Expose
    lateinit var success: String
}

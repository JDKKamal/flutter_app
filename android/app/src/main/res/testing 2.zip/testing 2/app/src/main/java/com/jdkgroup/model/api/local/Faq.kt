package com.jdkgroup.model.api.local


class Faq(var title: String, var question: String, var answer: String, var date: String)

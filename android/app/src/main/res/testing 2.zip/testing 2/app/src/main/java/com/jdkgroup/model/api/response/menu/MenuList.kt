package com.jdkgroup.model.api.response.menu

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MenuList {

    @SerializedName("cid")
    @Expose
    lateinit var cid: String
    @SerializedName("category_name")
    @Expose
    lateinit var categoryName: String
    @SerializedName("category_image")
    @Expose
    lateinit var categoryImage: String
    @SerializedName("total_rate")
    @Expose
    lateinit var totalRate: String
    @SerializedName("rate_avg")
    @Expose
    lateinit  var rateAvg: String

}
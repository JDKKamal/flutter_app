package com.jdkgroup.interacter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

/*
 * TODO COMMON LOGIC API CALL, DATABASE ETC.
 */

import android.app.Activity
import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.telephony.TelephonyManager
import com.jdkgroup.connection.RestClient
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.operators.RxAPICallDisposingObserver
import com.jdkgroup.model.ModelDrawer
import com.jdkgroup.model.ModelOSInfo
import com.jdkgroup.model.api.response.DefaultResponse
import com.jdkgroup.model.api.response.addtocart.cartlist.CartListResponse
import com.jdkgroup.model.api.response.comment.commentlist.CommentResponse
import com.jdkgroup.model.api.response.comment.commentview.CommentViewResponse
import com.jdkgroup.model.api.response.comment.like.LikeResponse
import com.jdkgroup.model.api.response.comment.logincomment.LoginCommentResponse
import com.jdkgroup.model.api.response.comment.subcomment.SubCommentResponse
import com.jdkgroup.model.api.response.comment.unlike.UnLikeResponse
import com.jdkgroup.model.api.response.forgotpassword.ForgotPasswordResponse
import com.jdkgroup.model.api.response.login.LoginResponse
import com.jdkgroup.model.api.response.menu.MenuResponse
import com.jdkgroup.model.api.response.menucategory.MenuCategoryResponse
import com.jdkgroup.model.api.response.profile.ProfileResponse
import com.jdkgroup.model.api.response.promo.PromoResponse
import com.jdkgroup.model.api.response.shipping.country.CountryResponse
import com.jdkgroup.model.api.response.shipping.district.DistrictResponse
import com.jdkgroup.model.api.response.shipping.orderdelivery.OrderDeliveryResponse
import com.jdkgroup.model.api.response.signup.SignUpResponse
import com.jdkgroup.model.api.response.signup.facebook.FacebookResponse
import com.jdkgroup.model.api.response.signup.gmail.GmailSignUpResponse
import com.jdkgroup.model.api.response.signup.twitter.TwitterSignUpResponse
import com.jdkgroup.model.api.response.slider.SliderResponse
import com.jdkgroup.terasjawa.R
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import okhttp3.MultipartBody
import okhttp3.RequestBody

class AppInteractor {

    //TODO DEFAULT
    fun getDeviceInfo(activity: Activity): List<ModelOSInfo> {
        val packageInfo: PackageInfo
        val deviceUniqueId: String = Settings.Secure.getString(activity.contentResolver, Settings.Secure.ANDROID_ID)
        val deviceType = "Android"
        val deviceName: String = Build.BRAND + Build.MODEL
        val osVersion: String = Build.VERSION.RELEASE
        var appVersion = ""
        val countryIso: String
        val networkOperatorName: String

        try {
            packageInfo = activity.packageManager.getPackageInfo(activity.packageName, 0)
            appVersion = packageInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        }

        val tm = activity.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        countryIso = tm.networkCountryIso
        networkOperatorName = tm.networkOperatorName

        val alModelOSInfo = ArrayList<ModelOSInfo>()
        alModelOSInfo.add(ModelOSInfo(deviceUniqueId, deviceType, deviceName, osVersion, appVersion, countryIso, networkOperatorName))

        return alModelOSInfo
    }

    fun drawerMenuList(): MutableList<ModelDrawer> {
        return ArrayList<ModelDrawer>().apply {
            add(ModelDrawer(R.drawable.drawer_menu, "Menu"))
            add(ModelDrawer(R.drawable.drawer_pesanan, "Add to Card"))
            add(ModelDrawer(R.drawable.drawer_promo, "Promo"))
            add(ModelDrawer(R.drawable.drawer_pesanan, "Faq"))
            add(ModelDrawer(R.drawable.drawer_pesanan, "Privacy Policy"))
            add(ModelDrawer(R.drawable.drawer_pesanan, "Contact Us"))
        }
    }

    fun apiGetSlider(context: Context, callback: InterActorCallback<SliderResponse>) {
        RestClient().service.apiGetSliderList(RestConstant.BASE_URL + RestConstant.API_GET_CAT_SLIDER)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostLogin(context: Context, params: HashMap<String, String>, callback: InterActorCallback<LoginResponse>) {
        RestClient().service.apiPostLogin(RestConstant.BASE_URL + RestConstant.API_POST_LOGIN, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostSignUp(context: Context, params: HashMap<String, String>, callback: InterActorCallback<SignUpResponse>) {
        RestClient().service.apiPostSignUp(RestConstant.BASE_URL + RestConstant.API_POST_SIGN_UP, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostFacebookSignUp(context: Context, params: HashMap<String, String>, callback: InterActorCallback<FacebookResponse>) {
        RestClient().service.apiPostFacebookSignUp(RestConstant.BASE_URL + RestConstant.API_POST_FACEBOOK_SIGN_UP, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostGooglePlusSignUp(context: Context, params: HashMap<String, String>, callback: InterActorCallback<GmailSignUpResponse>) {
        RestClient().service.apiPostGooglePlusSignUp(RestConstant.BASE_URL + RestConstant.API_POST_GOOGLE_SIGN_UP, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostTwitterSignUp(context: Context, params: HashMap<String, String>, callback: InterActorCallback<TwitterSignUpResponse>) {
        RestClient().service.apiPostTwitterSignUp(RestConstant.BASE_URL + RestConstant.API_POST_TWITTER_SIGN_UP, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostForgotPassword(context: Context, params: HashMap<String, String>, callback: InterActorCallback<ForgotPasswordResponse>) {
        RestClient().service.apiPostForgotPassword(RestConstant.BASE_URL + RestConstant.API_POST_FORGOTPASSWORD, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetMenu(context: Context, callback: InterActorCallback<MenuResponse>) {
        RestClient().service.apiGetMenuList(RestConstant.BASE_URL + RestConstant.API_GET_MENU_LIST)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetMenuCategory(context: Context, params: HashMap<String, String>, callback: InterActorCallback<MenuCategoryResponse>) {
        RestClient().service.apiGetMenuCategory(RestConstant.BASE_URL + RestConstant.API_GET, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetAddToCart(context: Context, params: HashMap<String, String>, callback: InterActorCallback<DefaultResponse>) {
        RestClient().service.apiGetAddToCart(RestConstant.BASE_URL + RestConstant.API_GET_ADD_TO_CART, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetAddToCartList(context: Context, params: HashMap<String, String>, callback: InterActorCallback<CartListResponse>) {
        RestClient().service.apiGetAddToCartList(RestConstant.BASE_URL + RestConstant.API_GET_CAT_LIST, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetDeleteCartItem(context: Context, params: HashMap<String, String>, callback: InterActorCallback<DefaultResponse>) {
        RestClient().service.apiGetDeleteCartItem(RestConstant.BASE_URL + RestConstant.API_GET_DELETE_CART_ITEM, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetUpdateCartItem(context: Context, params: HashMap<String, String>, callback: InterActorCallback<DefaultResponse>) {
        RestClient().service.apiGetUpdateCartItem(RestConstant.BASE_URL + RestConstant.API_GET_UPDATE_CART_ITEM, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostProfile(context: Context, image: MultipartBody.Part, userid: RequestBody, name: RequestBody, email: RequestBody, password: RequestBody, mobile: RequestBody, address: RequestBody, callback: InterActorCallback<ProfileResponse>) {
        RestClient().service.apiPostProfile(RestConstant.BASE_URL + RestConstant.API_POST_PROFILE, image, userid, name, email, password, mobile, address)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetCountry(context: Context, callback: InterActorCallback<CountryResponse>) {
        RestClient().service.apiGetCountryList(RestConstant.BASE_URL + RestConstant.API_GET_COUNTRY_LIST)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetDistrict(context: Context, params: HashMap<String, String>, callback: InterActorCallback<DistrictResponse>) {
        RestClient().service.apiGetDistrictList(RestConstant.BASE_URL + RestConstant.API_GET_DISTRICT_LIST, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostOrderDelivery(context: Context, params: HashMap<String, String>, callback: InterActorCallback<OrderDeliveryResponse>) {
        RestClient().service.apiPostOrderDelivery(RestConstant.BASE_URL + RestConstant.API_POST_ORDER_DELIVERY, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetLoginComment(context: Context, params: HashMap<String, String>, callback: InterActorCallback<LoginCommentResponse>) {
        RestClient().service.apiGetLoginComment(RestConstant.BASE_URL + RestConstant.API_GET_LOGIN_COMMENT, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetPromo(context: Context, params: HashMap<String, String>, callback: InterActorCallback<PromoResponse>) {
        RestClient().service.apiGetPromo(RestConstant.BASE_URL + RestConstant.API_GET_PROMO, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostCommentList(context: Context, params: HashMap<String, String>, callback: InterActorCallback<CommentResponse>) {
        RestClient().service.apiPostCommentList(RestConstant.BASE_URL + RestConstant.API_POST_COMMENT_LIST, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostSubComment(context: Context, params: HashMap<String, String>, callback: InterActorCallback<SubCommentResponse>) {
        RestClient().service.apiPostSubComment(RestConstant.BASE_URL + RestConstant.API_POST_SUB_COMMENT, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostLike(context: Context, params: HashMap<String, String>, callback: InterActorCallback<LikeResponse>) {
        RestClient().service.apiPostLike(RestConstant.BASE_URL + RestConstant.API_POST_LIKE, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiPostUnLike(context: Context, params: HashMap<String, String>, callback: InterActorCallback<UnLikeResponse>) {
        RestClient().service.apiPostUnLike(RestConstant.BASE_URL + RestConstant.API_POST_UNLIKE, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    fun apiGetCommentView(context: Context, params: HashMap<String, String>, callback: InterActorCallback<CommentViewResponse>) {
        RestClient().service.apiGetCommentView(RestConstant.BASE_URL + RestConstant.API_GET_COMMENT_VIEW, params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(RxAPICallDisposingObserver(context, callback))
    }

    //TODO CALL API
    /*private fun toSubscribe(rxAPICallDisposingObserver: RxAPICallDisposingObserver<Any>) {
        observable!!.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(rxAPICallDisposingObserver)
    }*/
}
package com.jdkgroup.model.api.response.profile

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class UpdateUserProfile {

    @SerializedName("user_id")
    @Expose
    lateinit var userId: String
    @SerializedName("name")
    @Expose
    lateinit var name: String
    @SerializedName("email")
    @Expose
    lateinit var email: String
    @SerializedName("phone")
    @Expose
    lateinit var phone: String
    @SerializedName("address")
    @Expose
    lateinit var address: String
    @SerializedName("user_image")
    @Expose
    lateinit var userImage: String
    @SerializedName("msg")
    @Expose
    lateinit var msg: String
    @SerializedName("success")
    @Expose
    lateinit var success: String

}
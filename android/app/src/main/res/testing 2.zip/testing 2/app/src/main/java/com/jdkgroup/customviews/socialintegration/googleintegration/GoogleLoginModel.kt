package com.jdkgroup.customviews.socialintegration.googleintegration

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.net.Uri

class GoogleLoginModel(var authtoken: String?, var id: String?, var name: String?, var email: String?, var profilePicture: Uri?)

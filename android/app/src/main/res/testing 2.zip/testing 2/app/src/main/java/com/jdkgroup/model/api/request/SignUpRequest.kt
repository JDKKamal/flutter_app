package com.jdkgroup.model.api.request

class SignUpRequest(var name: String?, var email: String?, var mobile: String?, var password: String?) {
}

package com.jdkgroup.terasjawa.fragment

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.content.Context
import android.os.Bundle
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.*
import com.jdkgroup.baseclass.BaseFragment
import com.jdkgroup.interacter.AppInteractor
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.activity.ProfileActivity
import com.jdkgroup.terasjawa.adapter.DrawerAdapter
import com.jdkgroup.utils.EnumLaunchActivity
import com.jdkgroup.utils.PreferenceUtils
import com.jdkgroup.utils.glideSetAppImageView
import com.jdkgroup.utils.launchActivity
import kotlinx.android.synthetic.main.drawer_header.*
import org.greenrobot.eventbus.EventBus

class FragmentDrawer : BaseFragment(), View.OnClickListener {
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var adapter: DrawerAdapter
    private lateinit var containerView: View
    private lateinit var drawerListener: FragmentDrawerListener

    private lateinit var appInteractor: AppInteractor

    fun setDrawerListener(listener: FragmentDrawerListener) {
        this.drawerListener = listener
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.drawer_header, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        appInteractor = AppInteractor()

        if (PreferenceUtils.preferenceInstance(activity()).profilepicture.isNotEmpty()) {
            activity().glideSetAppImageView(PreferenceUtils.preferenceInstance(activity()).profilepicture, appIvProfile)
        }

        adapter = DrawerAdapter(activity(), appInteractor.drawerMenuList())

        rvDrawer.adapter = adapter
        rvDrawer.layoutManager = LinearLayoutManager(activity)
        rvDrawer.addOnItemTouchListener(RecyclerTouchListener(activity(), rvDrawer, object : ClickListener {
            override fun onClick(view: View, position: Int) {
                drawerListener.onDrawerItemSelected(view, position)
                drawerLayout.closeDrawer(containerView)
            }

            override fun onLongClick(view: View?, position: Int) {

            }
        }))

        llProfile.setOnClickListener(this)
    }

    override fun onPause() {
        EventBus.getDefault().unregister(this)
        super.onPause()
    }

    fun setUp(fragmentId: Int, drawerLayout: DrawerLayout) {
        containerView = activity().findViewById(fragmentId)
        this.drawerLayout = drawerLayout
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.llProfile -> {
                drawerLayout.closeDrawer(containerView)
                activity().launchActivity(ProfileActivity::class.java, EnumLaunchActivity.LaunchActivity)
            }
        }
    }


    interface ClickListener {
        fun onClick(view: View, position: Int)

        fun onLongClick(view: View?, position: Int)
    }

    internal class RecyclerTouchListener(context: Context, recyclerView: RecyclerView, private val clickListener: ClickListener?) : RecyclerView.OnItemTouchListener {
        private val gestureDetector: GestureDetector

        init {
            gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    return true
                }

                override fun onLongPress(e: MotionEvent) {
                    val child = recyclerView.findChildViewUnder(e.x, e.y)
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildAdapterPosition(child))
                    }
                }
            })
        }

        override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {

            val child = rv.findChildViewUnder(e.x, e.y)
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildAdapterPosition(child))
            }
            return false
        }

        override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {}

        override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {

        }
    }

    interface FragmentDrawerListener {
        fun onDrawerItemSelected(view: View, position: Int)
    }
}
package com.jdkgroup.baseclass

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Environment
import android.support.design.widget.CoordinatorLayout
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.Toolbar
import android.view.MenuItem
import android.widget.TextView
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.model.api.Response
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.EnumProgressBar
import com.jdkgroup.utils.checkProgressBar
import com.jdkgroup.utils.hideSoftKeyboard
import com.jdkgroup.utils.logInfo
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper
import java.io.File
import java.util.*

abstract class BaseActivity : AppCompatActivity() {
    private lateinit var params: HashMap<String, String>

    //TODO PROGRESSBAR DIALOG
    fun showProgressDialog(enumProgressBar: EnumProgressBar) {
        checkProgressBar(enumProgressBar)
    }

    val defaultParam: HashMap<String, String>
        get() {
            params = HashMap()
            return params
        }

    val defaultParamWithIdAndToken: HashMap<String, String>?
        get() {
            params = defaultParam
            return params
        }

    open val activity: Activity
        get() = this

    fun setContentViewWithoutInject(layoutResId: Int) {
        super.setContentView(layoutResId)
    }

    override fun onOptionsItemSelected(menuItem: MenuItem): Boolean {
        if (menuItem.itemId == android.R.id.home) {
            hideSoftKeyboard()
            onBackPressed()
        }
        return super.onOptionsItemSelected(menuItem)
    }

    fun toolBarSetFont(toolBar: Toolbar) {
        for (i in 0 until toolBar.childCount) {
            val view = toolBar.getChildAt(i)
            if (view is TextView) {
                val titleFont = Typeface.createFromAsset(applicationContext.assets, AppConstant.FONT_AILERON_SEMIBOLD)
                if (view.text == toolBar.title) {
                    view.typeface = titleFont
                    break
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    fun showSnackBar(coordinatorLayout: CoordinatorLayout, message: String) {
        val snackBar = Snackbar.make(coordinatorLayout, message, Snackbar.LENGTH_SHORT)
        snackBar.show()
    }

    fun appExit() {
        val builder = AlertDialog.Builder(this)
        val alertDialog = builder.create()
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_close, null)
        alertDialog.setView(dialogView)

        val appTvYes = dialogView.findViewById(R.id.appTvYes) as AppCompatTextView
        val appTvNo = dialogView.findViewById(R.id.appTvNo) as AppCompatTextView
        appTvYes.setOnClickListener { finish() }
        appTvNo.setOnClickListener { alertDialog.dismiss() }

        alertDialog.show()
    }

    fun getFileDelete(fileName: String) {
        val file = File(Environment.getExternalStorageDirectory().toString() + File.separator + AppConstant.FOLDER_NAME + File.separator + fileName)
        val deleted = file.delete()
        if (deleted)
            logInfo("Delete successful")
        logInfo("Delete not successful")
    }

    fun responseManage(response: Response): Boolean {
        return when {
            response.code == RestConstant.OK_200 -> {
                true
            }
            else -> {
                false
            }
        }
    }

}
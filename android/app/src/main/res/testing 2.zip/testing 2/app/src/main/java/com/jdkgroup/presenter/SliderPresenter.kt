package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.response.slider.SliderResponse
import com.jdkgroup.utils.EnumProgressBar
import com.jdkgroup.view.SliderView

class SliderPresenter : BasePresenter<SliderView>() {
    private fun callApiGetSlider() {
        appInteractor.apiGetSlider(view.activity(), object : InterActorCallback<SliderResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: SliderResponse) {
                view.apiGetSliderResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }
        })
    }

    fun apiCall(apiNo: Int) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_SLIDER -> callApiGetSlider()
            }
        }
    }
}

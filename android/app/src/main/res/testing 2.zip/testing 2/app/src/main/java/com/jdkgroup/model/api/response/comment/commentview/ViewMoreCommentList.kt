package com.jdkgroup.model.api.response.comment.commentview

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ViewMoreCommentList {

    @SerializedName("c_id")
    @Expose
    lateinit var cId: String
    @SerializedName("comment")
    @Expose
    lateinit var comment: String
    @SerializedName("name")
    @Expose
    lateinit var name: String
    @SerializedName("user_image")
    @Expose
    lateinit var userImage: String
    @SerializedName("user_id")
    @Expose
    lateinit var userId: String

}
package com.jdkgroup.model.api.response.comment.subcomment

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SubComment {

    @SerializedName("count")
    @Expose
    var count: String? = null

}
package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.view.View
import com.jdkgroup.baseclass.BaseActivity
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.hideSoftKeyboard
import kotlinx.android.synthetic.main.toolbar.*

class PesananAndaActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_persanan_anda)

        hideSoftKeyboard()

        appTvTitle.text = "YOUR ORDER"
        rlCount.visibility = View.INVISIBLE

        appIvDrawer.setOnClickListener { activity.finish() }

        //setRecyclerView(recyclerView, 0, recyclerViewLinearLayout);

        //recyclerView.setAdapter(new PesananAndaAdapter(this, listPesananAnda()));
    }

}

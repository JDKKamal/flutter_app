package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.AppCompatTextView
import android.view.View
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.db.DBQuery
import com.jdkgroup.model.api.response.DefaultResponse
import com.jdkgroup.model.api.response.addtocart.cartlist.CartList
import com.jdkgroup.model.api.response.addtocart.cartlist.CartListResponse
import com.jdkgroup.model.db.CategoryListRealm
import com.jdkgroup.presenter.AddToCartPresenter
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.adapter.AddToCardAdapter
import com.jdkgroup.utils.*
import com.jdkgroup.view.AddToCartView
import kotlinx.android.synthetic.main.activity_add_to_card.*
import kotlinx.android.synthetic.main.toolbar.*

class AddToCardActivity : SimpleMVPActivity<AddToCartPresenter, AddToCartView>(), AddToCartView, AddToCardAdapter.ItemListener, View.OnClickListener {


    private lateinit var menuIdDelete: String
    private var positionDelete: Int? = null

    private lateinit var addToCardAdapter: AddToCardAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_to_card)

        hideSoftKeyboard()

        appTvTitle.text = getString(R.string.toolbar_title_order_detail).toUpperCase()
        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem

        setRecyclerView(recyclerView, 0, LINEARLAYOUT)

        val param = HashMap<String, String>()
        param[RestConstant.PARAM_USER_ID] = PreferenceUtils.preferenceInstance(this).userId
        presenter.apiCall(1, param, RestConstant.CALL_API_ADD_TO_CART_LIST)

        when {
            hasInternet() -> swipeRefreshLayout.setOnRefreshListener {
                swipeRefreshLayout.isRefreshing = true
                Handler().postDelayed({
                    val param = HashMap<String, String>()
                    param[RestConstant.PARAM_USER_ID] = PreferenceUtils.preferenceInstance(this).userId
                    presenter.apiCall(0, param, RestConstant.CALL_API_ADD_TO_CART_LIST)
                }, 1000)
            }
        }

        appBtnNext.setOnClickListener(this)
        appIvDrawer.setOnClickListener(this)

        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent, R.color.colorPrimaryDark, R.color.colorAccent)
    }

    override fun createPresenter(): AddToCartPresenter {
        return AddToCartPresenter()
    }

    override fun attachView(): AddToCartView {
        return this
    }

    override fun apiGetAddToCartListResponse(response: CartListResponse) {
        swipeRefreshLayout.isRefreshing = false
        when {
            response.response.code == RestConstant.OK_200 -> {
                addToCardAdapter = AddToCardAdapter(activity, response.cartList)
                addToCardAdapter.setOnListener(this)
                recyclerView.adapter = addToCardAdapter

                appTvBadge.text = response.cartList.size.toString()
                PreferenceUtils.preferenceInstance(this).cartItem = response.cartList.size.toString()
            }
            else -> {
                DBQuery.with(this).realmDeleteTable(CategoryListRealm::class.java)

                var emptyCartList = ArrayList<CartList>()
                addToCardAdapter = AddToCardAdapter(activity, emptyCartList)
                addToCardAdapter.setOnListener(this)
                recyclerView.adapter = addToCardAdapter

                appTvTotal.text = AppConstant.DEFAULT_TOTAL
                PreferenceUtils.preferenceInstance(this).cartItem = AppConstant.DEFAULT_SHOPPING_ITEM
                appTvBadge.text = AppConstant.DEFAULT_SHOPPING_ITEM
            }
        }
    }

    override fun onClickDeleteCartItem(position: Int, cartId: Int, menuId: String, cartName: String) {
        positionDelete = position
        dialogDeleteItem(cartId, menuId, cartName);
    }

    override fun onCartChange(grandTotal: Double, cartItems: CartList, status: Int) {
        appTvTotal.text = activity.getString(R.string.total) + grandTotal.toString()

        when (status) {
            1 -> {
                val qtyCal = cartItems.menuQty.toDouble()
                val priceCal = cartItems.menuPrice.toDouble()

                val param = HashMap<String, String>()
                param[RestConstant.PARAM_USER_ID] = PreferenceUtils.preferenceInstance(this).userId
                param[RestConstant.REST_ID] = cartItems.restId.toString()
                param[RestConstant.MENU_ID] = cartItems.menuId.toString()
                param[RestConstant.MENU_QTY] = cartItems.menuQty.toString()
                param[RestConstant.MENU_PRICE] = (qtyCal * priceCal).toString()

                presenter.apiCall(0, param, RestConstant.CALL_API_UPDATE_CART_ITEM)
            }
        }
    }

    override fun onCartChange(grandTotal: Double, cartItem: String) {
        appTvTotal.text = activity.getString(R.string.total) + grandTotal.toString()
        PreferenceUtils.preferenceInstance(this).cartItem = cartItem

        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem
    }

    override fun apiGetUpdateItemResponse(response: DefaultResponse) {
        when {
            response.response.code == RestConstant.OK_200 -> { }
            else -> showToast(response.response.message)
        }
    }

    override fun apiGetDeleteItemResponse(response: DefaultResponse) {
        showToast(response.response.message)

        when {
            response.response.code == RestConstant.OK_200 -> {
                DBQuery.with(activity()).realmDeleteCategoryId(this.menuIdDelete)
                //val param = HashMap<String, String>()
                //param[RestConstant.PARAM_USER_ID] = PreferenceUtils.preferenceInstance(this).userId
                //presenter.apiCall(1, param, RestConstant.CALL_API_ADD_TO_CART_LIST)

                addToCardAdapter.remove(this.positionDelete!!)
            }
        }
    }

    override fun onFailure(message: String) {
        showToast(message)
    }

    private fun dialogDeleteItem(cartId: Int, menuId: String, name: String) {
        val builder = AlertDialog.Builder(this)
        val alertDialog = builder.create()
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_close, null)
        alertDialog.setView(dialogView)

        val appTvMessage = dialogView.findViewById(R.id.appTvMessage) as AppCompatTextView
        val appTvYes = dialogView.findViewById(R.id.appTvYes) as AppCompatTextView
        val appTvNo = dialogView.findViewById(R.id.appTvNo) as AppCompatTextView

        appTvMessage.text = getString(R.string.dialog_message_delete) + " " + name.toLowerCase() + "?"

        appTvYes.setOnClickListener {
            menuIdDelete = menuId;
            val param = HashMap<String, String>()
            param[RestConstant.PARAM_CART_ID] = cartId.toString()
            presenter.apiCall(0, param, RestConstant.CALL_API_DELETE_CART_ITEM)

            alertDialog.dismiss()
        }
        appTvNo.setOnClickListener { alertDialog.dismiss() }

        alertDialog.show()
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.appBtnNext -> {
                when {
                    PreferenceUtils.preferenceInstance(this).cartItem.toInt() > 0 -> launchActivity(OpsiPengirimanDeliveryActivity::class.java, EnumLaunchActivity.LaunchActivity)
                    else -> showToast(getString(R.string.add_to_card_empty))
                }
            }

            R.id.appIvDrawer -> {
                activity.finish()
            }
        }
    }
}

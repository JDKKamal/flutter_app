package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.os.Handler
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.AppEditTextChangedListener
import com.jdkgroup.db.DBQuery
import com.jdkgroup.model.api.response.menucategory.MenuCategoryList
import com.jdkgroup.model.api.response.menucategory.MenuCategoryResponse
import com.jdkgroup.model.db.CategoryListRealm
import com.jdkgroup.model.parcelable.CategoryParcelable
import com.jdkgroup.model.parcelable.MenuParcelable
import com.jdkgroup.presenter.MenuCategoryPresenter
import com.jdkgroup.terasjawa.CategoryClick
import com.jdkgroup.terasjawa.Finish
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.adapter.CategoryAdapter
import com.jdkgroup.terasjawa.execute
import com.jdkgroup.utils.*
import com.jdkgroup.view.MenuCategoryView
import kotlinx.android.synthetic.main.activity_category.*
import kotlinx.android.synthetic.main.toolbar.*
import java.util.*
import kotlin.collections.ArrayList

class CategoryActivity : SimpleMVPActivity<MenuCategoryPresenter, MenuCategoryView>(), MenuCategoryView, AppEditTextChangedListener.OnEditTextChangedListener, CategoryAdapter.ItemListener {
    private lateinit var parcelableMenu: List<MenuParcelable>

    var menuCategoryList: MutableList<MenuCategoryList> = ArrayList()
    private lateinit var categoryAdapter: CategoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category)

        hideSoftKeyboard()
        menuCategoryList = ArrayList()

        categoryAdapter = CategoryAdapter(this, "", menuCategoryList)
        rvCategory.adapter = categoryAdapter
        categoryAdapter.setOnListener(this)

        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem
        setRecyclerView(rvCategory, 2, GRIDLAYOUT)
        appEdtSearch.addTextChangedListener(AppEditTextChangedListener(this, appEdtSearch))

        parcelableMenu = getParcelable( AppConstant.BUNDLE_PARCELABLE)
        when {
            parcelableMenu.isNotEmpty() -> {
                appTvTitle.text = parcelableMenu[0].categoryName.toUpperCase()

                val param: HashMap<String, String> = hashMapOf(

                        RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(this).userId,
                        RestConstant.PARAM_MENU_LIST_CAT_ID to parcelableMenu[0].cid
                )

                presenter.apiCall(1, param, RestConstant.CALL_API_MENU_CATEGORY)
            }
        }

        swipeRefreshLayout.setOnRefreshListener {
            swipeRefreshLayout.isRefreshing = true
            Handler().postDelayed({
                val param: HashMap<String, String> = hashMapOf(
                        RestConstant.PARAM_USER_ID to PreferenceUtils.preferenceInstance(this).userId,
                        RestConstant.PARAM_MENU_LIST_CAT_ID to parcelableMenu[0].cid
                )
                presenter.apiCall(0, param, RestConstant.CALL_API_MENU_CATEGORY)

            }, 1000)
        }

        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent, R.color.colorPrimaryDark, R.color.colorAccent)

        appIvDrawer.setOnClickListener {
            var intentOperation = Finish(activity)
            execute(intentOperation)
        }
    }

    override fun onAfterTextChanged(str: String) {
        when {
            menuCategoryList.isNotEmpty() && str.isNotEmpty() -> categoryAdapter.filter(str)
            else -> categoryAdapter.filter("")
        }
    }

    override fun onResume() {
        super.onResume()
        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem
        categoryAdapter.notifyDataSetChanged()
    }

    override fun createPresenter(): MenuCategoryPresenter {
        return MenuCategoryPresenter()
    }

    override fun attachView(): MenuCategoryView {
        return this
    }

    override fun apiPostMenuCategoryResponse(response: MenuCategoryResponse) {
        swipeRefreshLayout.isRefreshing = false
        menuCategoryList = ArrayList()

        when {
            response.response.code == RestConstant.OK_200 -> {
                menuCategoryList = response.menuListCat

                when {
                    response.menuCart.isNotEmpty() -> {
                        DBQuery.with(this).realmDeleteTable(CategoryListRealm::class.java)
                        response.menuCart.forEach { cartList -> DBQuery.with(this).realmInsert(CategoryListRealm(UUID.randomUUID().toString(), cartList.menuId)) }
                    }
                    else -> DBQuery.with(this).realmDeleteTable(CategoryListRealm::class.java)
                }
                categoryAdapter = CategoryAdapter(this, parcelableMenu[0].categoryName, menuCategoryList)
                rvCategory.adapter = categoryAdapter
            }
            else -> {
                categoryAdapter = CategoryAdapter(this, parcelableMenu[0].categoryName, menuCategoryList)
                rvCategory.adapter = categoryAdapter

                showToast(response.response.message)
            }
        }

        categoryAdapter.setOnListener(this)
    }

    override fun onClickCategory(menuCategoryList: MenuCategoryList) {
        val listCategoryPassData = ArrayList<CategoryParcelable>()
        var intentOperation = CategoryClick(activity, parcelableMenu, menuCategoryList, listCategoryPassData)
        execute(intentOperation)
    }

    override fun onFailure(message: String) {
        showToast( message)
    }
}

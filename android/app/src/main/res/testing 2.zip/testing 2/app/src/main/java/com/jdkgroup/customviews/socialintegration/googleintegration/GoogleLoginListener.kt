package com.jdkgroup.customviews.socialintegration.googleintegration

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

interface GoogleLoginListener {
    fun onGoogleAuthSignIn(googleLoginModel: GoogleLoginModel)
    fun onGoogleAuthSignInFailed(errorMessage: String)
    fun onGoogleAuthSignOut()
}

package com.jdkgroup.model.api.response.comment.logincomment

import com.jdkgroup.model.api.Response
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class LoginCommentResponse{
    @SerializedName("response")
    @Expose
    var response: Response? = null
}


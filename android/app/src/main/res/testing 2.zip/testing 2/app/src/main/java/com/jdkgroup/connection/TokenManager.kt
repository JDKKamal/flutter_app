package com.jdkgroup.connection

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

interface TokenManager {
    val token: String
    fun hasToken(): Boolean
    fun clearToken()
    fun refreshToken()
}

package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import com.exam.mania.adapter.FaqSectionAdapter
import com.jdkgroup.baseclass.BaseActivity
import com.jdkgroup.model.api.local.Faq
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.adapter.section.SectionFaq
import com.jdkgroup.utils.LINEARLAYOUT
import com.jdkgroup.utils.setRecyclerView
import kotlinx.android.synthetic.main.activity_faq.*
import kotlinx.android.synthetic.main.toolbar.*

class FaqActivity : BaseActivity(), SectionFaq.OnItemClickListener {
    private lateinit var baseMovieAdapter: SectionFaq

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_faq)

        appTvTitle.text = "FAQ"

        setRecyclerView(recyclerView, 0, LINEARLAYOUT)

        getFaqData()

        appIvDrawer.setOnClickListener {
            finish()
        }
    }

    private fun getFaqData() {
        val list = ArrayList<Faq>()
        list.add(Faq("About Deliveroo", "What is Deliveroo?", "Deliveroo is on a mission to transform the way you order food. We partner with the best restaurants in the business – from local hotspots to national favourites – and bring you the food you love, right to your door.", "6-28-2018"))
        list.add(Faq("What is Deliveroo?", "What is the story behind Deliveroo?", "Deliveroo is a British tech success story. After moving from New York to London, our founder was surprised to find it was nearly impossible to get great quality food delivered. So he made it his personal mission to bring great restaurants closer to their customers. We now operate in over 100 towns and cities across the UK, employing over 600 software engineers and employees in our UK headquarters, working with more than 8,000 partner restaurants and engaging 15,000 riders.", "6-28-2018"))
        list.add(Faq("Using Deliveroo", "How does it work?", "You can order either on the website or by using the Deliveroo app, available on iOS and Android. Simply add your postcode to find all the great restaurants delivering in your area, choose your food and place your order. Once the restaurant receives your order, they’ll get to work preparing your food and then carefully package it. Once it's all ready to go, a Deliveroo rider will pick it up and bring it to you. If you want to be super-organised, you can also order up to 24 hours in advance with a scheduled delivery.", "6-28-2018"))

        list.sortWith(Comparator { faq1, faq2 ->
            faq2.date.compareTo(faq1.date)
        })

        baseMovieAdapter = FaqSectionAdapter(list)
        baseMovieAdapter.setOnItemClickListener(this)
        recyclerView.adapter = baseMovieAdapter
    }

    override fun onItemClicked(faq: Faq) {
    }

    override fun onSubHeaderClicked(position: Int) {
        when {
            baseMovieAdapter.isSectionExpanded(baseMovieAdapter.getSectionIndex(position)) -> baseMovieAdapter.collapseSection(baseMovieAdapter.getSectionIndex(position))
            else -> baseMovieAdapter.expandSection(baseMovieAdapter.getSectionIndex(position))
        }
    }
}

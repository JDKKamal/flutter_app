package com.jdkgroup.terasjawa.adapter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.Activity
import android.support.v4.content.ContextCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.customviews.recyclerview.BaseRecyclerView
import com.jdkgroup.customviews.recyclerview.BaseViewHolder
import com.jdkgroup.db.DBQuery
import com.jdkgroup.model.api.response.menucategory.MenuCategoryList
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.glideSetAppImageView
import kotlinx.android.synthetic.main.itemview_category.view.*
import java.util.*

class CategoryAdapter(private val activity: Activity, private val menuName: String, private val menuCategoryList: MutableList<MenuCategoryList>) : BaseRecyclerView<MenuCategoryList>() {
    private val inflater: LayoutInflater = LayoutInflater.from(activity)

    private lateinit var listener: ItemListener
    private val searchList: MutableList<MenuCategoryList>

    init {
        searchList = ArrayList()
        searchList.addAll(menuCategoryList)
    }

    fun setOnListener(listener: ItemListener) {
        this.listener = listener
    }

    override fun getItem(position: Int): MenuCategoryList {
        return menuCategoryList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<MenuCategoryList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_category, parent, false))
    }

    override fun getItemCount(): Int {
        return menuCategoryList.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<MenuCategoryList>(itemView) {
        val appBtnMenu = itemView.appBtnMenu!!
        val appIvMenu = itemView.appIvMenu!!
        val appTvTitle = itemView.appTvTitle!!
        val appTvPrice = itemView.appTvPrice!!
        val appRbMenu = itemView.appRbMenu!!

        override fun populateItem(t: MenuCategoryList) {
            appBtnMenu.text = menuName
            appTvPrice.text = t.menuPrice
            appTvTitle.text = t.menuName
            appRbMenu.rating = t.totalRate.toFloat()
            activity.glideSetAppImageView(RestConstant.IMAGE_URL + t.menuImage, this.appIvMenu)

            val categoryList = DBQuery.with(activity).realmList(t.mid)
            when {
                categoryList.isNotEmpty() -> {
                    appBtnMenu.setTextColor(ContextCompat.getColor(activity, R.color.colorPesanMenu))
                    appBtnMenu.setBackgroundResource(R.drawable.style_add_to_card)
                    appBtnMenu.text = "Menu"
                }
                else -> {
                    appBtnMenu.setTextColor(ContextCompat.getColor(activity, R.color.colorPesanMenu))
                    appBtnMenu.setBackgroundResource(R.drawable.style_add_to_card_no)
                    appBtnMenu.text = "Ordered"
                }
            }

            itemView.setOnClickListener { listener.onClickCategory(menuCategoryList[layoutPosition]) }
        }
    }

    //TODO FILTER
    fun filter(searchText: String) {
        menuCategoryList.clear()

        when {
            searchText.isEmpty() -> menuCategoryList.addAll(searchList)
            else -> searchList.forEach { search ->
                if (search.menuName.toLowerCase(Locale.getDefault()).contains(searchText)
                || search.menuPrice.toLowerCase(Locale.getDefault()).contains(searchText)
                || search.totalRate.toLowerCase(Locale.getDefault()).contains(searchText)) {
                    menuCategoryList.add(search)
                }
            }
        }
        notifyDataSetChanged()
    }

    interface ItemListener {
        fun onClickCategory(menuCategoryList: MenuCategoryList)
    }
}

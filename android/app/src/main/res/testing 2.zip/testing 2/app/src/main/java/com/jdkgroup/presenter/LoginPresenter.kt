package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.request.LoginRequest
import com.jdkgroup.model.api.response.login.LoginResponse
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.*
import com.jdkgroup.view.LoginView

class LoginPresenter : BasePresenter<LoginView>() {
    private fun callApiPostLogin(params: HashMap<String, String>) {
        appInteractor.apiPostLogin(view.activity(), params, object : InterActorCallback<LoginResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: LoginResponse) {
                view.apiPostLoginResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }
        })
    }

    fun apiCall(apiNo: Int, loginRequest: LoginRequest) {
        when {
            hasInternet() -> when (apiNo) {
                RestConstant.CALL_API_LOGIN -> {
                    /*
                     val param = mapOf(Pair(RestConstant.PARAM_EMAIL,loginRequest.email.toLowerCase()),
                            Pair(RestConstant.PARAM_PASSWORD, loginRequest.password))
                    */
                    val param: HashMap<String, String> = hashMapOf(
                            RestConstant.PARAM_EMAIL to loginRequest.email.toLowerCase(),
                            RestConstant.PARAM_PASSWORD to loginRequest.password
                    )
                    callApiPostLogin(param)
                }
                RestConstant.CALL_LOGIN_SOCIAL -> {
                    val param: HashMap<String, String> = hashMapOf(
                            RestConstant.PARAM_EMAIL to loginRequest.email.toLowerCase()
                    )
                    callApiPostLogin(param)
                }
            }
        }
    }

    //TODO VALIDATION
    fun validation(email: String, password: String) {
        return when {
            isEmpty(email) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_email))
            }
            !isRegexValidator(email, patternEmail) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_valid_email))
            }
            isEmpty(password) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_password))
            }
            else -> apiCall(RestConstant.CALL_API_LOGIN, LoginRequest(email, password))
        }
    }
    //FINISH VALIDATION
}

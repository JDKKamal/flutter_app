package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.jdkgroup.baseclass.BaseActivity
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.model.parcelable.DeliveryParcelable
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.hideSoftKeyboard
import com.jdkgroup.utils.isEmpty
import com.jdkgroup.utils.sentParcelsLaunchClear
import com.jdkgroup.utils.showToast
import kotlinx.android.synthetic.main.activity_opsi_pengiriman_take_away.*
import kotlinx.android.synthetic.main.toolbar.*
import java.text.SimpleDateFormat
import java.util.*

class OpsiPengirimanTakeAwayActivity : BaseActivity(), AdapterView.OnItemSelectedListener {
    private lateinit var time: String
    var listCountry: MutableList<String> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_opsi_pengiriman_take_away)

        hideSoftKeyboard()

        appTvTitle.text = getString(R.string.toolbar_title_shipping_option).toUpperCase()
        rlCount.visibility = View.INVISIBLE
        listCountry.add("Time")

        val aaTime = ArrayAdapter(this, R.layout.itemview_spinner_select, listCountry)
        aaTime.setDropDownViewResource(R.layout.itemview_spinner_default)
        appSpTime.adapter = aaTime

        //LISTENER
        appSpTime.onItemSelectedListener = this

        appIvDrawer.setOnClickListener { activity.finish() }

        appIvUnDeliverySelect.setOnClickListener {
            finish()
        }

        appBtnNext.setOnClickListener {
            var title = appEdtTitle.text.toString()
            var fullName = appEdtFullName.text.toString()
            var mobile = appEdtMobile.text.toString()

            when {
                validation(title, fullName, mobile) -> when {
                    time != "Time" -> {
                        val alPassDataQuestion = ArrayList<DeliveryParcelable>()
                        alPassDataQuestion.add(DeliveryParcelable(title, fullName, this.time, "", "", "", "", "", mobile, 0))
                        sentParcelsLaunchClear(OrderDeliveryActivity::class.java, AppConstant.BUNDLE_PARCELABLE, alPassDataQuestion, 1)
                    }
                    else -> showToast("Select order time")
                }
            }
        }

        val sdf = SimpleDateFormat("HH:mm:aa")
        val currentDateTime = sdf.format(Date())

        val splitTime = currentDateTime.split(":".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()

        when {
            Integer.valueOf(splitTime[0]) in 10..21 -> for (i in Integer.valueOf(splitTime[0])..20) when {
                i < 22 && i >= 10 -> listCountry.add(i.toString() + ":" + splitTime[1])
            }
            else -> println(getString(R.string.msg_restaurant_close))
        }
    }

    override fun onBackPressed() {
        finish()
    }

    override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {

        time = when {
            listCountry[position] != "Time" -> listCountry[position]
            else -> "Time"
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>) {

    }

    private fun validation(title: String, fullName: String, mobile: String): Boolean {
        return when {
            isEmpty(title) -> {
                showToast(activity.getString(R.string.msg_empty_title_order))
                false
            }
            isEmpty(fullName) -> {
                showToast(activity.getString(R.string.msg_empty_full_name_order))
                false
            }
            isEmpty(mobile) -> {
                showToast(activity.getString(R.string.msg_empty_mobile))
                false
            }

            else -> true
        }
    }
}

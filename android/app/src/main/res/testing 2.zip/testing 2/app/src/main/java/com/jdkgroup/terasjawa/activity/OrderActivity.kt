package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.support.v7.widget.AppCompatImageView
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.Toolbar
import android.view.View

import com.jdkgroup.baseclass.BaseActivity
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.hideSoftKeyboard

class OrderActivity: BaseActivity() {
    private lateinit var toolBar: Toolbar
    private lateinit var appTvTitle: AppCompatTextView
    private lateinit var appIvDrawer: AppCompatImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order)

        //bindViews();
        hideSoftKeyboard()

        toolBar = findViewById(R.id.toolBar)
        setSupportActionBar(toolBar)
        toolBar.findViewById<View>(R.id.appIvDrawer)

        appTvTitle = toolBar.findViewById(R.id.appTvTitle)
        appIvDrawer = toolBar.findViewById(R.id.appIvDrawer)

        appTvTitle.text = "YOUR ORDER"
        appIvDrawer.setOnClickListener { activity.finish() }
    }
}

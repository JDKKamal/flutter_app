package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.content.Context
import android.os.Bundle
import android.support.v4.app.FragmentManager
import android.support.v4.view.GravityCompat
import android.support.v7.widget.AppCompatTextView
import android.view.View
import com.jdkgroup.baseclass.BaseActivity
import com.jdkgroup.model.event.ProfileEvent
import com.jdkgroup.model.event.PromoEvent
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.fragment.FragmentDrawer
import com.jdkgroup.terasjawa.fragment.MenuFragment
import com.jdkgroup.utils.*
import kotlinx.android.synthetic.main.activity_drawer.*
import kotlinx.android.synthetic.main.drawer_header.*
import kotlinx.android.synthetic.main.toolbar.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class DrawerActivity : BaseActivity(), View.OnClickListener, FragmentDrawer.FragmentDrawerListener {
    private lateinit var fm: FragmentManager
    private lateinit var drawerFragment: FragmentDrawer

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drawer)

        fm = supportFragmentManager
        EventBus.getDefault().register(this)

        appTvTitle.text = getString(R.string.toolbar_title_drawer)
        appIvDrawer.setImageResource(R.mipmap.arrow_drawer)

        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem

        rlCount.setOnClickListener(this)

        drawerFragment = supportFragmentManager.findFragmentById(R.id.fragment_navigation_drawer) as FragmentDrawer
        drawerFragment.setUp(R.id.fragment_navigation_drawer, findViewById(R.id.drawerLayout))
        drawerFragment.setDrawerListener(this)

        val fragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.fragment, MenuFragment())
        fragmentTransaction.commit()

        appIvDrawer.setOnClickListener(this)

        /*
        startService(Intent(this, PromoCountService::class.java))
        val cal = Calendar.getInstance()
        val intent = Intent(this, PromoCountService::class.java)
        val pintent = PendingIntent.getService(this, 0, intent, 0)
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), (60 * 1000).toLong(), pintent)
        */
    }

    override fun onResume() {
        super.onResume()
        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem
    }

    override fun onBackPressed() {
        appExit()
    }

    private fun drawerClose() {
        drawerLayout.closeDrawer(GravityCompat.START)
    }

    @Subscribe
    fun onEvent(event: ProfileEvent) {
        glideSetAppImageView(event.userProfile, appIvProfile)
    }

    @Subscribe
    fun onEvent(event: PromoEvent) {
        glideSetAppImageView(event.promoCount, appIvProfile)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appIvDrawer -> drawerLayout.openDrawer(GravityCompat.START)
            R.id.rlCount -> {
                when {
                    PreferenceUtils.preferenceInstance(this).cartItem.toInt() > 0 -> launchActivity(AddToCardActivity::class.java, EnumLaunchActivity.LaunchActivity)
                    else -> showToast(getString(R.string.add_to_card_empty))
                }
            }
        }
    }

    override fun onDrawerItemSelected(view: View, position: Int) {
        drawerMenuClick(position)
        drawerClose()
    }

    private fun drawerMenuClick(id: Int) {
        when (id) {
            0 -> {
                val fragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.fragment, MenuFragment())
                fragmentTransaction.commit()
            }

            1 -> {
                launchActivity(AddToCardActivity::class.java, EnumLaunchActivity.LaunchActivity)
            }

            2 -> {
                launchActivity(PromoActivity::class.java, EnumLaunchActivity.LaunchActivity)
            }

            3 -> {
                launchActivity(FaqActivity::class.java, EnumLaunchActivity.LaunchActivity)
            }

            5 -> {
                launchActivity(ContactUsActivity::class.java, EnumLaunchActivity.LaunchActivity)
            }
        }
    }
}

package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.view.View
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.model.api.request.DistrictRequest
import com.jdkgroup.model.api.response.shipping.country.CountryList
import com.jdkgroup.model.api.response.shipping.country.CountryResponse
import com.jdkgroup.model.api.response.shipping.district.DistrictList
import com.jdkgroup.model.api.response.shipping.district.DistrictResponse
import com.jdkgroup.model.api.response.shipping.orderdelivery.OrderDeliveryResponse
import com.jdkgroup.model.parcelable.DeliveryParcelable
import com.jdkgroup.presenter.OpsiPengirimanPresenter
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.spdialog.SpDialogCountry
import com.jdkgroup.terasjawa.spdialog.SpDialogDistrict
import com.jdkgroup.utils.*
import com.jdkgroup.view.OpsiPengirimanView
import kotlinx.android.synthetic.main.activity_opsi_pengiriman_delivery.*
import kotlinx.android.synthetic.main.toolbar.*

class OpsiPengirimanDeliveryActivity : SimpleMVPActivity<OpsiPengirimanPresenter, OpsiPengirimanView>(), OpsiPengirimanView, View.OnClickListener {


    private var listCountry: MutableList<CountryList> = arrayListOf()
    private var listDistrict: MutableList<DistrictList> = arrayListOf()

    private var countryId: String? = ""
    private var districtId: String? = ""
    private var districtDeliveryService: String? = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_opsi_pengiriman_delivery)
        hideSoftKeyboard()

        appTvTitle.text = getString(R.string.toolbar_title_shipping_option).toUpperCase()
        rlCount.visibility = View.INVISIBLE

        presenter.apiCall(RestConstant.CALL_API_COUNTRY, null, null)

        appIvDrawer.setOnClickListener(this)
        appIvTakeawayUnselect.setOnClickListener(this)
        appBtnNext.setOnClickListener(this)
        llCountry.setOnClickListener(this)
        llDistrict.setOnClickListener(this)
    }

    override fun createPresenter(): OpsiPengirimanPresenter {
        return OpsiPengirimanPresenter()
    }

    override fun attachView(): OpsiPengirimanView {
        return this
    }

    override fun apiGetCountryResponse(response: CountryResponse) {
        countryId = ""
        listCountry = response.countryList as MutableList<CountryList>
    }

    override fun apiGetDistrictResponse(response: DistrictResponse) {
        listDistrict = response.districtList as MutableList<DistrictList>
    }

    override fun apiPostOrderDeliveryResponse(response: OrderDeliveryResponse) {
        showToast(response.response!!.message)

        when {
            response.response!!.code == RestConstant.OK_200 -> launchActivity(OrderDeliveryActivity::class.java, EnumLaunchActivity.LaunchActivity)
        }
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.appIvDrawer -> activity.finish()

            R.id.appIvTakeawayUnselect -> launchActivity(OpsiPengirimanTakeAwayActivity::class.java, EnumLaunchActivity.LaunchActivity)

            R.id.appBtnNext -> {
                var title = appEdtTitle.text.toString()
                var fullName = appEdtFullName.text.toString()
                var address = appEdtAddress.text.toString()
                var mobile = appEdtMobile.text.toString()

                when {
                    presenter.validation(title, fullName, address, countryId!!, districtId!!, districtDeliveryService!!, mobile) -> {

                        val alPassDataQuestion = ArrayList<DeliveryParcelable>()
                        alPassDataQuestion.add(DeliveryParcelable(title, fullName, address, countryId!!, districtId!!, appTvCountry.text.toString(), appTvDistrict.text.toString(), districtDeliveryService!!, mobile, 1))
                        sentParcelsLaunchClear(OrderDeliveryActivity::class.java, AppConstant.BUNDLE_PARCELABLE, alPassDataQuestion, 1)
                        //presenter.apiCall(this, RestConstant.CALL_API_ORDER_DELIVERY, null, OrderDeliveryRequest(PreferenceUtils.preferenceInstance(this).userId, title, fullName, mobile, address, this.countryId, this.districtId))
                    }
                }
            }
            R.id.llCountry -> {
                when {
                    listCountry.isNotEmpty() -> {
                        val dialogCountry = SpDialogCountry(this, getString(R.string.sp_select_country), SpDialogCountry.OnItemClick { `object` ->
                            var selectedCountry = `object` as CountryList
                            appTvCountry.text = selectedCountry.countryName
                            countryId = selectedCountry.countryId

                            districtId = ""
                            districtDeliveryService = ""

                            appTvDistrict.text = getString(R.string.hint_district)
                            presenter.apiCall(RestConstant.CALL_API_DISTRICT, DistrictRequest(selectedCountry.countryId), null)

                        }, listCountry)
                        dialogCountry.show()
                    }
                    else -> showToast(getString(R.string.msg_no_data))
                }
            }
            R.id.llDistrict -> {
                when {
                    listDistrict.isNotEmpty() -> {
                        val dialogDistrict = SpDialogDistrict(this, getString(R.string.sp_select_country), SpDialogDistrict.OnItemClick { `object` ->
                            var selectedDistrict = `object` as DistrictList
                            appTvDistrict.text = selectedDistrict.stateName
                            districtId = selectedDistrict.stateId
                            districtDeliveryService = selectedDistrict.serviceCharge

                        }, listDistrict)
                        dialogDistrict.show()
                    }
                    else -> showToast(getString(R.string.msg_no_data))
                }
            }
        }
    }

    override fun onFailure(message: String) {
        showToast(message)
    }
}

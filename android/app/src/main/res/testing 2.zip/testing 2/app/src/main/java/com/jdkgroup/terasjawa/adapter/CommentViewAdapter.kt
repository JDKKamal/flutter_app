package com.jdkgroup.terasjawa.adapter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.jdkgroup.customviews.recyclerview.BaseRecyclerView
import com.jdkgroup.customviews.recyclerview.BaseViewHolder
import com.jdkgroup.model.api.response.comment.commentview.ViewMoreCommentList
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.glideSetAppImageView
import kotlinx.android.synthetic.main.itemview_section_child.view.*

class CommentViewAdapter(private val activity: Activity, private val profiles: List<ViewMoreCommentList>) : BaseRecyclerView<ViewMoreCommentList>() {
    private val inflater: LayoutInflater = LayoutInflater.from(activity)

    override fun getItem(position: Int): ViewMoreCommentList {
        return profiles[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<ViewMoreCommentList> {
        return ViewHolder(inflater.inflate(R.layout.itemview_section_child, parent, false))
    }

    override fun getItemCount(): Int {
        return profiles.size
    }

    internal inner class ViewHolder(itemView: View) : BaseViewHolder<ViewMoreCommentList>(itemView) {
        var appTvChildTitle = itemView.appTvChildTitle!!
        var appTvChildComment = itemView.appTvChildComment!!
        var appIvChild = itemView.appIvChild!!

        override fun populateItem(t: ViewMoreCommentList) {
            appTvChildTitle.text = t.name
            appTvChildComment.text = t.comment

            activity.glideSetAppImageView( t.userImage, this.appIvChild)

        }
    }
}

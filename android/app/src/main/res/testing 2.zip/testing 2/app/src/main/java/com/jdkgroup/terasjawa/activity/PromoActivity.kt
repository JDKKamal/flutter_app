package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.os.Handler
import android.support.v4.widget.SwipeRefreshLayout
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.constant.AppConstant
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.db.DBQuery
import com.jdkgroup.model.api.response.promo.PromoListCat
import com.jdkgroup.model.api.response.promo.PromoResponse
import com.jdkgroup.model.db.CategoryListRealm
import com.jdkgroup.model.parcelable.CategoryParcelable
import com.jdkgroup.presenter.PromoPresenter
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.adapter.PromoAdapter
import com.jdkgroup.utils.*
import com.jdkgroup.view.PromoView
import kotlinx.android.synthetic.main.activity_promo.*
import kotlinx.android.synthetic.main.toolbar.*
import java.util.*

class PromoActivity : SimpleMVPActivity<PromoPresenter, PromoView>(), PromoView, PromoAdapter.ItemListener {
    private lateinit var promoAdapter: PromoAdapter
    private lateinit var listPromo: MutableList<PromoListCat>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_promo)

        hideSoftKeyboard()

        appTvTitle.text = getString(R.string.toolbar_title_promo).toUpperCase()
        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem

        setRecyclerView(recyclerView, 2, GRIDLAYOUT)

        listPromo = mutableListOf()
        presenter.apiCall(1, RestConstant.CALL_API_PROMO)
        promoAdapter = PromoAdapter(this, listPromo)
        promoAdapter.setOnListener(this)
        recyclerView.adapter = promoAdapter

        if (hasInternet()) {
            findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout).setOnRefreshListener {
                swipeRefreshLayout.isRefreshing = true
                Handler().postDelayed({
                    presenter.apiCall(0, RestConstant.CALL_API_PROMO)
                }, 1000)
            }
        }

        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent, R.color.colorPrimaryDark, R.color.colorAccent)

        appIvDrawer.setOnClickListener { activity.finish() }
    }

    override fun onResume() {
        super.onResume()
        appTvBadge.text = PreferenceUtils.preferenceInstance(this).cartItem

        promoAdapter.notifyDataSetChanged()
    }

    override fun createPresenter(): PromoPresenter {
        return PromoPresenter()
    }

    override fun attachView(): PromoView {
        return this
    }

    override fun apiPostPromoResponse(response: PromoResponse) {
        swipeRefreshLayout.isRefreshing = false

        when {
            response.response.code == RestConstant.OK_200 -> {
                when {
                    response.menuCart.isNotEmpty() -> {
                        DBQuery.with(this).realmDeleteTable(CategoryListRealm::class.java)
                        response.menuCart.forEach { cartList -> DBQuery.with(this).realmInsert(CategoryListRealm(UUID.randomUUID().toString(), cartList.menuId)) }
                    }
                    else -> DBQuery.with(this).realmDeleteTable(CategoryListRealm::class.java)
                }

                promoAdapter.promoAddAll(response.menuListCat)
            }
            else -> showToast(response.response.message!!)
        }
    }

    override fun onClickPromo(promoListCat: PromoListCat) {
        val listCategoryPassData = ArrayList<CategoryParcelable>()
        listCategoryPassData.add(
                CategoryParcelable("",
                        promoListCat.menuName, //parcelableTopic[0].categoryName
                        promoListCat.mid,
                        promoListCat.menuName,
                        promoListCat.menuInfo,
                        promoListCat.menuImage,
                        promoListCat.totalRate,
                        promoListCat.rateAvg,
                        promoListCat.specialPrice
                ))
        sentParcelsLaunchClear(CategoryDetailActivity::class.java, AppConstant.BUNDLE_PARCELABLE, listCategoryPassData, 1)
    }

    override fun onFailure(message: String) {
        showToast(message)
    }
}

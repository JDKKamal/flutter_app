package com.jdkgroup.customviews.socialintegration.twitterintegration

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

class TwitterUser {
    var name: String? = null

    var email: String? = null

    var description: String? = null

    var pictureUrl: String? = null

    var bannerUrl: String? = null

    var language: String? = null

    var id: Long = 0
}
package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.terasjawa.R
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.response.DefaultResponse
import com.jdkgroup.utils.EnumProgressBar
import com.jdkgroup.utils.isEmpty
import com.jdkgroup.view.DetailView
import com.jdkgroup.utils.showToast
import kotlin.collections.HashMap

class DetailPresenter : BasePresenter<DetailView>() {
    private fun callApiGetAdToCart(params: HashMap<String, String>) {
        appInteractor.apiGetAddToCart(view.activity(), params, object : InterActorCallback<DefaultResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: DefaultResponse) {
                view.apiGetAddToCartResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }
        })
    }

    internal fun apiCall(params: HashMap<String, String>, apiNo: Int) {
        when {
            hasInternet() ->
                when (apiNo) {
                    RestConstant.CALL_API_ADD_TO_CART -> callApiGetAdToCart(params)
                }
        }
    }

    internal fun validationComment(comment: String): Boolean {
        return when {
            isEmpty(comment) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_comment))
                false
            }
            else -> true
        }
    }
}

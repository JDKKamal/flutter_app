package com.jdkgroup.presenter

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BasePresenter
import com.jdkgroup.constant.RestConstant
import com.jdkgroup.interacter.InterActorCallback
import com.jdkgroup.model.api.request.ForgotPasswordRequest
import com.jdkgroup.model.api.response.forgotpassword.ForgotPasswordResponse
import com.jdkgroup.terasjawa.R
import com.jdkgroup.utils.*
import com.jdkgroup.view.ForgotPasswordView

class ForgotPasswordPresenter : BasePresenter<ForgotPasswordView>() {
    private fun callApiPostForgotPassword(params: HashMap<String, String>) {
        appInteractor.apiPostForgotPassword(view.activity(), params, object : InterActorCallback<ForgotPasswordResponse> {
            override fun onStart() {
                view.showProgressDialog(EnumProgressBar.Show)
            }

            override fun onResponse(response: ForgotPasswordResponse) {
                view.apiPostForgotPasswordResponse(response)
            }

            override fun onFinish() {
                view.showProgressDialog(EnumProgressBar.Hide)
            }

            override fun onError(message: String) {
                view.onFailure(message)
            }
        })
    }

    fun apiCall(apiNo: Int, forgotPasswordRequest: ForgotPasswordRequest) {
        when {
            hasInternet() ->
                when (apiNo) {
                    RestConstant.CALL_API_FORGOTPASSWORD -> {
                        val param = HashMap<String, String>()
                        param[RestConstant.PARAM_EMAIL] = forgotPasswordRequest.email!!.toLowerCase()
                        callApiPostForgotPassword(param)
                    }
                }
        }
    }

    //TODO VALIDATION
    fun validation(email: String) {
        return when {
            isEmpty(email) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_empty_email))
            }
            !isRegexValidator(email, patternEmail) -> {
                view.activity().showToast(view.activity().getString(R.string.msg_valid_email))
            }
            else -> apiCall(RestConstant.CALL_API_FORGOTPASSWORD, ForgotPasswordRequest(email))
        }
    }
    //FINISH VALIDATION
}

package com.jdkgroup.model.api.response.shipping.district

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class DistrictList {

    @SerializedName("state_id")
    @Expose
    lateinit var stateId: String
    @SerializedName("state_name")
    @Expose
    lateinit var stateName: String
    @SerializedName("service_charge")
    @Expose
    lateinit var serviceCharge: String
}
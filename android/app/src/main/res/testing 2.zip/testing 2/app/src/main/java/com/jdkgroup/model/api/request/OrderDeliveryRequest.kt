package com.jdkgroup.model.api.request

class OrderDeliveryRequest
( var userid: String,
   var title: String,
   var fullname: String,
   var mobile: String,
   var address: String,
   var countryid: String,
   var stateid: String)

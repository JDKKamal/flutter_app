package com.jdkgroup.baseclass

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.interacter.AppInteractor

open class BasePresenter<V : BaseView> {
    lateinit var view: V
        private set

    val isViewAttached: Boolean
        get() = true

    protected val appInteractor: AppInteractor
        get() = AppInteractor()

    internal fun attachView(view: V) {
        this.view = view
    }

    fun hasInternet(): Boolean {
        return view.hasInternet()
    }

    fun checkViewAttached() {
        if (!isViewAttached) throw MvpViewNotAttachedException()
    }

    class MvpViewNotAttachedException : RuntimeException("Please call Presenter.attachView(MvpView) before requesting data to the Presenter")
}

package com.jdkgroup.terasjawa.activity

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import android.os.Bundle
import android.view.View
import com.jdkgroup.baseclass.SimpleMVPActivity
import com.jdkgroup.model.api.response.forgotpassword.ForgotPasswordResponse
import com.jdkgroup.presenter.ForgotPasswordPresenter
import com.jdkgroup.terasjawa.Finish
import com.jdkgroup.terasjawa.R
import com.jdkgroup.terasjawa.execute
import com.jdkgroup.utils.hideSoftKeyboard
import com.jdkgroup.utils.showToast
import com.jdkgroup.view.ForgotPasswordView
import kotlinx.android.synthetic.main.activity_forgot_password.*

class ForgotPasswordActivity : SimpleMVPActivity<ForgotPasswordPresenter, ForgotPasswordView>(), ForgotPasswordView, View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        hideSoftKeyboard()

        appBtnForgotPassword.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.appBtnForgotPassword -> {
                val email = appEdtEmail.text.toString()
                presenter.validation(email)
            }
        }
    }

    override fun createPresenter(): ForgotPasswordPresenter {
        return ForgotPasswordPresenter()
    }

    override fun attachView(): ForgotPasswordView {
        return this
    }

    override fun apiPostForgotPasswordResponse(response: ForgotPasswordResponse) {
        val responseCheck = response.response
        showToast(responseCheck.message)

        when {
            responseManage(responseCheck) -> {
                var intentOperation = Finish(activity)
                execute(intentOperation)
            }
            else -> appEdtEmail.text = null
        }
    }

    override fun onFailure(message: String) {
        showToast(message)
    }

    override fun onBackPressed() {
        var intentOperation = Finish(activity)
        execute(intentOperation)
    }
}

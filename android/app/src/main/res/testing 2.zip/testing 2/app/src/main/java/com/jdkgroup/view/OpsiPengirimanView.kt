package com.jdkgroup.view

/*
   Developed BY Lakhani Kamlesh
   kamal.lakhani56@gmail.com
   +91 9586331823
*/

import com.jdkgroup.baseclass.BaseView
import com.jdkgroup.model.api.response.shipping.country.CountryResponse
import com.jdkgroup.model.api.response.shipping.district.DistrictResponse
import com.jdkgroup.model.api.response.shipping.orderdelivery.OrderDeliveryResponse

interface OpsiPengirimanView : BaseView {
    fun apiGetCountryResponse(response: CountryResponse)
    fun apiGetDistrictResponse(response: DistrictResponse)
    fun apiPostOrderDeliveryResponse(response: OrderDeliveryResponse)
}

